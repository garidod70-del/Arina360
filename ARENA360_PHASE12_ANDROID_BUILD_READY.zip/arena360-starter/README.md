# ARENA 360 — sports services platform

**ONE PLATFORM. ALL SPORTS.**

This repository is the active development foundation for the ARENA 360 platform. The authoritative requirements are in `docs/MASTER_DEVELOPMENT_SPECIFICATION_V1.0.md`.

## Project structure

- `apps/mobile` — Flutter Android/iOS client.
- `apps/api` — NestJS API and Prisma/PostgreSQL schema.
- `apps/admin-web` — Next.js administration client foundation.
- `docs` — master specification, architecture, data model, API map, roadmap and QA checklist.

## Implemented source foundations

- Mobile login/registration interface and seven-service navigation prototype.
- NestJS API foundation and catalogue endpoints for the seven ARENA 360 service groups.
- PostgreSQL-backed account registration/login, bcrypt password hashing and JWT access tokens.
- Protected profile endpoint.
- Authenticated provider applications, applicant-only status view and admin pending/review endpoints.
- Provider approval promotes the account to `PROVIDER`; protected requests reload current account role/status from the database.
- Admin review audit log, transactional role promotion and one-time initial-admin bootstrap script.
- Prisma schema and incremental SQL migrations.

## Not yet production-complete

Real SMS/OTP delivery, refresh-token rotation, password recovery, distributed rate limiting, push notifications, full provider/admin dashboards, pool play and sport-specific tournament formats, QR scanner UI, refunds/settlement, production monitoring, deployment and release signing remain outstanding. QPay Merchant V2 invoice creation and server-side payment verification are implemented behind merchant environment configuration; they are not live until QPay issues credentials and the sandbox flow is tested. See the API README and development status for precise boundaries.

## Build status

No production APK is included or claimed as built. Flutter/Android SDK is required to build the mobile application. API dependencies must be installed before NestJS/Prisma compilation and database integration tests can run. See `docs/BUILD-APK.md`.

## Latest implementation
- Phase 4: venue listings and booking API with database-level overlap protection.
- Phase 5: competition registration, single-elimination and round-robin scheduling, automatic byes, winner advancement, standings, score validation and podium output.
- See `docs/PHASE4_VENUE_BOOKING.md` and `docs/PHASE5_COMPETITIONS.md` for routes and verification notes.

## Latest development phase

Phase 7 adds QPay Merchant V2 invoice creation, callback shared-secret validation and server-to-server payment confirmation; payment records now update marketplace orders and fitness memberships only after exact amount verification. Venue bookings create pending payment records. Mobile session restoration and secure logout are also added.

Phase 6 adds training enrollment and certificate issuance, hashed-token QR verification, marketplace product/order inventory, fitness center plans/memberships, and user notifications. See `docs/PHASE6_ECOSYSTEM.md`. QPay sandbox/live testing remains pending until merchant credentials and a public HTTPS callback endpoint are configured; callbacks are independently verified with QPay server-side payment checks.

## Mobile API configuration

The Flutter app uses `http` and `flutter_secure_storage`. Set `API_BASE_URL` with `--dart-define` when running/building. Android emulator default is `http://10.0.2.2:3000/api/v1`; physical devices need a reachable server address. See `docs/BUILD-APK.md`.

## Phase 10 — User Account & Professional Referee Cabinet

See [`docs/PHASE10_ACCOUNT_AND_REFEREE_PROFESSIONAL.md`](docs/PHASE10_ACCOUNT_AND_REFEREE_PROFESSIONAL.md) for the added account APIs, referee team-booking workflows, migration and build instructions, plus current verification boundaries.
