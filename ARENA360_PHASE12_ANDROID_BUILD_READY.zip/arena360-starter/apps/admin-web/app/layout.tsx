import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ARENA 360 — Admin',
  description: 'ARENA 360 удирдлагын систем',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="mn"><body>{children}</body></html>;
}
