'use client';

import { useState } from 'react';

type Metrics = {
  users: number; providersPending: number; refereesPending: number; activeVenues: number; bookings: number;
  competitions: number; courses: number; products: number; orders: number;
  pendingPayments: number; confirmedRevenueMnt: number; currency: string;
};
type RefereeAdmin = {
  id: string; displayName: string; sportTypes: string[]; status: string; federationName?: string | null;
  federationVerifiedAt?: string | null; experienceYears: number; region?: string | null; city?: string | null;
  district?: string | null; _count: { bookings: number; eventReports: number };
};
const API = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:3000/api/v1';
const tiles: { key: keyof Metrics; label: string; suffix?: string }[] = [
  { key: 'users', label: 'Нийт хэрэглэгч' }, { key: 'providersPending', label: 'Баталгаажуулах үйлчилгээ үзүүлэгч' },
  { key: 'refereesPending', label: 'Баталгаажуулах шүүгч' }, { key: 'activeVenues', label: 'Идэвхтэй заал' },
  { key: 'bookings', label: 'Заалны захиалга' }, { key: 'competitions', label: 'Тэмцээн' },
  { key: 'courses', label: 'Сургалт' }, { key: 'products', label: 'Спорт бараа' },
  { key: 'orders', label: 'Барааны захиалга' }, { key: 'pendingPayments', label: 'Хүлээгдэж буй төлбөр' },
  { key: 'confirmedRevenueMnt', label: 'Баталгаажсан орлого', suffix: '₮' },
];
export default function Home() {
  const [token, setToken] = useState('');
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [referees, setReferees] = useState<RefereeAdmin[]>([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function loadDashboard() {
    if (!token.trim()) { setError('Админы access token оруулна уу.'); return; }
    setLoading(true); setError('');
    try {
      const response = await fetch(`${API}/admin/dashboard`, { headers: { Authorization: `Bearer ${token.trim()}` }, cache: 'no-store' });
      const data = await response.json();
      if (!response.ok) throw new Error(Array.isArray(data.message) ? data.message.join(', ') : data.message || 'Мэдээлэл татахад алдаа гарлаа.');
      const refereeResponse = await fetch(`${API}/referees/admin/all`, { headers: { Authorization: `Bearer ${token.trim()}` }, cache: 'no-store' });
      const refereeData = await refereeResponse.json();
      if (!refereeResponse.ok) throw new Error(refereeData.message || 'Шүүгчийн жагсаалт татаж чадсангүй.');
      setMetrics(data as Metrics);
      setReferees(refereeData as RefereeAdmin[]);
    } catch (e) { setError(e instanceof Error ? e.message : 'Сервертэй холбогдож чадсангүй.'); setMetrics(null); }
    finally { setLoading(false); }
  }

  async function refereeAction(id: string, action: string, body?: object) {
    if (!token.trim()) return;
    try {
      const response = await fetch(`${API}/referees/admin/${id}/${action}`, {
        method: 'PATCH', headers: { Authorization: `Bearer ${token.trim()}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Үйлдэл амжилтгүй.');
      await loadDashboard();
    } catch (e) { setError(e instanceof Error ? e.message : 'Үйлдэл амжилтгүй.'); }
  }

  return <main className="wrap">
    <header><div className="mark">A360</div><div><h1>ARENA 360</h1><p>Админ удирдлагын самбар</p></div></header>
    <section className="hero"><span>ПЛАТФОРМЫН УДИРДЛАГА</span><h2>Спортын үйлчилгээг нэг дор.</h2><p>Хэрэглэгч, үйлчилгээ үзүүлэгч, тэмцээн, захиалга болон төлбөрийн нэгдсэн хяналт.</p></section>
    <section className="authPanel">
      <label htmlFor="adminToken">Админы access token</label>
      <input id="adminToken" type="password" autoComplete="off" placeholder="Bearer token" value={token} onChange={e => setToken(e.target.value)} />
      <button onClick={loadDashboard} disabled={loading}>{loading ? 'Уншиж байна…' : 'Dashboard мэдээлэл татах'}</button>
      <small>Token зөвхөн энэ дэлгэцийн санах ойд хадгалагдана. Browser storage-д бичихгүй.</small>
      {error && <p className="error">{error}</p>}
    </section>
    {metrics && <>
      <h3>ПЛАТФОРМЫН ҮЗҮҮЛЭЛТ</h3>
      <section className="grid">{tiles.map(tile => <article key={tile.key}><small>{tile.label}</small><b>{Number(metrics[tile.key]).toLocaleString('mn-MN')}{tile.suffix ? ` ${tile.suffix}` : ''}</b></article>)}</section>
      <h3>ШҮҮГЧИЙН МЭРГЭЖЛИЙН БҮРТГЭЛ</h3>
      <section className="grid">
        {referees.map(referee => <article key={referee.id}>
          <small>{referee.sportTypes.join(' · ')} · {referee.region || referee.city || 'Байршилгүй'}</small>
          <b>{referee.displayName}</b>
          <small>Төлөв: {referee.status} · Туршлага: {referee.experienceYears} жил</small>
          <small>Тэмцээн: {referee._count.bookings} · Тайлан: {referee._count.eventReports}</small>
          <small>Холбоо: {referee.federationName || 'Бүртгээгүй'} · {referee.federationVerifiedAt ? 'Баталгаажсан' : 'Баталгаажаагүй'}</small>
          <div className="actions">
            {referee.status === 'PENDING_ADMIN_REVIEW' && <><button onClick={() => refereeAction(referee.id, 'APPROVED')}>Зөвшөөрөх</button><button onClick={() => refereeAction(referee.id, 'REJECTED')}>Татгалзах</button></>}
            {referee.status === 'APPROVED' && !referee.federationVerifiedAt && <button onClick={() => refereeAction(referee.id, 'federation-verify')}>Холбоо баталгаажуулах</button>}
            {referee.status === 'APPROVED' && <button onClick={() => refereeAction(referee.id, 'suspend', { reason: 'Админы шийдвэр' })}>Эрх түдгэлзүүлэх</button>}
            {referee.status === 'SUSPENDED' && <button onClick={() => refereeAction(referee.id, 'restore')}>Эрх сэргээх</button>}
          </div>
        </article>)}
        {referees.length === 0 && <article><b>Шүүгчийн бүртгэл алга</b><small>Шинэ хүсэлт ирэхэд энд харагдана.</small></article>}
      </section>
    </>}
    {!metrics && <section className="grid"><article><b>Үйлчилгээ үзүүлэгч</b><small>Админ баталгаажуулалтын API холбогдсон</small></article><article><b>Тэмцээн, сугалаа</b><small>Тэмцээний удирдлагын API холбогдсон</small></article><article><b>Захиалга, төлбөр</b><small>Захиалгын бүртгэл ба pending төлбөрийн API холбогдсон</small></article></section>}
    <footer>ARENA 360 · Admin API · v0.7.0</footer>
  </main>;
}
