CREATE TYPE "CompetitionStatus" AS ENUM ('DRAFT', 'REGISTRATION_OPEN', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED');
CREATE TABLE "competitions" (
  "id" UUID NOT NULL, "owner_id" UUID NOT NULL, "title" VARCHAR(180) NOT NULL,
  "sport" VARCHAR(80) NOT NULL, "division" VARCHAR(100),
  "format" VARCHAR(32) NOT NULL DEFAULT 'SINGLE_ELIMINATION', "venue" VARCHAR(220),
  "starts_at" TIMESTAMP(3), "status" "CompetitionStatus" NOT NULL DEFAULT 'DRAFT',
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "competitions_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "competitions_owner_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE TABLE "competition_entrants" (
  "id" UUID NOT NULL, "competition_id" UUID NOT NULL, "name" VARCHAR(160) NOT NULL,
  "kind" VARCHAR(20) NOT NULL DEFAULT 'INDIVIDUAL', "club" VARCHAR(160), "seed" INTEGER, "registered_by_id" UUID,
  "registered_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "competition_entrants_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "competition_entrants_competition_id_fkey" FOREIGN KEY ("competition_id") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "competition_entrants_registered_by_fkey" FOREIGN KEY ("registered_by_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE TABLE "competition_matches" (
  "id" UUID NOT NULL, "competition_id" UUID NOT NULL, "round" INTEGER NOT NULL,
  "match_number" INTEGER NOT NULL, "entrant_a_id" UUID, "entrant_b_id" UUID,
  "score_a" INTEGER, "score_b" INTEGER, "winner_entrant_id" UUID,
  "scheduled_at" TIMESTAMP(3), "completed_at" TIMESTAMP(3),
  CONSTRAINT "competition_matches_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "competition_matches_competition_id_fkey" FOREIGN KEY ("competition_id") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "competition_matches_entrant_a_fkey" FOREIGN KEY ("entrant_a_id") REFERENCES "competition_entrants"("id") ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT "competition_matches_entrant_b_fkey" FOREIGN KEY ("entrant_b_id") REFERENCES "competition_entrants"("id") ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT "competition_matches_winner_fkey" FOREIGN KEY ("winner_entrant_id") REFERENCES "competition_entrants"("id") ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT "competition_matches_round_check" CHECK ("round" > 0),
  CONSTRAINT "competition_matches_number_check" CHECK ("match_number" > 0),
  CONSTRAINT "competition_matches_scores_check" CHECK (("score_a" IS NULL OR "score_a" >= 0) AND ("score_b" IS NULL OR "score_b" >= 0)),
  CONSTRAINT "competition_matches_winner_slot_check" CHECK ("winner_entrant_id" IS NULL OR "winner_entrant_id" = "entrant_a_id" OR "winner_entrant_id" = "entrant_b_id")
);
CREATE INDEX "competitions_status_starts_at_idx" ON "competitions"("status", "starts_at");
CREATE INDEX "competitions_owner_id_created_at_idx" ON "competitions"("owner_id", "created_at");
CREATE UNIQUE INDEX "competition_entrants_competition_id_name_key" ON "competition_entrants"("competition_id", "name");
CREATE INDEX "competition_entrants_competition_id_seed_idx" ON "competition_entrants"("competition_id", "seed");
CREATE UNIQUE INDEX "competition_matches_competition_id_round_match_number_key" ON "competition_matches"("competition_id", "round", "match_number");
CREATE INDEX "competition_matches_competition_id_round_idx" ON "competition_matches"("competition_id", "round");
