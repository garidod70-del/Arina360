ALTER TYPE "ProviderStatus" ADD VALUE IF NOT EXISTS 'SUSPENDED';

ALTER TABLE "users"
  ADD COLUMN "display_name" VARCHAR(160),
  ADD COLUMN "email" VARCHAR(254),
  ADD COLUMN "avatar_url" VARCHAR(1000),
  ADD COLUMN "city" VARCHAR(100),
  ADD COLUMN "district" VARCHAR(100);
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

ALTER TABLE "referee_profiles"
  ADD COLUMN "lodging_fee" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "federation_name" VARCHAR(180),
  ADD COLUMN "federation_verified_at" TIMESTAMP(3),
  ADD COLUMN "federation_document_url" VARCHAR(1000),
  ADD COLUMN "city" VARCHAR(100),
  ADD COLUMN "district" VARCHAR(100),
  ADD COLUMN "qr_token" VARCHAR(64),
  ADD COLUMN "suspended_at" TIMESTAMP(3),
  ADD COLUMN "suspension_reason" VARCHAR(500);
CREATE UNIQUE INDEX "referee_profiles_qr_token_key" ON "referee_profiles"("qr_token");

ALTER TABLE "referee_bookings"
  ADD COLUMN "service_fee_snapshot" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "travel_fee_snapshot" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "meal_fee_snapshot" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "lodging_fee_snapshot" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "group_id" UUID;

CREATE TABLE "favorites" (
  "id" UUID NOT NULL,
  "user_id" UUID NOT NULL,
  "target_type" VARCHAR(40) NOT NULL,
  "target_id" VARCHAR(80) NOT NULL,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "favorites_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "favorites_user_id_target_type_target_id_key" ON "favorites"("user_id", "target_type", "target_id");
CREATE INDEX "favorites_user_id_created_at_idx" ON "favorites"("user_id", "created_at");
ALTER TABLE "favorites" ADD CONSTRAINT "favorites_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "reviews" (
  "id" UUID NOT NULL,
  "user_id" UUID NOT NULL,
  "target_type" VARCHAR(40) NOT NULL,
  "target_id" VARCHAR(80) NOT NULL,
  "rating" INTEGER NOT NULL,
  "comment" VARCHAR(2000),
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "reviews_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "reviews_user_id_target_type_target_id_key" ON "reviews"("user_id", "target_type", "target_id");
CREATE INDEX "reviews_target_type_target_id_created_at_idx" ON "reviews"("target_type", "target_id", "created_at");
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "chat_conversations" (
  "id" UUID NOT NULL,
  "participant_a_id" UUID NOT NULL,
  "participant_b_id" UUID NOT NULL,
  "title" VARCHAR(180),
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "chat_conversations_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "chat_conversations_participant_a_id_updated_at_idx" ON "chat_conversations"("participant_a_id", "updated_at");
CREATE INDEX "chat_conversations_participant_b_id_updated_at_idx" ON "chat_conversations"("participant_b_id", "updated_at");
ALTER TABLE "chat_conversations" ADD CONSTRAINT "chat_conversations_participant_a_id_fkey" FOREIGN KEY ("participant_a_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "chat_conversations" ADD CONSTRAINT "chat_conversations_participant_b_id_fkey" FOREIGN KEY ("participant_b_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "chat_messages" (
  "id" UUID NOT NULL,
  "conversation_id" UUID NOT NULL,
  "sender_id" UUID NOT NULL,
  "body" VARCHAR(4000) NOT NULL,
  "read_at" TIMESTAMP(3),
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "chat_messages_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "chat_messages_conversation_id_created_at_idx" ON "chat_messages"("conversation_id", "created_at");
CREATE INDEX "chat_messages_sender_id_read_at_idx" ON "chat_messages"("sender_id", "read_at");
ALTER TABLE "chat_messages" ADD CONSTRAINT "chat_messages_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "chat_conversations"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "chat_messages" ADD CONSTRAINT "chat_messages_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "support_tickets" (
  "id" UUID NOT NULL,
  "user_id" UUID NOT NULL,
  "subject" VARCHAR(180) NOT NULL,
  "message" VARCHAR(4000) NOT NULL,
  "category" VARCHAR(40) NOT NULL DEFAULT 'GENERAL',
  "status" VARCHAR(20) NOT NULL DEFAULT 'OPEN',
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "support_tickets_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "support_tickets_user_id_created_at_idx" ON "support_tickets"("user_id", "created_at");
CREATE INDEX "support_tickets_status_created_at_idx" ON "support_tickets"("status", "created_at");
ALTER TABLE "support_tickets" ADD CONSTRAINT "support_tickets_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "referee_event_reports" (
  "id" UUID NOT NULL,
  "booking_id" UUID NOT NULL,
  "referee_id" UUID NOT NULL,
  "event_name" VARCHAR(180) NOT NULL,
  "tournament_level" VARCHAR(100) NOT NULL,
  "role" VARCHAR(100) NOT NULL,
  "notes" VARCHAR(3000),
  "submitted_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "referee_event_reports_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "referee_event_reports_booking_id_key" ON "referee_event_reports"("booking_id");
CREATE INDEX "referee_event_reports_referee_id_submitted_at_idx" ON "referee_event_reports"("referee_id", "submitted_at");
ALTER TABLE "referee_event_reports" ADD CONSTRAINT "referee_event_reports_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "referee_bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "referee_event_reports" ADD CONSTRAINT "referee_event_reports_referee_id_fkey" FOREIGN KEY ("referee_id") REFERENCES "referee_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
