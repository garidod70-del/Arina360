ALTER TABLE "payment_records" ADD COLUMN "provider_payment_id" VARCHAR(120);
CREATE UNIQUE INDEX "payment_records_provider_payment_id_key" ON "payment_records"("provider_payment_id");
