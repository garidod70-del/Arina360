CREATE EXTENSION IF NOT EXISTS btree_gist;

CREATE TYPE "BookingStatus" AS ENUM ('CONFIRMED', 'CANCELLED');

CREATE TABLE "venues" (
  "id" UUID NOT NULL,
  "provider_id" UUID NOT NULL,
  "name" VARCHAR(180) NOT NULL,
  "address" VARCHAR(300) NOT NULL,
  "description" VARCHAR(2000),
  "hourly_price" INTEGER NOT NULL,
  "capacity" INTEGER,
  "is_active" BOOLEAN NOT NULL DEFAULT true,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "venues_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "bookings" (
  "id" UUID NOT NULL,
  "venue_id" UUID NOT NULL,
  "user_id" UUID NOT NULL,
  "starts_at" TIMESTAMP(3) NOT NULL,
  "ends_at" TIMESTAMP(3) NOT NULL,
  "total_price" INTEGER NOT NULL,
  "status" "BookingStatus" NOT NULL DEFAULT 'CONFIRMED',
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "cancelled_at" TIMESTAMP(3),
  CONSTRAINT "bookings_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "bookings_valid_time_check" CHECK ("ends_at" > "starts_at"),
  CONSTRAINT "bookings_nonnegative_price_check" CHECK ("total_price" >= 0)
);

CREATE INDEX "venues_is_active_created_at_idx" ON "venues"("is_active", "created_at");
CREATE INDEX "venues_provider_id_idx" ON "venues"("provider_id");
CREATE INDEX "bookings_venue_id_starts_at_ends_at_status_idx" ON "bookings"("venue_id", "starts_at", "ends_at", "status");
CREATE INDEX "bookings_user_id_created_at_idx" ON "bookings"("user_id", "created_at");

ALTER TABLE "venues" ADD CONSTRAINT "venues_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_venue_id_fkey" FOREIGN KEY ("venue_id") REFERENCES "venues"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- Database-level guarantee: two confirmed bookings for the same venue cannot overlap.
ALTER TABLE "bookings"
  ADD CONSTRAINT "bookings_no_confirmed_overlap"
  EXCLUDE USING gist (
    "venue_id" WITH =,
    tsrange("starts_at", "ends_at", '[)') WITH &&
  ) WHERE ("status" = 'CONFIRMED');
