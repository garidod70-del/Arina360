CREATE TABLE "training_courses" (
  "id" UUID NOT NULL, "provider_id" UUID NOT NULL, "title" VARCHAR(180) NOT NULL,
  "sport" VARCHAR(80) NOT NULL, "description" VARCHAR(3000), "starts_at" TIMESTAMP(3),
  "ends_at" TIMESTAMP(3), "price" INTEGER NOT NULL DEFAULT 0, "capacity" INTEGER,
  "is_published" BOOLEAN NOT NULL DEFAULT false, "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "training_courses_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "training_courses_price_check" CHECK ("price" >= 0),
  CONSTRAINT "training_courses_capacity_check" CHECK ("capacity" IS NULL OR "capacity" > 0),
  CONSTRAINT "training_courses_time_check" CHECK ("ends_at" IS NULL OR "starts_at" IS NULL OR "ends_at" > "starts_at")
);
CREATE INDEX "training_courses_is_published_starts_at_idx" ON "training_courses"("is_published", "starts_at");
ALTER TABLE "training_courses" ADD CONSTRAINT "training_courses_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

CREATE TABLE "course_enrollments" (
  "id" UUID NOT NULL, "course_id" UUID NOT NULL, "user_id" UUID NOT NULL,
  "status" VARCHAR(20) NOT NULL DEFAULT 'ENROLLED', "certificate_id" VARCHAR(80),
  "completed_at" TIMESTAMP(3), "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "course_enrollments_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "course_enrollments_course_id_user_id_key" ON "course_enrollments"("course_id", "user_id");
CREATE UNIQUE INDEX "course_enrollments_certificate_id_key" ON "course_enrollments"("certificate_id");
CREATE INDEX "course_enrollments_user_id_created_at_idx" ON "course_enrollments"("user_id", "created_at");
ALTER TABLE "course_enrollments" ADD CONSTRAINT "course_enrollments_course_id_fkey" FOREIGN KEY ("course_id") REFERENCES "training_courses"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "course_enrollments" ADD CONSTRAINT "course_enrollments_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "fitness_centers" (
  "id" UUID NOT NULL, "provider_id" UUID NOT NULL, "name" VARCHAR(180) NOT NULL,
  "address" VARCHAR(300) NOT NULL, "description" VARCHAR(2000), "is_published" BOOLEAN NOT NULL DEFAULT false,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "fitness_centers_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "fitness_centers_is_published_created_at_idx" ON "fitness_centers"("is_published", "created_at");
ALTER TABLE "fitness_centers" ADD CONSTRAINT "fitness_centers_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

CREATE TABLE "fitness_plans" (
  "id" UUID NOT NULL, "center_id" UUID NOT NULL, "title" VARCHAR(120) NOT NULL,
  "duration_days" INTEGER NOT NULL, "price" INTEGER NOT NULL, "is_active" BOOLEAN NOT NULL DEFAULT true,
  CONSTRAINT "fitness_plans_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "fitness_plans_duration_check" CHECK ("duration_days" > 0),
  CONSTRAINT "fitness_plans_price_check" CHECK ("price" > 0)
);
CREATE INDEX "fitness_plans_center_id_is_active_idx" ON "fitness_plans"("center_id", "is_active");
ALTER TABLE "fitness_plans" ADD CONSTRAINT "fitness_plans_center_id_fkey" FOREIGN KEY ("center_id") REFERENCES "fitness_centers"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "fitness_memberships" (
  "id" UUID NOT NULL, "plan_id" UUID NOT NULL, "user_id" UUID NOT NULL,
  "starts_at" TIMESTAMP(3) NOT NULL, "expires_at" TIMESTAMP(3) NOT NULL,
  "status" VARCHAR(20) NOT NULL DEFAULT 'ACTIVE', "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "fitness_memberships_pkey" PRIMARY KEY ("id"), CONSTRAINT "fitness_memberships_dates_check" CHECK ("expires_at" > "starts_at")
);
CREATE INDEX "fitness_memberships_user_id_expires_at_idx" ON "fitness_memberships"("user_id", "expires_at");
ALTER TABLE "fitness_memberships" ADD CONSTRAINT "fitness_memberships_plan_id_fkey" FOREIGN KEY ("plan_id") REFERENCES "fitness_plans"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "fitness_memberships" ADD CONSTRAINT "fitness_memberships_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "verification_passes" (
  "id" UUID NOT NULL, "user_id" UUID NOT NULL, "pass_type" VARCHAR(30) NOT NULL,
  "reference_id" UUID NOT NULL, "token_hash" VARCHAR(64) NOT NULL, "expires_at" TIMESTAMP(3),
  "used_at" TIMESTAMP(3), "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "verification_passes_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "verification_passes_token_hash_key" ON "verification_passes"("token_hash");
CREATE INDEX "verification_passes_user_id_pass_type_idx" ON "verification_passes"("user_id", "pass_type");
ALTER TABLE "verification_passes" ADD CONSTRAINT "verification_passes_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "marketplace_products" (
  "id" UUID NOT NULL, "seller_id" UUID NOT NULL, "title" VARCHAR(180) NOT NULL,
  "category" VARCHAR(80) NOT NULL, "description" VARCHAR(2000), "price" INTEGER NOT NULL,
  "stock" INTEGER NOT NULL DEFAULT 0, "image_url" VARCHAR(1000), "is_published" BOOLEAN NOT NULL DEFAULT false,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "marketplace_products_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "marketplace_products_price_check" CHECK ("price" > 0), CONSTRAINT "marketplace_products_stock_check" CHECK ("stock" >= 0)
);
CREATE INDEX "marketplace_products_is_published_category_created_at_idx" ON "marketplace_products"("is_published", "category", "created_at");
ALTER TABLE "marketplace_products" ADD CONSTRAINT "marketplace_products_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

CREATE TABLE "marketplace_orders" (
  "id" UUID NOT NULL, "buyer_id" UUID NOT NULL, "total_amount" INTEGER NOT NULL,
  "status" VARCHAR(30) NOT NULL DEFAULT 'PENDING_PAYMENT', "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "marketplace_orders_pkey" PRIMARY KEY ("id"), CONSTRAINT "marketplace_orders_total_check" CHECK ("total_amount" > 0)
);
CREATE INDEX "marketplace_orders_buyer_id_created_at_idx" ON "marketplace_orders"("buyer_id", "created_at");
ALTER TABLE "marketplace_orders" ADD CONSTRAINT "marketplace_orders_buyer_id_fkey" FOREIGN KEY ("buyer_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

CREATE TABLE "marketplace_order_items" (
  "id" UUID NOT NULL, "order_id" UUID NOT NULL, "product_id" UUID NOT NULL,
  "quantity" INTEGER NOT NULL, "unit_price" INTEGER NOT NULL, CONSTRAINT "marketplace_order_items_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "marketplace_order_items_quantity_check" CHECK ("quantity" > 0), CONSTRAINT "marketplace_order_items_price_check" CHECK ("unit_price" > 0)
);
ALTER TABLE "marketplace_order_items" ADD CONSTRAINT "marketplace_order_items_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "marketplace_orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "marketplace_order_items" ADD CONSTRAINT "marketplace_order_items_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "marketplace_products"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

CREATE TABLE "payment_records" (
  "id" UUID NOT NULL, "user_id" UUID NOT NULL, "purpose" VARCHAR(40) NOT NULL,
  "reference_id" UUID NOT NULL, "amount" INTEGER NOT NULL, "currency" VARCHAR(3) NOT NULL DEFAULT 'MNT',
  "provider" VARCHAR(20) NOT NULL DEFAULT 'QPAY', "provider_invoice_id" VARCHAR(120),
  "status" VARCHAR(20) NOT NULL DEFAULT 'PENDING', "idempotency_key" VARCHAR(100) NOT NULL,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT "payment_records_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "payment_records_amount_check" CHECK ("amount" > 0)
);
CREATE UNIQUE INDEX "payment_records_provider_invoice_id_key" ON "payment_records"("provider_invoice_id");
CREATE UNIQUE INDEX "payment_records_idempotency_key_key" ON "payment_records"("idempotency_key");
CREATE INDEX "payment_records_user_id_created_at_idx" ON "payment_records"("user_id", "created_at");
ALTER TABLE "payment_records" ADD CONSTRAINT "payment_records_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

CREATE TABLE "user_notifications" (
  "id" UUID NOT NULL, "user_id" UUID NOT NULL, "title" VARCHAR(180) NOT NULL,
  "body" VARCHAR(1000) NOT NULL, "type" VARCHAR(30) NOT NULL DEFAULT 'GENERAL',
  "read_at" TIMESTAMP(3), "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "user_notifications_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "user_notifications_user_id_read_at_created_at_idx" ON "user_notifications"("user_id", "read_at", "created_at");
ALTER TABLE "user_notifications" ADD CONSTRAINT "user_notifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "sport_listings" (
  "id" UUID NOT NULL, "provider_id" UUID NOT NULL, "listing_type" VARCHAR(30) NOT NULL,
  "name" VARCHAR(180) NOT NULL, "sport" VARCHAR(80) NOT NULL, "description" VARCHAR(3000),
  "location" VARCHAR(240) NOT NULL, "age_group" VARCHAR(100), "level" VARCHAR(80),
  "coach_name" VARCHAR(160), "schedule" VARCHAR(1000), "fee" INTEGER NOT NULL DEFAULT 0,
  "capacity" INTEGER, "contact_phone" VARCHAR(20), "is_published" BOOLEAN NOT NULL DEFAULT false,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "sport_listings_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "sport_listings_fee_check" CHECK ("fee" >= 0),
  CONSTRAINT "sport_listings_capacity_check" CHECK ("capacity" IS NULL OR "capacity" > 0),
  CONSTRAINT "sport_listings_type_check" CHECK ("listing_type" IN ('REFEREE','CLUB','COACH'))
);
CREATE INDEX "sport_listings_is_published_listing_type_sport_location_idx" ON "sport_listings"("is_published", "listing_type", "sport", "location");
CREATE INDEX "sport_listings_provider_id_created_at_idx" ON "sport_listings"("provider_id", "created_at");
ALTER TABLE "sport_listings" ADD CONSTRAINT "sport_listings_provider_id_fkey" FOREIGN KEY ("provider_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

CREATE TABLE "service_inquiries" (
  "id" UUID NOT NULL, "listing_id" UUID NOT NULL, "user_id" UUID NOT NULL,
  "message" VARCHAR(1500) NOT NULL, "status" VARCHAR(20) NOT NULL DEFAULT 'PENDING',
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "service_inquiries_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "service_inquiries_listing_id_created_at_idx" ON "service_inquiries"("listing_id", "created_at");
CREATE INDEX "service_inquiries_user_id_created_at_idx" ON "service_inquiries"("user_id", "created_at");
ALTER TABLE "service_inquiries" ADD CONSTRAINT "service_inquiries_listing_id_fkey" FOREIGN KEY ("listing_id") REFERENCES "sport_listings"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "service_inquiries" ADD CONSTRAINT "service_inquiries_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
