CREATE TABLE "marketplace_commissions" (
  "id" UUID NOT NULL,
  "order_id" UUID NOT NULL,
  "gross_amount" INTEGER NOT NULL,
  "rate_bps" INTEGER NOT NULL DEFAULT 500,
  "amount" INTEGER NOT NULL,
  "status" VARCHAR(20) NOT NULL DEFAULT 'ACCRUED',
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "marketplace_commissions_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "marketplace_commissions_order_id_key" ON "marketplace_commissions"("order_id");
CREATE INDEX "marketplace_commissions_status_created_at_idx" ON "marketplace_commissions"("status", "created_at");

CREATE TABLE "marketplace_refunds" (
  "id" UUID NOT NULL,
  "order_id" UUID NOT NULL,
  "buyer_id" UUID NOT NULL,
  "reason" VARCHAR(1000) NOT NULL,
  "amount" INTEGER NOT NULL,
  "status" VARCHAR(20) NOT NULL DEFAULT 'REQUESTED',
  "provider_refund_id" VARCHAR(120),
  "reviewed_by" UUID,
  "reviewed_at" TIMESTAMP(3),
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "marketplace_refunds_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "marketplace_refunds_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "marketplace_orders"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT "marketplace_refunds_buyer_id_fkey" FOREIGN KEY ("buyer_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "marketplace_refunds_order_id_key" ON "marketplace_refunds"("order_id");
CREATE UNIQUE INDEX "marketplace_refunds_provider_refund_id_key" ON "marketplace_refunds"("provider_refund_id");
CREATE INDEX "marketplace_refunds_order_id_status_idx" ON "marketplace_refunds"("order_id", "status");
CREATE INDEX "marketplace_refunds_buyer_id_created_at_idx" ON "marketplace_refunds"("buyer_id", "created_at");
