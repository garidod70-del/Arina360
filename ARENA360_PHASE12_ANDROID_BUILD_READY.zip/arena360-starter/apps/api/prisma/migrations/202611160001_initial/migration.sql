CREATE TYPE "UserRole" AS ENUM ('USER', 'PROVIDER', 'ADMIN');
CREATE TYPE "ProviderStatus" AS ENUM ('PENDING_ADMIN_REVIEW', 'APPROVED', 'REJECTED');

CREATE TABLE "users" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "phone" VARCHAR(20) NOT NULL,
  "password_hash" TEXT NOT NULL,
  "role" "UserRole" NOT NULL DEFAULT 'USER',
  "is_active" BOOLEAN NOT NULL DEFAULT true,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "users_phone_key" ON "users"("phone");

CREATE TABLE "provider_applications" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "organization_name" VARCHAR(180) NOT NULL,
  "phone" VARCHAR(20) NOT NULL,
  "provider_type" VARCHAR(32) NOT NULL,
  "description" VARCHAR(2000),
  "status" "ProviderStatus" NOT NULL DEFAULT 'PENDING_ADMIN_REVIEW',
  "submitted_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "reviewed_at" TIMESTAMP(3),
  "reviewed_by" UUID,
  CONSTRAINT "provider_applications_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "provider_applications_status_submitted_at_idx" ON "provider_applications"("status", "submitted_at");
