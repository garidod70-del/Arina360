-- Link provider applications to authenticated accounts and retain admin review history.
-- Phone-based matching preserves existing rows where the old submitted phone matches a user.
ALTER TABLE "provider_applications" ADD COLUMN IF NOT EXISTS "user_id" UUID;
UPDATE "provider_applications" AS application
SET "user_id" = account."id"
FROM "users" AS account
WHERE application."user_id" IS NULL
  AND regexp_replace(application."phone", '[[:space:]()-]', '', 'g') = account."phone";

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM "provider_applications" WHERE "user_id" IS NULL) THEN
    RAISE EXCEPTION 'ARENA360 migration blocked: one or more provider applications do not match a user phone. Manually set provider_applications.user_id to the verified account UUID, then rerun.';
  END IF;
  IF EXISTS (
    SELECT 1 FROM "provider_applications" application
    LEFT JOIN "users" reviewer ON reviewer."id" = application."reviewed_by"
    WHERE application."reviewed_by" IS NOT NULL AND reviewer."id" IS NULL
  ) THEN
    RAISE EXCEPTION 'ARENA360 migration blocked: one or more reviewed_by values do not match an admin account. Reconcile them before retrying.';
  END IF;
END $$;

ALTER TABLE "provider_applications" ALTER COLUMN "user_id" SET NOT NULL;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'provider_applications_user_id_fkey') THEN
    ALTER TABLE "provider_applications" ADD CONSTRAINT "provider_applications_user_id_fkey"
      FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'provider_applications_reviewed_by_fkey') THEN
    ALTER TABLE "provider_applications" ADD CONSTRAINT "provider_applications_reviewed_by_fkey"
      FOREIGN KEY ("reviewed_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
  END IF;
END $$;
CREATE UNIQUE INDEX IF NOT EXISTS "provider_applications_user_id_provider_type_key"
  ON "provider_applications"("user_id", "provider_type");

CREATE TABLE IF NOT EXISTS "admin_audit_logs" (
  "id" UUID NOT NULL DEFAULT gen_random_uuid(),
  "admin_id" UUID NOT NULL,
  "action" VARCHAR(80) NOT NULL,
  "entity_id" UUID NOT NULL,
  "details" JSONB,
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "admin_audit_logs_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "admin_audit_logs_admin_id_fkey" FOREIGN KEY ("admin_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "admin_audit_logs_admin_id_created_at_idx" ON "admin_audit_logs"("admin_id", "created_at");
CREATE INDEX IF NOT EXISTS "admin_audit_logs_entity_id_idx" ON "admin_audit_logs"("entity_id");
