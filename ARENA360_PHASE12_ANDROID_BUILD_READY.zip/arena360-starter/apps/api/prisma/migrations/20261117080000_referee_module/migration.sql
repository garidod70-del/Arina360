CREATE TYPE "RefereeBookingStatus" AS ENUM ('REQUESTED', 'ACCEPTED', 'REJECTED', 'CANCELLED', 'COMPLETED');

CREATE TABLE "referee_profiles" (
  "id" UUID NOT NULL,
  "user_id" UUID NOT NULL,
  "display_name" VARCHAR(160) NOT NULL,
  "sport_types" TEXT[] NOT NULL,
  "rank" VARCHAR(100),
  "license_number" VARCHAR(100),
  "license_expires_at" TIMESTAMP(3),
  "experience_years" INTEGER NOT NULL DEFAULT 0,
  "region" VARCHAR(120),
  "bio" VARCHAR(2000),
  "service_fee" INTEGER NOT NULL DEFAULT 0,
  "travel_fee" INTEGER NOT NULL DEFAULT 0,
  "meal_fee" INTEGER NOT NULL DEFAULT 0,
  "availability" JSONB,
  "status" "ProviderStatus" NOT NULL DEFAULT 'PENDING_ADMIN_REVIEW',
  "verified_at" TIMESTAMP(3),
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "referee_profiles_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "referee_profiles_user_id_key" ON "referee_profiles"("user_id");
CREATE INDEX "referee_profiles_status_region_idx" ON "referee_profiles"("status", "region");
CREATE INDEX "referee_profiles_sport_types_idx" ON "referee_profiles" USING GIN ("sport_types");
ALTER TABLE "referee_profiles" ADD CONSTRAINT "referee_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "referee_bookings" (
  "id" UUID NOT NULL,
  "referee_id" UUID NOT NULL,
  "customer_id" UUID NOT NULL,
  "starts_at" TIMESTAMP(3) NOT NULL,
  "ends_at" TIMESTAMP(3) NOT NULL,
  "location" VARCHAR(300) NOT NULL,
  "sport" VARCHAR(80) NOT NULL,
  "notes" VARCHAR(1000),
  "total_price" INTEGER NOT NULL,
  "status" "RefereeBookingStatus" NOT NULL DEFAULT 'REQUESTED',
  "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updated_at" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "referee_bookings_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "referee_bookings_referee_id_starts_at_ends_at_status_idx" ON "referee_bookings"("referee_id", "starts_at", "ends_at", "status");
CREATE INDEX "referee_bookings_customer_id_created_at_idx" ON "referee_bookings"("customer_id", "created_at");
ALTER TABLE "referee_bookings" ADD CONSTRAINT "referee_bookings_referee_id_fkey" FOREIGN KEY ("referee_id") REFERENCES "referee_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
ALTER TABLE "referee_bookings" ADD CONSTRAINT "referee_bookings_customer_id_fkey" FOREIGN KEY ("customer_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
