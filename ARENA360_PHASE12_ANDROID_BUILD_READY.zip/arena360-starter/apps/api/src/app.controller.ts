import { Controller, Get } from '@nestjs/common';
import { PrismaService } from './database/prisma.service';

@Controller()
export class AppController {
  constructor(private readonly db: PrismaService) {}
  @Get('health')
  health() {
    return { app: 'ARENA 360 API', status: 'ok', version: '0.7.0', environment: process.env.NODE_ENV || 'development' };
  }
  @Get('health/ready')
  async readiness() {
    await this.db.$queryRaw`SELECT 1`;
    return { app: 'ARENA 360 API', status: 'ready', database: 'connected', version: '0.7.0' };
  }
}
