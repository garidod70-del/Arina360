import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { ProviderStatus } from '@prisma/client';
import { PrismaService } from '../database/prisma.service';
import { ProviderApplicationDto } from './dto/provider-application.dto';

@Injectable()
export class ProvidersService {
  constructor(private readonly db: PrismaService) {}

  async submit(input: ProviderApplicationDto, userId: string) {
    const user = await this.db.user.findUnique({ where: { id: userId }, select: { id: true, phone: true, isActive: true } });
    if (!user || !user.isActive) throw new NotFoundException('Хэрэглэгчийн бүртгэл олдсонгүй.');

    const existing = await this.db.providerApplication.findUnique({
      where: { userId_providerType: { userId, providerType: input.providerType } },
      select: { id: true, status: true },
    });
    if (existing && existing.status !== 'REJECTED') {
      throw new ConflictException('Энэ үйлчилгээний төрлөөр хүсэлт өмнө нь илгээгдсэн байна.');
    }

    const application = existing
      ? await this.db.providerApplication.update({
          where: { id: existing.id },
          data: { organizationName: input.organizationName.trim(), phone: user.phone, description: input.description?.trim(), status: 'PENDING_ADMIN_REVIEW', submittedAt: new Date(), reviewedAt: null, reviewedBy: null },
          select: { id: true, status: true, submittedAt: true },
        })
      : await this.db.providerApplication.create({
          data: { userId, organizationName: input.organizationName.trim(), phone: user.phone, providerType: input.providerType, description: input.description?.trim() },
          select: { id: true, status: true, submittedAt: true },
        });

    return { ...application, message: 'Хүсэлт хүлээн авлаа. Админ баталгаажуулах хүртэл нийтэд харагдахгүй.' };
  }

  mine(userId: string) {
    return this.db.providerApplication.findMany({
      where: { userId },
      orderBy: { submittedAt: 'desc' },
      select: { id: true, organizationName: true, providerType: true, status: true, submittedAt: true, reviewedAt: true },
    });
  }

  auditLogs() {
    return this.db.adminAuditLog.findMany({
      take: 100,
      orderBy: { createdAt: 'desc' },
      select: { id: true, adminId: true, action: true, entityId: true, details: true, createdAt: true, admin: { select: { phone: true } } },
    });
  }

  pending() {
    return this.db.providerApplication.findMany({
      where: { status: 'PENDING_ADMIN_REVIEW' },
      orderBy: { submittedAt: 'asc' },
      select: { id: true, organizationName: true, phone: true, providerType: true, description: true, submittedAt: true, userId: true },
    });
  }

  async review(id: string, adminId: string, status: Extract<ProviderStatus, 'APPROVED' | 'REJECTED'>) {
    return this.db.$transaction(async (tx) => {
      const application = await tx.providerApplication.findUnique({ where: { id }, select: { id: true, userId: true, status: true, organizationName: true } });
      if (!application) throw new NotFoundException('Үйлчилгээ үзүүлэгчийн хүсэлт олдсонгүй.');
      if (application.status !== 'PENDING_ADMIN_REVIEW') {
        throw new ConflictException('Энэ хүсэлтийг өмнө нь шийдвэрлэсэн байна.');
      }
      const changed = await tx.providerApplication.updateMany({
        where: { id, status: 'PENDING_ADMIN_REVIEW' },
        data: { status, reviewedAt: new Date(), reviewedBy: adminId },
      });
      if (changed.count !== 1) {
        throw new ConflictException('Энэ хүсэлтийг өөр админ аль хэдийн шийдвэрлэж байна.');
      }
      const updated = await tx.providerApplication.findUniqueOrThrow({
        where: { id },
        select: { id: true, organizationName: true, status: true, reviewedAt: true, userId: true },
      });
      if (status === 'APPROVED') {
        await tx.user.update({ where: { id: application.userId }, data: { role: 'PROVIDER' } });
      }
      await tx.adminAuditLog.create({
        data: { adminId, action: status === 'APPROVED' ? 'PROVIDER_APPLICATION_APPROVED' : 'PROVIDER_APPLICATION_REJECTED', entityId: id, details: { organizationName: application.organizationName, providerUserId: application.userId } },
      });
      return updated;
    });
  }
}
