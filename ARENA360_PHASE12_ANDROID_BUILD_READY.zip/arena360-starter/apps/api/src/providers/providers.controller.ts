import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { AdminRoleGuard } from '../auth/roles.guard';
import { ProviderApplicationDto } from './dto/provider-application.dto';
import { ProvidersService } from './providers.service';

interface AuthenticatedRequest { user: { sub: string } }

@Controller('providers')
export class ProvidersController {
  constructor(private readonly providers: ProvidersService) {}

  @Post('applications')
  @UseGuards(AuthGuard)
  submitApplication(@Body() body: ProviderApplicationDto, @Req() request: AuthenticatedRequest) {
    return this.providers.submit(body, request.user.sub);
  }

  @Get('applications/mine')
  @UseGuards(AuthGuard)
  myApplications(@Req() request: AuthenticatedRequest) {
    return this.providers.mine(request.user.sub);
  }

  @Get('admin/audit-logs')
  @UseGuards(AuthGuard, AdminRoleGuard)
  auditLogs() {
    return this.providers.auditLogs();
  }

  @Get('applications/pending')
  @UseGuards(AuthGuard, AdminRoleGuard)
  pendingApplications() {
    return this.providers.pending();
  }

  @Patch('applications/:id/approve')
  @UseGuards(AuthGuard, AdminRoleGuard)
  approve(@Param('id') id: string, @Req() request: AuthenticatedRequest) {
    return this.providers.review(id, request.user.sub, 'APPROVED');
  }

  @Patch('applications/:id/reject')
  @UseGuards(AuthGuard, AdminRoleGuard)
  reject(@Param('id') id: string, @Req() request: AuthenticatedRequest) {
    return this.providers.review(id, request.user.sub, 'REJECTED');
  }
}
