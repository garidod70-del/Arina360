import { IsIn, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';

const PROVIDER_TYPES: string[] = ['REFEREE', 'CLUB', 'COMPETITION', 'VENUE', 'SHOP', 'EDUCATION', 'FITNESS'];

export class ProviderApplicationDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(180)
  organizationName!: string;

  @IsIn(PROVIDER_TYPES)
  providerType!: string;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  description?: string;
}
