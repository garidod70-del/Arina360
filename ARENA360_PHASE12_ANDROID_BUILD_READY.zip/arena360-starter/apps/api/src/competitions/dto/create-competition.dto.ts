import { IsDateString, IsIn, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class CreateCompetitionDto {
  @IsString() @MinLength(3) @MaxLength(180) title!: string;
  @IsString() @MinLength(2) @MaxLength(80) sport!: string;
  @IsOptional() @IsString() @MaxLength(100) division?: string;
  @IsOptional() @IsString() @MaxLength(220) venue?: string;
  @IsOptional() @IsDateString() startsAt?: string;
  @IsOptional() @IsIn(['SINGLE_ELIMINATION', 'ROUND_ROBIN']) format?: 'SINGLE_ELIMINATION' | 'ROUND_ROBIN';
}
