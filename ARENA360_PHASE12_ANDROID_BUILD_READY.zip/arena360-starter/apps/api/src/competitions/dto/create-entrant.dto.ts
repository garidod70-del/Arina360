import { IsIn, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';

export class CreateEntrantDto {
  @IsString() @MinLength(2) @MaxLength(160) name!: string;
  @IsOptional() @IsIn(['INDIVIDUAL', 'TEAM']) kind?: 'INDIVIDUAL' | 'TEAM';
  @IsOptional() @IsString() @MaxLength(160) club?: string;
}
