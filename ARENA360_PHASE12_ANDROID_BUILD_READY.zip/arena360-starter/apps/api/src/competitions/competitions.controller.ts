import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { CompetitionsService } from './competitions.service';
import { CreateCompetitionDto } from './dto/create-competition.dto';
import { CreateEntrantDto } from './dto/create-entrant.dto';
import { RecordResultDto } from './dto/record-result.dto';

interface RequestWithUser { user: { sub: string; role: string } }

@Controller('competitions')
export class CompetitionsController {
  constructor(private readonly competitions: CompetitionsService) {}

  @Get() list() { return this.competitions.list(); }
  @Get(':id') details(@Param('id') id: string) { return this.competitions.details(id); }

  @Post()
  @UseGuards(AuthGuard)
  create(@Body() body: CreateCompetitionDto, @Req() req: RequestWithUser) { return this.competitions.create(body, req.user); }

  @Post(':id/registration/open')
  @UseGuards(AuthGuard)
  openRegistration(@Param('id') id: string, @Req() req: RequestWithUser) { return this.competitions.openRegistration(id, req.user); }

  @Post(':id/entrants')
  @UseGuards(AuthGuard)
  register(@Param('id') id: string, @Body() body: CreateEntrantDto, @Req() req: RequestWithUser) { return this.competitions.register(id, body, req.user.sub); }

  @Post(':id/bracket/generate')
  @UseGuards(AuthGuard)
  generateBracket(@Param('id') id: string, @Req() req: RequestWithUser) { return this.competitions.start(id, req.user); }

  @Patch(':id/matches/:matchId/result')
  @UseGuards(AuthGuard)
  result(@Param('id') id: string, @Param('matchId') matchId: string, @Body() body: RecordResultDto, @Req() req: RequestWithUser) { return this.competitions.recordResult(id, matchId, body, req.user); }
}
