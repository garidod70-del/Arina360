import { BadRequestException, ForbiddenException, Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { randomInt, randomUUID } from 'node:crypto';
import { PrismaService } from '../database/prisma.service';
import { CreateCompetitionDto } from './dto/create-competition.dto';
import { CreateEntrantDto } from './dto/create-entrant.dto';
import { RecordResultDto } from './dto/record-result.dto';

type Actor = { sub: string; role: string };
type BracketMatch = { id: string; competitionId: string; round: number; matchNumber: number; entrantAId: string | null; entrantBId: string | null; scoreA: number | null; scoreB: number | null; winnerEntrantId: string | null; completedAt: Date | null };

@Injectable()
export class CompetitionsService {
  constructor(private readonly db: PrismaService) {}

  async list() {
    return this.db.competition.findMany({
      where: { status: { in: ['REGISTRATION_OPEN', 'IN_PROGRESS', 'COMPLETED'] } },
      orderBy: [{ startsAt: 'asc' }, { createdAt: 'desc' }],
      include: { _count: { select: { entrants: true, matches: true } } },
    });
  }

  async create(dto: CreateCompetitionDto, actor: Actor) {
    if (!['PROVIDER', 'ADMIN'].includes(actor.role)) throw new ForbiddenException('Тэмцээн үүсгэхийн тулд баталгаажсан үйлчилгээ үзүүлэгч байх шаардлагатай.');
    return this.db.competition.create({
      data: { ownerId: actor.sub, title: dto.title.trim(), sport: dto.sport.trim(), division: dto.division?.trim(), venue: dto.venue?.trim(), startsAt: dto.startsAt ? new Date(dto.startsAt) : undefined, format: dto.format ?? 'SINGLE_ELIMINATION' },
    });
  }

  async openRegistration(id: string, actor: Actor) {
    const competition = await this.ownedCompetition(id, actor);
    if (competition.status !== 'DRAFT') throw new ConflictException('Зөвхөн ноорог тэмцээний бүртгэлийг нээж болно.');
    return this.db.competition.update({ where: { id }, data: { status: 'REGISTRATION_OPEN' } });
  }

  async register(id: string, dto: CreateEntrantDto, userId: string) {
    const competition = await this.db.competition.findUnique({ where: { id } });
    if (!competition) throw new NotFoundException('Тэмцээн олдсонгүй.');
    if (competition.status !== 'REGISTRATION_OPEN') throw new ConflictException('Энэ тэмцээний бүртгэл нээлттэй биш байна.');
    try {
      return await this.db.competitionEntrant.create({
        data: { competitionId: id, registeredById: userId, name: dto.name.trim(), kind: dto.kind ?? 'INDIVIDUAL', club: dto.club?.trim() },
      });
    } catch (error) {
      if ((error as { code?: string }).code === 'P2002') throw new ConflictException('Ижил нэртэй оролцогч бүртгэгдсэн байна.');
      throw error;
    }
  }

  async start(id: string, actor: Actor) {
    await this.ownedCompetition(id, actor);
    return this.db.$transaction(async (tx) => {
      const competition = await tx.competition.findUnique({ where: { id } });
      if (!competition) throw new NotFoundException('Тэмцээн олдсонгүй.');
      if (competition.status !== 'REGISTRATION_OPEN') throw new ConflictException('Тэмцээний бүртгэл нээлттэй үед сугалаа үүсгэнэ.');
      const entrants = await tx.competitionEntrant.findMany({ where: { competitionId: id } });
      if (entrants.length < 2) throw new BadRequestException('Сугалаа үүсгэхэд дор хаяж 2 оролцогч шаардлагатай.');
      if (entrants.some((e) => e.seed !== null)) entrants.sort((a, b) => (a.seed ?? Number.MAX_SAFE_INTEGER) - (b.seed ?? Number.MAX_SAFE_INTEGER));
      else this.shuffle(entrants);

      if (competition.format === 'ROUND_ROBIN') {
        const rotating: (typeof entrants[number] | null)[] = [...entrants];
        if (rotating.length % 2) rotating.push(null);
        const roundRobinMatches: BracketMatch[] = [];
        const rounds = rotating.length - 1;
        for (let round = 1; round <= rounds; round++) {
          let matchNumber = 1;
          for (let i = 0; i < rotating.length / 2; i++) {
            const a = rotating[i];
            const b = rotating[rotating.length - 1 - i];
            if (!a || !b) continue;
            roundRobinMatches.push({ id: randomUUID(), competitionId: id, round, matchNumber: matchNumber++, entrantAId: a.id, entrantBId: b.id, scoreA: null, scoreB: null, winnerEntrantId: null, completedAt: null });
          }
          const last = rotating.pop()!;
          rotating.splice(1, 0, last);
        }
        await tx.competitionMatch.createMany({ data: roundRobinMatches });
        await tx.competition.update({ where: { id }, data: { status: 'IN_PROGRESS' } });
        return { competitionId: id, format: 'ROUND_ROBIN', entrants: entrants.length, rounds, matches: roundRobinMatches };
      }

      const size = 2 ** Math.ceil(Math.log2(entrants.length));
      const totalRounds = Math.log2(size);
      const byeCount = size - entrants.length;
      const matches: BracketMatch[] = [];
      let previousWinners: (string | null)[] = [];
      for (let round = 1; round <= totalRounds; round++) {
        const count = size / (2 ** round);
        const currentWinners: (string | null)[] = [];
        for (let n = 1; n <= count; n++) {
          let a: string | null = null;
          let b: string | null = null;
          if (round === 1) {
            // Allocate one-player bye matches first; never create an empty first-round match.
            const entrantIndex = n <= byeCount ? n - 1 : byeCount + (n - byeCount - 1) * 2;
            a = entrants[entrantIndex]?.id ?? null;
            b = n <= byeCount ? null : (entrants[entrantIndex + 1]?.id ?? null);
          } else {
            a = previousWinners[(n - 1) * 2] ?? null;
            b = previousWinners[(n - 1) * 2 + 1] ?? null;
          }
          // Only first-round missing opponents are real byes. Later null slots mean an upstream match is still pending.
          const winner = round === 1 && a && !b ? a : round === 1 && b && !a ? b : null;
          currentWinners.push(winner);
          matches.push({ id: randomUUID(), competitionId: id, round, matchNumber: n, entrantAId: a, entrantBId: b, scoreA: null, scoreB: null, winnerEntrantId: winner, completedAt: winner ? new Date() : null });
        }
        previousWinners = currentWinners;
      }
      await tx.competitionMatch.createMany({ data: matches });
      const finalWinner = matches[matches.length - 1]?.winnerEntrantId;
      await tx.competition.update({ where: { id }, data: { status: finalWinner ? 'COMPLETED' : 'IN_PROGRESS' } });
      return { competitionId: id, entrants: entrants.length, bracketSize: size, rounds: totalRounds, matches };
    }, { isolationLevel: 'Serializable' });
  }

  async recordResult(id: string, matchId: string, dto: RecordResultDto, actor: Actor) {
    await this.ownedCompetition(id, actor);
    return this.db.$transaction(async (tx) => {
      const competition = await tx.competition.findUnique({ where: { id } });
      if (!competition || competition.status !== 'IN_PROGRESS') throw new ConflictException('Тэмцээн үр дүн бүртгэх төлөвт байхгүй байна.');
      const match = await tx.competitionMatch.findFirst({ where: { id: matchId, competitionId: id } });
      if (!match) throw new NotFoundException('Тоглолт олдсонгүй.');
      if (match.winnerEntrantId) throw new ConflictException('Энэ тоглолтын ялагч аль хэдийн баталгаажсан.');
      if (!match.entrantAId || !match.entrantBId) throw new ConflictException('Хоёр оролцогч тодорхой болоогүй байна.');
      if (dto.winnerEntrantId !== match.entrantAId && dto.winnerEntrantId !== match.entrantBId) throw new BadRequestException('Ялагч нь тухайн тоглолтын оролцогч байх ёстой.');
      if (dto.scoreA === dto.scoreB) throw new BadRequestException('Хасагдах шатанд тэнцсэн оноо бүртгэх боломжгүй.');
      const scoreWinner = dto.scoreA > dto.scoreB ? match.entrantAId : match.entrantBId;
      if (scoreWinner !== dto.winnerEntrantId) throw new BadRequestException('Ялагч болон онооны дүн хоорондоо зөрж байна.');
      const updated = await tx.competitionMatch.update({ where: { id: matchId }, data: { scoreA: dto.scoreA, scoreB: dto.scoreB, winnerEntrantId: dto.winnerEntrantId, completedAt: new Date() } });
      if (competition.format === 'ROUND_ROBIN') {
        const remaining = await tx.competitionMatch.count({ where: { competitionId: id, winnerEntrantId: null } });
        if (remaining === 0) await tx.competition.update({ where: { id }, data: { status: 'COMPLETED' } });
        return updated;
      }
      const nextRound = match.round + 1;
      const nextNumber = Math.ceil(match.matchNumber / 2);
      const next = await tx.competitionMatch.findFirst({ where: { competitionId: id, round: nextRound, matchNumber: nextNumber } });
      if (next) {
        const isA = match.matchNumber % 2 === 1;
        await tx.competitionMatch.update({ where: { id: next.id }, data: isA ? { entrantAId: dto.winnerEntrantId } : { entrantBId: dto.winnerEntrantId } });
      } else {
        await tx.competition.update({ where: { id }, data: { status: 'COMPLETED' } });
      }
      return updated;
    }, { isolationLevel: 'Serializable' });
  }

  async details(id: string) {
    const competition = await this.db.competition.findUnique({
      where: { id }, include: { entrants: { orderBy: [{ seed: 'asc' }, { registeredAt: 'asc' }] }, matches: { orderBy: [{ round: 'asc' }, { matchNumber: 'asc' }] } },
    });
    if (!competition) throw new NotFoundException('Тэмцээн олдсонгүй.');
    const entrantNames = new Map(competition.entrants.map((e) => [e.id, e.name]));
    if (competition.format === 'ROUND_ROBIN') {
      const standings = new Map(competition.entrants.map((entrant) => [entrant.id, { entrantId: entrant.id, name: entrant.name, played: 0, wins: 0, pointsFor: 0, pointsAgainst: 0 }]));
      for (const match of competition.matches) {
        if (!match.winnerEntrantId || !match.entrantAId || !match.entrantBId || match.scoreA === null || match.scoreB === null) continue;
        const a = standings.get(match.entrantAId)!; const b = standings.get(match.entrantBId)!;
        a.played++; b.played++; a.pointsFor += match.scoreA; a.pointsAgainst += match.scoreB; b.pointsFor += match.scoreB; b.pointsAgainst += match.scoreA;
        if (match.winnerEntrantId === a.entrantId) a.wins++; else b.wins++;
      }
      const ranking = [...standings.values()].sort((a, b) => b.wins - a.wins || (b.pointsFor - b.pointsAgainst) - (a.pointsFor - a.pointsAgainst) || b.pointsFor - a.pointsFor || a.name.localeCompare(b.name));
      return { ...competition, matches: competition.matches.map((m) => ({ ...m, entrantAName: m.entrantAId ? entrantNames.get(m.entrantAId) : null, entrantBName: m.entrantBId ? entrantNames.get(m.entrantBId) : null, winnerName: m.winnerEntrantId ? entrantNames.get(m.winnerEntrantId) : null })), standings: ranking, podium: competition.status === 'COMPLETED' ? { gold: ranking[0]?.name ?? null, silver: ranking[1]?.name ?? null, bronze: ranking[2]?.name ?? null } : null };
    }
    const finalRound = Math.max(0, ...competition.matches.map((x) => x.round));
    const final = competition.matches.find((m) => m.round === finalRound);
    const semiFinals = competition.matches.filter((m) => m.round === finalRound - 1 && m.winnerEntrantId && m.entrantAId && m.entrantBId);
    const bronze = semiFinals.map((m) => m.winnerEntrantId === m.entrantAId ? m.entrantBId : m.entrantAId).filter((entrantId): entrantId is string => Boolean(entrantId)).map((entrantId) => entrantNames.get(entrantId)).filter((name): name is string => Boolean(name));
    return {
      ...competition,
      matches: competition.matches.map((m) => ({ ...m, entrantAName: m.entrantAId ? entrantNames.get(m.entrantAId) : null, entrantBName: m.entrantBId ? entrantNames.get(m.entrantBId) : null, winnerName: m.winnerEntrantId ? entrantNames.get(m.winnerEntrantId) : null })),
      podium: final?.winnerEntrantId ? { gold: entrantNames.get(final.winnerEntrantId) ?? null, silver: final.entrantAId && final.entrantBId ? entrantNames.get(final.winnerEntrantId === final.entrantAId ? final.entrantBId : final.entrantAId) ?? null : null, bronze: competition.status === 'COMPLETED' ? bronze : [] } : null,
    };
  }

  private async ownedCompetition(id: string, actor: Actor) {
    const competition = await this.db.competition.findUnique({ where: { id } });
    if (!competition) throw new NotFoundException('Тэмцээн олдсонгүй.');
    if (competition.ownerId !== actor.sub && actor.role !== 'ADMIN') throw new ForbiddenException('Зөвхөн тэмцээн зохион байгуулагч энэ үйлдлийг хийх эрхтэй.');
    return competition;
  }

  private shuffle<T>(items: T[]) {
    for (let i = items.length - 1; i > 0; i--) {
      const j = randomInt(i + 1);
      [items[i], items[j]] = [items[j], items[i]];
    }
  }
}
