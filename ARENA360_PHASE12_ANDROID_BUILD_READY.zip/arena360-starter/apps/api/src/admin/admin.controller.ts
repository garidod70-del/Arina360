import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { AdminRoleGuard } from '../auth/roles.guard';
import { AdminService } from './admin.service';
@Controller('admin')
@UseGuards(AuthGuard, AdminRoleGuard)
export class AdminController {
  constructor(private readonly admin: AdminService) {}
  @Get('dashboard') dashboard() { return this.admin.dashboard(); }
  @Get('users') users(@Query('limit') limit?: string) { return this.admin.users(limit); }
  @Get('payments') payments(@Query('status') status?: string) { return this.admin.payments(status); }
  @Get('orders') orders() { return this.admin.orders(); }
}
