import { Injectable, NotFoundException } from '@nestjs/common';
import { SERVICE_CATALOG } from './services.data';

@Injectable()
export class ServicesService {
  list() {
    return SERVICE_CATALOG;
  }

  getBySlug(slug: string) {
    const service = SERVICE_CATALOG.find((item) => item.slug === slug);
    if (!service) throw new NotFoundException('Үйлчилгээ олдсонгүй.');
    return service;
  }
}
