import { Controller, Get, Param } from '@nestjs/common';
import { ServicesService } from './services.service';

@Controller('services')
export class ServicesController {
  constructor(private readonly services: ServicesService) {}

  @Get()
  list() {
    return { items: this.services.list(), total: this.services.list().length };
  }

  @Get(':slug')
  getOne(@Param('slug') slug: string) {
    return this.services.getBySlug(slug);
  }
}
