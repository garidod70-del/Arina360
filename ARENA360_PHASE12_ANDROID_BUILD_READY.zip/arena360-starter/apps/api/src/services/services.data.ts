export type ServiceDefinition = {
  slug: string;
  name: string;
  summary: string;
  icon: string;
  audience: string;
  capabilities: string[];
  availability: 'PLANNED' | 'BETA' | 'ACTIVE';
};

// Canonical public catalogue for the seven ARENA 360 service areas.
// Listings, bookings and payments are deliberately not fabricated here.
export const SERVICE_CATALOG: ServiceDefinition[] = [
  {
    slug: 'referees',
    name: 'Шүүгч',
    summary: 'Спортын төрлөөр шүүгч хайх, профайл болон эрхийн мэдээлэл үзэх.',
    icon: 'sports',
    audience: 'Тэмцээн зохион байгуулагч, клуб',
    capabilities: ['Спортын төрөл, зэрэглэлээр хайх', 'Туршлага, байршил, үйлчилгээний үнэ харах', 'Эрхийн баримт бичиг шалгуулах'],
    availability: 'PLANNED',
  },
  {
    slug: 'clubs',
    name: 'Клуб, сургалтууд',
    summary: 'Спортын клуб, секц болон хүүхэд, насанд хүрэгчдийн сургалт.',
    icon: 'groups',
    audience: 'Тамирчин, эцэг эх, клуб',
    capabilities: ['Спорт, нас, түвшин, байршлаар шүүх', 'Дасгалжуулагч, хуваарь, төлбөр харах', 'Сургалтад хүсэлт илгээх'],
    availability: 'PLANNED',
  },
  {
    slug: 'competitions',
    name: 'Спортын тэмцээн',
    summary: 'Багийн, ганцаарчилсан болон үндэсний спортын тэмцээний мэдээлэл.',
    icon: 'emoji_events',
    audience: 'Тамирчин, баг, холбоо, зохион байгуулагч',
    capabilities: ['Тэмцээн, ангилал, дүрэм харах', 'Оролцогч бүртгэх', 'Сугалаа, оноолт, үр дүн, медалийн хүснэгт'],
    availability: 'PLANNED',
  },
  {
    slug: 'venues',
    name: 'Заал түрээс',
    summary: 'Спортын заал, талбайн цагийн хуваарь болон түрээсийн үйлчилгээ.',
    icon: 'stadium',
    audience: 'Баг, клуб, хувь хэрэглэгч',
    capabilities: ['Байршил, спортын төрлөөр хайх', 'Үнэ, багтаамж, тоноглол харах', 'Цаг сонгон захиалах'],
    availability: 'PLANNED',
  },
  {
    slug: 'marketplace',
    name: 'Спорт бараа',
    summary: 'Спортын хувцас, хэрэглэл болон тоног төхөөрөмжийн худалдаа.',
    icon: 'shopping_bag',
    audience: 'Худалдан авагч, худалдаалагч',
    capabilities: ['Ангилал, үнэ, хэмжээгээр хайх', 'Барааны үлдэгдэл харах', 'Сагс, захиалга, хүргэлт'],
    availability: 'PLANNED',
  },
  {
    slug: 'education',
    name: 'Дасгалжуулагч, шүүгчийн сургалт',
    summary: 'Мэргэжлийн сургалт, шалгалт болон гэрчилгээний бүртгэл.',
    icon: 'school',
    audience: 'Дасгалжуулагч, шүүгч, спортын мэргэжилтэн',
    capabilities: ['Сургалтын хөтөлбөр харах', 'Бүртгэл, ирц, шалгалт', 'Дугаартай гэрчилгээ, QR баталгаажуулалт'],
    availability: 'PLANNED',
  },
  {
    slug: 'fitness',
    name: 'Фитнесс',
    summary: 'Фитнесс төв, дасгалжуулагч, гишүүнчлэл болон цагийн захиалга.',
    icon: 'fitness_center',
    audience: 'Фитнесс хэрэглэгч, төв, дасгалжуулагч',
    capabilities: ['Төв, тоног төхөөрөмж, цагийн хуваарь харах', 'Эрх, багц сонгох', 'Дасгалжуулагч болон цаг захиалах'],
    availability: 'PLANNED',
  },
];
