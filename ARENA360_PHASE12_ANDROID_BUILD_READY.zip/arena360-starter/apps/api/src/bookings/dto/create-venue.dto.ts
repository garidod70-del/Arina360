import { IsInt, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';

export class CreateVenueDto {
  @IsString() @MaxLength(180) name!: string;
  @IsString() @MaxLength(300) address!: string;
  @IsOptional() @IsString() @MaxLength(2000) description?: string;
  @IsInt() @Min(1) @Max(100000000) hourlyPrice!: number;
  @IsOptional() @IsInt() @Min(1) @Max(100000) capacity?: number;
}
