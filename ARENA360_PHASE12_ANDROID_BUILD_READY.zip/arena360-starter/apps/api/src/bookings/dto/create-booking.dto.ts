import { IsDateString, IsUUID } from 'class-validator';

export class CreateBookingDto {
  @IsUUID() venueId!: string;
  @IsDateString() startsAt!: string;
  @IsDateString() endsAt!: string;
}
