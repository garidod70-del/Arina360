import { Body, Controller, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { ProviderRoleGuard } from '../auth/roles.guard';
import { BookingsService } from './bookings.service';
import { CreateVenueDto } from './dto/create-venue.dto';
import { CreateBookingDto } from './dto/create-booking.dto';

interface RequestWithUser { user: { sub: string } }

@Controller()
export class BookingsController {
  constructor(private readonly bookings: BookingsService) {}

  @Get('venues') listVenues() { return this.bookings.listVenues(); }

  @Post('venues')
  @UseGuards(AuthGuard, ProviderRoleGuard)
  createVenue(@Body() body: CreateVenueDto, @Req() req: RequestWithUser) { return this.bookings.createVenue(body, req.user.sub); }

  @Post('bookings')
  @UseGuards(AuthGuard)
  createBooking(@Body() body: CreateBookingDto, @Req() req: RequestWithUser) { return this.bookings.createBooking(body, req.user.sub); }

  @Get('bookings/mine')
  @UseGuards(AuthGuard)
  myBookings(@Req() req: RequestWithUser) { return this.bookings.myBookings(req.user.sub); }

  @Post('bookings/:id/cancel')
  @UseGuards(AuthGuard)
  cancel(@Param('id') id: string, @Req() req: RequestWithUser) { return this.bookings.cancelBooking(id, req.user.sub); }
}
