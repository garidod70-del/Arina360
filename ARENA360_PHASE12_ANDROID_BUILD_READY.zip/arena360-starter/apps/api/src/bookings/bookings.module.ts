import { Module } from '@nestjs/common';
import { AuthModule } from '../auth/auth.module';
import { ProviderRoleGuard } from '../auth/roles.guard';
import { BookingsController } from './bookings.controller';
import { BookingsService } from './bookings.service';

@Module({ imports: [AuthModule], controllers: [BookingsController], providers: [BookingsService, ProviderRoleGuard] })
export class BookingsModule {}
