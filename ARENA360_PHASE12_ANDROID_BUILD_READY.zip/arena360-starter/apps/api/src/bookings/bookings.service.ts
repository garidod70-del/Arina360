import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../database/prisma.service';
import { CreateVenueDto } from './dto/create-venue.dto';
import { CreateBookingDto } from './dto/create-booking.dto';

@Injectable()
export class BookingsService {
  constructor(private readonly db: PrismaService) {}

  async createVenue(input: CreateVenueDto, providerId: string) {
    const provider = await this.db.user.findUnique({ where: { id: providerId }, select: { role: true, isActive: true } });
    if (!provider?.isActive || !['PROVIDER', 'ADMIN'].includes(provider.role)) throw new ForbiddenException('Үйлчилгээ үзүүлэгчийн эрх баталгаажаагүй.');
    return this.db.venue.create({ data: { ...input, providerId }, select: { id: true, name: true, address: true, description: true, hourlyPrice: true, capacity: true, isActive: true, createdAt: true } });
  }

  listVenues() {
    return this.db.venue.findMany({ where: { isActive: true }, orderBy: { createdAt: 'desc' }, take: 100, select: { id: true, name: true, address: true, description: true, hourlyPrice: true, capacity: true, provider: { select: { phone: true } } } });
  }

  async createBooking(input: CreateBookingDto, userId: string) {
    const start = new Date(input.startsAt);
    const end = new Date(input.endsAt);
    const durationMs = end.getTime() - start.getTime();
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || durationMs <= 0) throw new BadRequestException('Эхлэх болон дуусах цаг буруу байна.');
    if (start.getTime() < Date.now() - 60_000) throw new BadRequestException('Өнгөрсөн цагт захиалга үүсгэх боломжгүй.');
    if (durationMs > 12 * 60 * 60 * 1000) throw new BadRequestException('Нэг захиалга 12 цагаас хэтрэхгүй.');

    try {
      return await this.db.$transaction(async (tx) => {
        const venue = await tx.venue.findFirst({ where: { id: input.venueId, isActive: true }, select: { id: true, hourlyPrice: true } });
        if (!venue) throw new NotFoundException('Заал олдсонгүй эсвэл түр хаалттай байна.');
        const overlap = await tx.booking.findFirst({ where: { venueId: venue.id, status: 'CONFIRMED', startsAt: { lt: end }, endsAt: { gt: start } }, select: { id: true } });
        if (overlap) throw new ConflictException('Энэ цагт заал аль хэдийн захиалагдсан байна.');
        const hours = durationMs / 3_600_000;
        const totalPrice = Math.ceil(hours * venue.hourlyPrice);
        const booking = await tx.booking.create({ data: { venueId: venue.id, userId, startsAt: start, endsAt: end, totalPrice }, select: { id: true, venueId: true, startsAt: true, endsAt: true, totalPrice: true, status: true, createdAt: true } });
        const payment = await tx.paymentRecord.create({ data: { userId, purpose: 'VENUE_BOOKING', referenceId: booking.id, amount: totalPrice, idempotencyKey: `booking:${booking.id}` } });
        return { ...booking, paymentRecordId: payment.id, paymentStatus: payment.status };
      }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable, maxWait: 5000, timeout: 10000 });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && ['P2034', 'P2004'].includes(error.code)) throw new ConflictException('Энэ цагт заал аль хэдийн захиалагдсан байна.');
      if (typeof error === 'object' && error !== null && 'code' in error && (error as { code?: string }).code === '23P01') throw new ConflictException('Энэ цагт заал аль хэдийн захиалагдсан байна.');
      throw error;
    }
  }

  myBookings(userId: string) {
    return this.db.booking.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 100, select: { id: true, startsAt: true, endsAt: true, totalPrice: true, status: true, createdAt: true, venue: { select: { id: true, name: true, address: true } } } });
  }

  async cancelBooking(id: string, userId: string) {
    const booking = await this.db.booking.findUnique({ where: { id }, select: { id: true, userId: true, status: true, startsAt: true } });
    if (!booking) throw new NotFoundException('Захиалга олдсонгүй.');
    if (booking.userId !== userId) throw new ForbiddenException('Та зөвхөн өөрийн захиалгыг цуцална.');
    if (booking.status !== 'CONFIRMED') throw new ConflictException('Зөвхөн баталгаатай захиалгыг цуцална.');
    if (booking.startsAt.getTime() <= Date.now()) throw new BadRequestException('Эхэлсэн захиалгыг цуцлах боломжгүй.');
    const changed = await this.db.booking.updateMany({ where: { id, userId, status: 'CONFIRMED' }, data: { status: 'CANCELLED', cancelledAt: new Date() } });
    if (changed.count !== 1) throw new ConflictException('Захиалгын төлөв өөрчлөгдсөн байна.');
    return { id, status: 'CANCELLED' as const, message: 'Захиалга цуцлагдлаа.' };
  }
}
