import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { Prisma, ProviderStatus } from '@prisma/client';
import { PrismaService } from '../database/prisma.service';
import { UpsertRefereeProfileDto } from './dto/upsert-referee-profile.dto';
import { CreateRefereeBookingDto } from './dto/create-referee-booking.dto';
import { CreateEventReportDto } from './dto/create-event-report.dto';

@Injectable()
export class RefereesService {
  constructor(private readonly db: PrismaService) {}

  async list(filters: { sport?: string; region?: string }) {
    const profiles = await this.db.refereeProfile.findMany({
      where: { status: ProviderStatus.APPROVED, suspendedAt: null, ...(filters.sport ? { sportTypes: { has: filters.sport } } : {}), ...(filters.region ? { region: { contains: filters.region, mode: 'insensitive' as const } } : {}) },
      orderBy: [{ experienceYears: 'desc' }, { createdAt: 'desc' }], take: 100,
      select: { id: true, userId: true, displayName: true, sportTypes: true, rank: true, experienceYears: true, region: true, city: true, district: true, bio: true, serviceFee: true, travelFee: true, mealFee: true, lodgingFee: true, licenseExpiresAt: true, verifiedAt: true, federationName: true, federationVerifiedAt: true, availability: true },
    });
    return profiles;
  }

  async mine(userId: string) {
    const profile = await this.db.refereeProfile.findUnique({ where: { userId }, include: { bookings: { orderBy: { startsAt: 'desc' }, take: 100, include: { eventReport: true } } } });
    if (!profile) return null;
    const [completedCount, reportCount, earnings, rating] = await Promise.all([
      this.db.refereeBooking.count({ where: { refereeId: profile.id, status: 'COMPLETED' } }),
      this.db.refereeEventReport.count({ where: { refereeId: profile.id } }),
      this.db.refereeBooking.aggregate({ where: { refereeId: profile.id, status: 'COMPLETED' }, _sum: { totalPrice: true, serviceFeeSnapshot: true, travelFeeSnapshot: true, mealFeeSnapshot: true, lodgingFeeSnapshot: true } }),
      this.db.review.aggregate({ where: { targetType: 'REFEREE', targetId: profile.id }, _avg: { rating: true }, _count: { _all: true } }),
    ]);
    return { ...profile, statistics: { completedTournaments: completedCount, reportsSubmitted: reportCount, ratingAverage: rating._avg.rating ?? null, ratingCount: rating._count._all, income: { total: earnings._sum.totalPrice ?? 0, service: earnings._sum.serviceFeeSnapshot ?? 0, travel: earnings._sum.travelFeeSnapshot ?? 0, meal: earnings._sum.mealFeeSnapshot ?? 0, lodging: earnings._sum.lodgingFeeSnapshot ?? 0, currency: 'MNT' } } };
  }

  async upsert(userId: string, input: UpsertRefereeProfileDto) {
    const user = await this.db.user.findUnique({ where: { id: userId }, select: { isActive: true } });
    if (!user?.isActive) throw new ForbiddenException('Идэвхтэй хэрэглэгч шаардлагатай.');
    const existing = await this.db.refereeProfile.findUnique({ where: { userId }, select: { qrToken: true, status: true, suspendedAt: true } });
    if (existing?.status === ProviderStatus.SUSPENDED || existing?.suspendedAt) throw new ForbiddenException('Шүүгчийн эрх түдгэлзсэн тул профайлыг өөрчлөх боломжгүй. Админтай холбогдоно уу.');
    const data = {
      ...input,
      availability: input.availability as Prisma.InputJsonValue | undefined,
      lodgingFee: input.lodgingFee ?? 0,
      licenseExpiresAt: input.licenseExpiresAt ? new Date(input.licenseExpiresAt) : null,
      qrToken: existing?.qrToken ?? randomUUID().replace(/-/g, ''),
      status: ProviderStatus.PENDING_ADMIN_REVIEW,
      verifiedAt: null,
      federationVerifiedAt: null,
      suspendedAt: null,
      suspensionReason: null,
    };
    return this.db.refereeProfile.upsert({ where: { userId }, create: { ...data, userId }, update: data, select: { id: true, displayName: true, sportTypes: true, status: true, qrToken: true, createdAt: true, updatedAt: true } });
  }

  async createBooking(customerId: string, input: CreateRefereeBookingDto) {
    const start = new Date(input.startsAt), end = new Date(input.endsAt);
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start || start < new Date(Date.now() - 60000)) throw new BadRequestException('Захиалгын огноо, цаг буруу байна.');
    if (end.getTime() - start.getTime() > 24 * 60 * 60 * 1000) throw new BadRequestException('Нэг захиалга 24 цагаас хэтрэхгүй.');
    const refereeIds = [...new Set([...(input.refereeIds ?? []), ...(input.refereeId ? [input.refereeId] : [])])];
    if (!refereeIds.length) throw new BadRequestException('Нэг эсвэл хэд хэдэн шүүгч сонгоно уу.');
    const profiles = await this.db.refereeProfile.findMany({ where: { id: { in: refereeIds }, status: ProviderStatus.APPROVED, suspendedAt: null } });
    if (profiles.length !== refereeIds.length) throw new NotFoundException('Баталгаажсан, идэвхтэй шүүгчдийн жагсаалт бүрэн олдсонгүй.');
    try {
      return await this.db.$transaction(async tx => {
        const created: any[] = [];
        const groupId = refereeIds.length > 1 ? randomUUID() : null;
        for (const profile of profiles) {
          const overlap = await tx.refereeBooking.findFirst({ where: { refereeId: profile.id, status: { in: ['REQUESTED', 'ACCEPTED'] }, startsAt: { lt: end }, endsAt: { gt: start } }, select: { id: true } });
          if (overlap) throw new ConflictException(`${profile.displayName} сонгосон цагт захиалгатай байна.`);
          created.push(await tx.refereeBooking.create({ data: {
            refereeId: profile.id, customerId, startsAt: start, endsAt: end, location: input.location, sport: input.sport, notes: input.notes,
            serviceFeeSnapshot: profile.serviceFee, travelFeeSnapshot: profile.travelFee, mealFeeSnapshot: profile.mealFee, lodgingFeeSnapshot: profile.lodgingFee,
            totalPrice: profile.serviceFee + profile.travelFee + profile.mealFee + profile.lodgingFee, groupId,
          }, select: { id: true, refereeId: true, startsAt: true, endsAt: true, location: true, sport: true, totalPrice: true, status: true, groupId: true, createdAt: true } }));
        }
        return { groupId, bookings: created, requiresEachRefereeApproval: true };
      }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2034') throw new ConflictException('Шүүгчийн цаг давхардсан байна. Дахин оролдоно уу.');
      throw e;
    }
  }

  async changeBookingStatus(userId: string, bookingId: string, status: 'ACCEPTED' | 'REJECTED' | 'COMPLETED' | 'CANCELLED') {
    const booking = await this.db.refereeBooking.findUnique({ where: { id: bookingId }, include: { referee: { select: { userId: true, suspendedAt: true } } } });
    if (!booking) throw new NotFoundException('Захиалга олдсонгүй.');
    const isReferee = booking.referee.userId === userId;
    const isCustomer = booking.customerId === userId;
    if (!isReferee && !isCustomer) throw new ForbiddenException('Энэ захиалгыг өөрчлөх эрхгүй.');
    if (['ACCEPTED', 'REJECTED', 'COMPLETED'].includes(status) && !isReferee) throw new ForbiddenException('Зөвхөн тухайн шүүгч төлөвийг өөрчилнө.');
    if (status === 'ACCEPTED' && booking.referee.suspendedAt) throw new ForbiddenException('Эрх нь түдгэлзсэн шүүгч шинэ захиалга баталгаажуулах боломжгүй.');
    if (status === 'ACCEPTED' && booking.status !== 'REQUESTED') throw new ConflictException('Зөвхөн хүсэлттэй захиалгыг зөвшөөрнө.');
    if (status === 'REJECTED' && booking.status !== 'REQUESTED') throw new ConflictException('Зөвхөн хүсэлттэй захиалгыг татгалзана.');
    if (status === 'COMPLETED' && booking.status !== 'ACCEPTED') throw new ConflictException('Зөвхөн зөвшөөрсөн захиалгыг дуусгана.');
    if (status === 'CANCELLED' && !['REQUESTED', 'ACCEPTED'].includes(booking.status)) throw new ConflictException('Энэ захиалгыг цуцлах боломжгүй.');
    return this.db.refereeBooking.update({ where: { id: bookingId }, data: { status } });
  }

  async createEventReport(userId: string, input: CreateEventReportDto) {
    const booking = await this.db.refereeBooking.findUnique({ where: { id: input.bookingId }, include: { referee: { select: { userId: true } } } });
    if (!booking) throw new NotFoundException('Шүүгчийн захиалга олдсонгүй.');
    if (booking.referee.userId !== userId) throw new ForbiddenException('Зөвхөн тухайн шүүгч тайлан илгээнэ.');
    if (booking.status !== 'COMPLETED') throw new ConflictException('Тэмцээн дууссан төлөвт орсны дараа тайлан илгээнэ.');
    try { return await this.db.refereeEventReport.create({ data: { ...input, refereeId: booking.refereeId } }); }
    catch (e: any) { if (e?.code === 'P2002') throw new ConflictException('Энэ захиалгын тайлан өмнө нь илгээгдсэн.'); throw e; }
  }

  async earnings(userId: string) {
    const profile = await this.db.refereeProfile.findUnique({ where: { userId }, select: { id: true } });
    if (!profile) throw new NotFoundException('Шүүгчийн профайл олдсонгүй.');
    const rows = await this.db.refereeBooking.findMany({ where: { refereeId: profile.id, status: 'COMPLETED' }, orderBy: { endsAt: 'desc' }, take: 200, select: { id: true, startsAt: true, endsAt: true, sport: true, location: true, totalPrice: true, serviceFeeSnapshot: true, travelFeeSnapshot: true, mealFeeSnapshot: true, lodgingFeeSnapshot: true } });
    return { currency: 'MNT', total: rows.reduce((a, b) => a + b.totalPrice, 0), bookings: rows };
  }

  async refereeQr(userId: string) {
    const profile = await this.db.refereeProfile.findUnique({ where: { userId }, select: { id: true, displayName: true, qrToken: true, status: true, suspendedAt: true } });
    if (!profile) throw new NotFoundException('Шүүгчийн профайл олдсонгүй.');
    return { ...profile, payload: profile.qrToken ? `ARENA360:REFEREE:${profile.qrToken}` : null };
  }
  verifyQr(token: string) {
    return this.db.refereeProfile.findFirst({ where: { qrToken: token, status: ProviderStatus.APPROVED, suspendedAt: null }, select: { id: true, displayName: true, sportTypes: true, rank: true, region: true, city: true, federationVerifiedAt: true, verifiedAt: true } }).then(profile => profile ? { valid: true, ...profile } : { valid: false });
  }
  async reviewProfile(profileId: string, status: 'APPROVED' | 'REJECTED', adminId: string) {
    const profile = await this.db.refereeProfile.findUnique({ where: { id: profileId } });
    if (!profile) throw new NotFoundException('Шүүгчийн профайл олдсонгүй.');
    if (profile.status !== ProviderStatus.PENDING_ADMIN_REVIEW) throw new ConflictException('Энэ хүсэлт аль хэдийн шийдвэрлэгдсэн.');
    const updated = await this.db.refereeProfile.update({ where: { id: profileId }, data: { status, verifiedAt: status === 'APPROVED' ? new Date() : null } , select: { id: true, displayName: true, status: true, verifiedAt: true } });
    await this.db.adminAuditLog.create({ data: { adminId, action: `REFEREE_${status}`, entityId: profileId, details: { displayName: profile.displayName } } });
    return updated;
  }
  async verifyFederation(profileId: string, adminId: string) {
    const profile = await this.db.refereeProfile.findUnique({ where: { id: profileId } });
    if (!profile) throw new NotFoundException('Шүүгчийн профайл олдсонгүй.');
    if (profile.status !== ProviderStatus.APPROVED) throw new ConflictException('Эхлээд шүүгчийн профайлыг баталгаажуулна.');
    const updated = await this.db.refereeProfile.update({ where: { id: profileId }, data: { federationVerifiedAt: new Date() }, select: { id: true, displayName: true, federationName: true, federationVerifiedAt: true } });
    await this.db.adminAuditLog.create({ data: { adminId, action: 'REFEREE_FEDERATION_VERIFIED', entityId: profileId } });
    return updated;
  }
  async setSuspended(profileId: string, adminId: string, suspended: boolean, reason?: string) {
    const profile = await this.db.refereeProfile.findUnique({ where: { id: profileId } });
    if (!profile) throw new NotFoundException('Шүүгчийн профайл олдсонгүй.');
    if (suspended && profile.status !== ProviderStatus.APPROVED) throw new ConflictException('Зөвхөн баталгаажсан шүүгчийн эрхийг түдгэлзүүлнэ.');
    if (!suspended && profile.status !== ProviderStatus.SUSPENDED) throw new ConflictException('Түдгэлзсэн шүүгчийн эрх сэргээх боломжтой.');
    const updated = await this.db.refereeProfile.update({ where: { id: profileId }, data: suspended ? { status: ProviderStatus.SUSPENDED, suspendedAt: new Date(), suspensionReason: reason || 'Админы шийдвэр' } : { status: ProviderStatus.APPROVED, suspendedAt: null, suspensionReason: null }, select: { id: true, displayName: true, status: true, suspendedAt: true, suspensionReason: true } });
    await this.db.adminAuditLog.create({ data: { adminId, action: suspended ? 'REFEREE_SUSPENDED' : 'REFEREE_RESTORED', entityId: profileId, details: { reason: reason ?? null } } });
    return updated;
  }
  allAdmin() { return this.db.refereeProfile.findMany({ orderBy: { updatedAt: 'desc' }, take: 200, select: { id: true, userId: true, displayName: true, sportTypes: true, rank: true, experienceYears: true, region: true, city: true, district: true, status: true, federationName: true, federationVerifiedAt: true, suspendedAt: true, suspensionReason: true, serviceFee: true, travelFee: true, mealFee: true, lodgingFee: true, _count: { select: { bookings: true, eventReports: true } } } }); }
  pending() { return this.db.refereeProfile.findMany({ where: { status: ProviderStatus.PENDING_ADMIN_REVIEW }, orderBy: { createdAt: 'asc' }, take: 100, select: { id: true, userId: true, displayName: true, sportTypes: true, rank: true, licenseNumber: true, licenseExpiresAt: true, experienceYears: true, region: true, city: true, district: true, federationName: true, federationDocumentUrl: true, createdAt: true } }); }
}
