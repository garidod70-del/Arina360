import { BadRequestException, Body, Controller, Get, Param, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { AdminRoleGuard } from '../auth/roles.guard';
import { RefereesService } from './referees.service';
import { UpsertRefereeProfileDto } from './dto/upsert-referee-profile.dto';
import { CreateRefereeBookingDto } from './dto/create-referee-booking.dto';
import { CreateEventReportDto } from './dto/create-event-report.dto';

interface AuthRequest { user: { sub: string } }

@Controller('referees')
export class RefereesController {
  constructor(private readonly service: RefereesService) {}
  @Get() list(@Query('sport') sport?: string, @Query('region') region?: string) { return this.service.list({ sport, region }); }
  @Get('me') @UseGuards(AuthGuard) mine(@Req() req: AuthRequest) { return this.service.mine(req.user.sub); }
  @Post('me') @UseGuards(AuthGuard) upsert(@Body() body: UpsertRefereeProfileDto, @Req() req: AuthRequest) { return this.service.upsert(req.user.sub, body); }
  @Get('qr/:token') verifyQr(@Param('token') token: string) { return this.service.verifyQr(token); }
  @Get('me/qr') @UseGuards(AuthGuard) qr(@Req() req: AuthRequest) { return this.service.refereeQr(req.user.sub); }
  @Get('me/earnings') @UseGuards(AuthGuard) earnings(@Req() req: AuthRequest) { return this.service.earnings(req.user.sub); }
  @Post('me/reports') @UseGuards(AuthGuard) report(@Body() body: CreateEventReportDto, @Req() req: AuthRequest) { return this.service.createEventReport(req.user.sub, body); }
  @Post('bookings') @UseGuards(AuthGuard) book(@Body() body: CreateRefereeBookingDto, @Req() req: AuthRequest) { return this.service.createBooking(req.user.sub, body); }
  @Patch('bookings/:id/:status') @UseGuards(AuthGuard) status(@Param('id') id: string, @Param('status') status: string, @Req() req: AuthRequest) {
    if (!['ACCEPTED', 'REJECTED', 'COMPLETED', 'CANCELLED'].includes(status)) throw new BadRequestException('Захиалгын төлөв буруу байна.');
    return this.service.changeBookingStatus(req.user.sub, id, status as 'ACCEPTED' | 'REJECTED' | 'COMPLETED' | 'CANCELLED');
  }
  @Patch('admin/:id/federation-verify') @UseGuards(AuthGuard, AdminRoleGuard) federationVerify(@Param('id') id: string, @Req() req: AuthRequest) { return this.service.verifyFederation(id, req.user.sub); }
  @Patch('admin/:id/suspend') @UseGuards(AuthGuard, AdminRoleGuard) suspend(@Param('id') id: string, @Body('reason') reason: string, @Req() req: AuthRequest) { return this.service.setSuspended(id, req.user.sub, true, reason); }
  @Patch('admin/:id/restore') @UseGuards(AuthGuard, AdminRoleGuard) restore(@Param('id') id: string, @Req() req: AuthRequest) { return this.service.setSuspended(id, req.user.sub, false); }
  @Get('admin/all') @UseGuards(AuthGuard, AdminRoleGuard) allAdmin() { return this.service.allAdmin(); }
  @Get('admin/pending') @UseGuards(AuthGuard, AdminRoleGuard) pending() { return this.service.pending(); }
  @Patch('admin/:id/:decision') @UseGuards(AuthGuard, AdminRoleGuard) review(@Param('id') id: string, @Param('decision') decision: string, @Req() req: AuthRequest) {
    if (!['APPROVED', 'REJECTED'].includes(decision)) throw new BadRequestException('Шийдвэр буруу байна.');
    return this.service.reviewProfile(id, decision as 'APPROVED' | 'REJECTED', req.user.sub);
  }
}
