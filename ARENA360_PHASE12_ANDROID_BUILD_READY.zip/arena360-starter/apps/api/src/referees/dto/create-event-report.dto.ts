import { IsOptional, IsString, IsUUID, MaxLength, MinLength } from 'class-validator';
export class CreateEventReportDto {
  @IsUUID() bookingId!: string;
  @IsString() @MinLength(2) @MaxLength(180) eventName!: string;
  @IsString() @MinLength(2) @MaxLength(100) tournamentLevel!: string;
  @IsString() @MinLength(2) @MaxLength(100) role!: string;
  @IsOptional() @IsString() @MaxLength(3000) notes?: string;
}
