import { ArrayMinSize, ArrayUnique, IsArray, IsDateString, IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';
export class CreateRefereeBookingDto {
  @IsOptional() @IsUUID() refereeId?: string;
  @IsOptional() @IsArray() @ArrayMinSize(1) @ArrayUnique() @IsUUID('4', { each: true }) refereeIds?: string[];
  @IsDateString() startsAt!: string;
  @IsDateString() endsAt!: string;
  @IsString() @MaxLength(300) location!: string;
  @IsString() @MaxLength(80) sport!: string;
  @IsOptional() @IsString() @MaxLength(1000) notes?: string;
}
