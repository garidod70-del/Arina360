import { IsArray, ArrayMinSize, IsInt, IsOptional, IsString, MaxLength, Min, IsDateString, IsObject } from 'class-validator';
export class UpsertRefereeProfileDto {
  @IsString() @MaxLength(160) displayName!: string;
  @IsArray() @ArrayMinSize(1) sportTypes!: string[];
  @IsOptional() @IsString() @MaxLength(100) rank?: string;
  @IsOptional() @IsString() @MaxLength(100) licenseNumber?: string;
  @IsOptional() @IsDateString() licenseExpiresAt?: string;
  @IsInt() @Min(0) experienceYears!: number;
  @IsOptional() @IsString() @MaxLength(120) region?: string;
  @IsOptional() @IsString() @MaxLength(100) city?: string;
  @IsOptional() @IsString() @MaxLength(100) district?: string;
  @IsOptional() @IsString() @MaxLength(180) federationName?: string;
  @IsOptional() @IsString() @MaxLength(1000) federationDocumentUrl?: string;
  @IsOptional() @IsString() @MaxLength(2000) bio?: string;
  @IsInt() @Min(0) serviceFee!: number;
  @IsInt() @Min(0) travelFee!: number;
  @IsInt() @Min(0) mealFee!: number;
  @IsOptional() @IsInt() @Min(0) lodgingFee?: number;
  @IsOptional() @IsObject() availability?: Record<string, unknown>;
}
