import { Body, Controller, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { CreateInvoiceDto } from './dto/create-invoice.dto';
import { PaymentsService } from './payments.service';
interface ActorRequest { user: { sub: string; role: string } }
@Controller('payments')
export class PaymentsController {
  constructor(private readonly payments: PaymentsService) {}
  @Post('qpay/invoices') @UseGuards(AuthGuard)
  createInvoice(@Body() dto: CreateInvoiceDto, @Req() req: ActorRequest) { return this.payments.createInvoice(dto.paymentRecordId, req.user.sub); }
  @Get(':id/status') @UseGuards(AuthGuard)
  status(@Param('id') id: string, @Req() req: ActorRequest) { return this.payments.status(id, req.user.sub); }
  // Callback payload is not trusted. The service independently checks the invoice with QPay.
  @Post('qpay/callback/:paymentRecordId') callback(@Param('paymentRecordId') paymentRecordId: string, @Query('key') key: string) { return this.payments.confirmPaymentRecord(paymentRecordId, key); }
}
