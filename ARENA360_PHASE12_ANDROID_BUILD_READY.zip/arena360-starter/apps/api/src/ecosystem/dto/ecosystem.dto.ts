import { IsArray, IsInt, IsOptional, IsString, IsUUID, Max, MaxLength, Min, MinLength, ArrayMinSize, ValidateNested, IsDateString, IsIn } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateCourseDto {
  @IsString() @MinLength(3) @MaxLength(180) title!: string;
  @IsString() @MinLength(2) @MaxLength(80) sport!: string;
  @IsOptional() @IsString() @MaxLength(3000) description?: string;
  @IsOptional() @IsDateString() startsAt?: string;
  @IsOptional() @IsDateString() endsAt?: string;
  @IsInt() @Min(0) @Max(100000000) price!: number;
  @IsOptional() @IsInt() @Min(1) @Max(100000) capacity?: number;
}
export class CreateProductDto {
  @IsString() @MinLength(2) @MaxLength(180) title!: string;
  @IsString() @MinLength(2) @MaxLength(80) category!: string;
  @IsOptional() @IsString() @MaxLength(2000) description?: string;
  @IsInt() @Min(1) @Max(100000000) price!: number;
  @IsInt() @Min(0) @Max(1000000) stock!: number;
  @IsOptional() @IsString() @MaxLength(1000) imageUrl?: string;
}
export class OrderLineDto {
  @IsUUID() productId!: string;
  @IsInt() @Min(1) @Max(1000) quantity!: number;
}
export class CreateOrderDto {
  @IsArray() @ArrayMinSize(1) @ValidateNested({ each: true }) @Type(() => OrderLineDto) items!: OrderLineDto[];
}
export class CreateFitnessCenterDto {
  @IsString() @MinLength(2) @MaxLength(180) name!: string;
  @IsString() @MinLength(4) @MaxLength(300) address!: string;
  @IsOptional() @IsString() @MaxLength(2000) description?: string;
}
export class CreateFitnessPlanDto {
  @IsString() @MinLength(2) @MaxLength(120) title!: string;
  @IsInt() @Min(1) @Max(3660) durationDays!: number;
  @IsInt() @Min(1) @Max(100000000) price!: number;
}

export class CreateSportListingDto {
  @IsString() @MinLength(3) @MaxLength(30) listingType!: string;
  @IsString() @MinLength(2) @MaxLength(180) name!: string;
  @IsString() @MinLength(2) @MaxLength(80) sport!: string;
  @IsOptional() @IsString() @MaxLength(3000) description?: string;
  @IsString() @MinLength(2) @MaxLength(240) location!: string;
  @IsOptional() @IsString() @MaxLength(100) ageGroup?: string;
  @IsOptional() @IsString() @MaxLength(80) level?: string;
  @IsOptional() @IsString() @MaxLength(160) coachName?: string;
  @IsOptional() @IsString() @MaxLength(1000) schedule?: string;
  @IsOptional() @IsInt() @Min(0) @Max(100000000) fee?: number;
  @IsOptional() @IsInt() @Min(1) @Max(100000) capacity?: number;
  @IsOptional() @IsString() @MaxLength(20) contactPhone?: string;
}
export class CreateInquiryDto {
  @IsString() @MinLength(3) @MaxLength(1500) message!: string;
}


export class RequestMarketplaceRefundDto {
  @IsString() @MinLength(5) @MaxLength(1000) reason!: string;
}
export class ReviewMarketplaceRefundDto {
  @IsIn(['APPROVED', 'REJECTED']) decision!: 'APPROVED' | 'REJECTED';
}
export class ConfirmMarketplaceRefundDto {
  @IsString() @MinLength(1) @MaxLength(120) providerRefundId!: string;
}
