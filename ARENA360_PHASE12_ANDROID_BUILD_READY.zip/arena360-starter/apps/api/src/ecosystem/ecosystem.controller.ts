import { Body, Controller, Get, Param, Patch, Post, Query, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { AdminRoleGuard, ProviderRoleGuard } from '../auth/roles.guard';
import { EcosystemService } from './ecosystem.service';
import { CreateCourseDto, CreateFitnessCenterDto, CreateFitnessPlanDto, CreateOrderDto, CreateProductDto, CreateSportListingDto, CreateInquiryDto, RequestMarketplaceRefundDto, ReviewMarketplaceRefundDto, ConfirmMarketplaceRefundDto } from './dto/ecosystem.dto';
interface ActorRequest { user: { sub: string; role: string } }

@Controller()
export class EcosystemController {
  constructor(private readonly ecosystem: EcosystemService) {}

  @Get('listings') listings(@Query('type') type?: string, @Query('sport') sport?: string, @Query('location') location?: string) { return this.ecosystem.listListings({ type, sport, location }); }
  @Post('listings') @UseGuards(AuthGuard, ProviderRoleGuard)
  createListing(@Body() dto: CreateSportListingDto, @Req() req: ActorRequest) { return this.ecosystem.createListing(dto, req.user.sub); }
  @Post('listings/:id/publish') @UseGuards(AuthGuard)
  publishListing(@Param('id') id: string, @Req() req: ActorRequest) { return this.ecosystem.publishListing(id, req.user); }
  @Post('listings/:id/inquiries') @UseGuards(AuthGuard)
  inquire(@Param('id') id: string, @Body() dto: CreateInquiryDto, @Req() req: ActorRequest) { return this.ecosystem.createInquiry(id, dto.message, req.user.sub); }
  @Get('listings/inquiries/mine') @UseGuards(AuthGuard)
  myInquiries(@Req() req: ActorRequest) { return this.ecosystem.providerInquiries(req.user.sub); }

  @Get('courses') courses() { return this.ecosystem.listCourses(); }
  @Post('courses') @UseGuards(AuthGuard, ProviderRoleGuard)
  createCourse(@Body() dto: CreateCourseDto, @Req() req: ActorRequest) { return this.ecosystem.createCourse(dto, req.user); }
  @Post('courses/:id/publish') @UseGuards(AuthGuard)
  publishCourse(@Param('id') id: string, @Req() req: ActorRequest) { return this.ecosystem.publishCourse(id, req.user); }
  @Post('courses/:id/enroll') @UseGuards(AuthGuard)
  enroll(@Param('id') id: string, @Req() req: ActorRequest) { return this.ecosystem.enroll(id, req.user.sub); }
  @Get('courses/enrollments/mine') @UseGuards(AuthGuard)
  myEnrollments(@Req() req: ActorRequest) { return this.ecosystem.myEnrollments(req.user.sub); }
  @Post('courses/enrollments/:id/complete') @UseGuards(AuthGuard)
  completeCourse(@Param('id') id: string, @Req() req: ActorRequest) { return this.ecosystem.completeCourse(id, req.user); }

  @Get('marketplace/products') products() { return this.ecosystem.listProducts(); }
  @Post('marketplace/products') @UseGuards(AuthGuard, ProviderRoleGuard)
  createProduct(@Body() dto: CreateProductDto, @Req() req: ActorRequest) { return this.ecosystem.createProduct(dto, req.user.sub); }
  @Post('marketplace/orders') @UseGuards(AuthGuard)
  createOrder(@Body() dto: CreateOrderDto, @Req() req: ActorRequest) { return this.ecosystem.createOrder(dto, req.user.sub); }
  @Get('marketplace/orders/mine') @UseGuards(AuthGuard)
  myOrders(@Req() req: ActorRequest) { return this.ecosystem.myOrders(req.user.sub); }
  @Post('marketplace/orders/:id/refunds') @UseGuards(AuthGuard)
  requestRefund(@Param('id') id: string, @Body() dto: RequestMarketplaceRefundDto, @Req() req: ActorRequest) { return this.ecosystem.requestMarketplaceRefund(id, dto.reason, req.user.sub); }
  @Patch('admin/marketplace/refunds/:id/review') @UseGuards(AuthGuard, AdminRoleGuard)
  reviewRefund(@Param('id') id: string, @Body() dto: ReviewMarketplaceRefundDto, @Req() req: ActorRequest) { return this.ecosystem.reviewMarketplaceRefund(id, dto.decision, req.user.sub); }
  @Post('admin/marketplace/refunds/:id/confirm') @UseGuards(AuthGuard, AdminRoleGuard)
  confirmRefund(@Param('id') id: string, @Body() dto: ConfirmMarketplaceRefundDto, @Req() req: ActorRequest) { return this.ecosystem.confirmMarketplaceRefund(id, dto.providerRefundId, req.user.sub); }

  @Get('fitness/centers') centers() { return this.ecosystem.listFitnessCenters(); }
  @Post('fitness/centers') @UseGuards(AuthGuard, ProviderRoleGuard)
  createCenter(@Body() dto: CreateFitnessCenterDto, @Req() req: ActorRequest) { return this.ecosystem.createFitnessCenter(dto, req.user.sub); }
  @Post('fitness/centers/:id/plans') @UseGuards(AuthGuard)
  createPlan(@Param('id') id: string, @Body() dto: CreateFitnessPlanDto, @Req() req: ActorRequest) { return this.ecosystem.createFitnessPlan(id, dto, req.user); }
  @Post('fitness/plans/:id/subscribe') @UseGuards(AuthGuard)
  subscribe(@Param('id') id: string, @Req() req: ActorRequest) { return this.ecosystem.subscribe(id, req.user.sub); }
  @Get('fitness/memberships/mine') @UseGuards(AuthGuard)
  myMemberships(@Req() req: ActorRequest) { return this.ecosystem.myMemberships(req.user.sub); }
  @Post('fitness/memberships/:id/pass') @UseGuards(AuthGuard)
  membershipPass(@Param('id') id: string, @Req() req: ActorRequest) { return this.ecosystem.issueMembershipPass(id, req.user.sub); }

  @Get('passes/verify/:token') verifyPass(@Param('token') token: string) { return this.ecosystem.verifyPass(token); }
  @Get('notifications/mine') @UseGuards(AuthGuard)
  notifications(@Req() req: ActorRequest) { return this.ecosystem.notifications(req.user.sub); }
  @Patch('notifications/:id/read') @UseGuards(AuthGuard)
  markRead(@Param('id') id: string, @Req() req: ActorRequest) { return this.ecosystem.markNotificationRead(id, req.user.sub); }
}
