import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { PrismaService } from '../database/prisma.service';
import { CreateCourseDto, CreateFitnessCenterDto, CreateFitnessPlanDto, CreateOrderDto, CreateProductDto, CreateSportListingDto } from './dto/ecosystem.dto';

type Actor = { sub: string; role: string };
const hashToken = (token: string) => createHash('sha256').update(token).digest('hex');

@Injectable()
export class EcosystemService {
  constructor(private readonly db: PrismaService) {}

  listListings(filters: { type?: string; sport?: string; location?: string } = {}) {
    const type = filters.type?.toUpperCase();
    const allowedTypes = ['REFEREE', 'CLUB', 'COACH', 'SPORTS_DOCTOR', 'STRENGTH_COACH', 'SPORTS_PSYCHOLOGIST', 'NUTRITIONIST', 'PHYSIOTHERAPIST', 'SPORTS_ANALYST', 'FITNESS_TRAINER', 'REHABILITATION_SPECIALIST'];
    if (type && !allowedTypes.includes(type)) throw new BadRequestException('Үйлчилгээний төрөл буруу байна.');
    return this.db.sportListing.findMany({ where: { isPublished: true, ...(type ? { listingType: type } : {}), ...(filters.sport ? { sport: { contains: filters.sport, mode: 'insensitive' } } : {}), ...(filters.location ? { location: { contains: filters.location, mode: 'insensitive' } } : {}) }, orderBy: { createdAt: 'desc' }, take: 200 });
  }
  createListing(dto: CreateSportListingDto, providerId: string) {
    const allowed = ['REFEREE', 'CLUB', 'COACH', 'SPORTS_DOCTOR', 'STRENGTH_COACH', 'SPORTS_PSYCHOLOGIST', 'NUTRITIONIST', 'PHYSIOTHERAPIST', 'SPORTS_ANALYST', 'FITNESS_TRAINER', 'REHABILITATION_SPECIALIST'];
    if (!allowed.includes(dto.listingType.toUpperCase())) throw new BadRequestException('Үйлчилгээний төрөл буруу байна.');
    return this.db.sportListing.create({ data: { ...dto, listingType: dto.listingType.toUpperCase(), providerId } });
  }
  async publishListing(id: string, actor: Actor) {
    const listing = await this.db.sportListing.findUnique({ where: { id } });
    if (!listing) throw new NotFoundException('Үйлчилгээний зар олдсонгүй.');
    if (listing.providerId !== actor.sub && actor.role !== 'ADMIN') throw new ForbiddenException('Зөвхөн эзэмшигч нийтлэх эрхтэй.');
    return this.db.sportListing.update({ where: { id }, data: { isPublished: true } });
  }
  async createInquiry(listingId: string, message: string, userId: string) {
    const listing = await this.db.sportListing.findFirst({ where: { id: listingId, isPublished: true } });
    if (!listing) throw new NotFoundException('Нийтлэгдсэн үйлчилгээ олдсонгүй.');
    if (listing.providerId === userId) throw new BadRequestException('Өөрийн үйлчилгээнд хүсэлт илгээх боломжгүй.');
    const inquiry = await this.db.serviceInquiry.create({ data: { listingId, userId, message: message.trim() } });
    await this.db.userNotification.create({ data: { userId: listing.providerId, title: 'Шинэ үйлчилгээний хүсэлт', body: `${listing.name}: шинэ хүсэлт ирлээ.`, type: 'INQUIRY' } });
    return inquiry;
  }
  providerInquiries(providerId: string) { return this.db.serviceInquiry.findMany({ where: { listing: { providerId } }, include: { listing: { select: { name: true, listingType: true } }, user: { select: { phone: true } } }, orderBy: { createdAt: 'desc' } }); }

  listCourses() { return this.db.trainingCourse.findMany({ where: { isPublished: true }, orderBy: { startsAt: 'asc' }, include: { _count: { select: { enrollments: true } } } }); }
  async createCourse(dto: CreateCourseDto, actor: Actor) {
    if (!['PROVIDER', 'ADMIN'].includes(actor.role)) throw new ForbiddenException('Баталгаажсан үйлчилгээ үзүүлэгч шаардлагатай.');
    if (dto.startsAt && dto.endsAt && new Date(dto.endsAt) <= new Date(dto.startsAt)) throw new BadRequestException('Дуусах хугацаа эхлэх хугацаанаас хойш байна.');
    return this.db.trainingCourse.create({ data: { ...dto, providerId: actor.sub, startsAt: dto.startsAt ? new Date(dto.startsAt) : undefined, endsAt: dto.endsAt ? new Date(dto.endsAt) : undefined } });
  }
  async publishCourse(id: string, actor: Actor) {
    const course = await this.db.trainingCourse.findUnique({ where: { id } });
    if (!course) throw new NotFoundException('Сургалт олдсонгүй.');
    if (course.providerId !== actor.sub && actor.role !== 'ADMIN') throw new ForbiddenException('Зөвхөн эзэмшигч нийтлэх эрхтэй.');
    return this.db.trainingCourse.update({ where: { id }, data: { isPublished: true } });
  }
  async enroll(courseId: string, userId: string) {
    return this.db.$transaction(async (tx) => {
      const course = await tx.trainingCourse.findFirst({ where: { id: courseId, isPublished: true } });
      if (!course) throw new NotFoundException('Нээлттэй сургалт олдсонгүй.');
      const count = await tx.courseEnrollment.count({ where: { courseId } });
      if (course.capacity && count >= course.capacity) throw new ConflictException('Сургалтын суудал дүүрсэн байна.');
      try { return await tx.courseEnrollment.create({ data: { courseId, userId } }); }
      catch (e) { if ((e as { code?: string }).code === 'P2002') throw new ConflictException('Та энэ сургалтад бүртгүүлсэн байна.'); throw e; }
    }, { isolationLevel: 'Serializable' });
  }
  myEnrollments(userId: string) { return this.db.courseEnrollment.findMany({ where: { userId }, include: { course: true }, orderBy: { createdAt: 'desc' } }); }
  async completeCourse(enrollmentId: string, actor: Actor) {
    const enrollment = await this.db.courseEnrollment.findUnique({ where: { id: enrollmentId }, include: { course: true } });
    if (!enrollment) throw new NotFoundException('Бүртгэл олдсонгүй.');
    if (enrollment.course.providerId !== actor.sub && actor.role !== 'ADMIN') throw new ForbiddenException('Зөвхөн сургалт зохион байгуулагч баталгаажуулна.');
    if (enrollment.status === 'COMPLETED') throw new ConflictException('Сертификат өмнө нь үүссэн байна.');
    const token = randomBytes(32).toString('base64url');
    const certificateId = `A360-${new Date().getFullYear()}-${randomUUID().slice(0, 8).toUpperCase()}`;
    const updated = await this.db.$transaction(async (tx) => {
      const row = await tx.courseEnrollment.update({ where: { id: enrollmentId }, data: { status: 'COMPLETED', completedAt: new Date(), certificateId } });
      await tx.verificationPass.create({ data: { userId: enrollment.userId, passType: 'CERTIFICATE', referenceId: enrollment.id, tokenHash: hashToken(token) } });
      await tx.userNotification.create({ data: { userId: enrollment.userId, title: 'Сертификат бэлэн боллоо', body: `${enrollment.course.title} сургалтын сертификат үүслээ.`, type: 'CERTIFICATE' } });
      return row;
    });
    return { ...updated, verificationUrlToken: token, note: 'QR үүсгэхдээ энэ токеныг QR payload-д оруулна. Токеныг дахин харах боломжгүй.' };
  }

  listProducts() { return this.db.marketplaceProduct.findMany({ where: { isPublished: true, stock: { gt: 0 } }, orderBy: { createdAt: 'desc' }, select: { id: true, title: true, category: true, description: true, price: true, stock: true, imageUrl: true, createdAt: true } }); }
  createProduct(dto: CreateProductDto, sellerId: string) { return this.db.marketplaceProduct.create({ data: { ...dto, sellerId, isPublished: true } }); }
  async createOrder(dto: CreateOrderDto, buyerId: string) {
    const consolidated = new Map<string, number>();
    for (const item of dto.items) consolidated.set(item.productId, (consolidated.get(item.productId) ?? 0) + item.quantity);
    if (consolidated.size !== dto.items.length) throw new BadRequestException('Нэг барааг давхар мөрөөр илгээхгүй, тоо хэмжээг нэгтгэнэ үү.');
    return this.db.$transaction(async (tx) => {
      const productIds = [...consolidated.keys()];
      const products = await tx.marketplaceProduct.findMany({ where: { id: { in: productIds }, isPublished: true } });
      if (products.length !== productIds.length) throw new NotFoundException('Зарим бараа олдсонгүй эсвэл нийтлэгдээгүй байна.');
      let total = 0;
      const lines = products.map((p) => {
        const quantity = consolidated.get(p.id)!;
        if (p.stock < quantity) throw new ConflictException(`${p.title}: үлдэгдэл хүрэлцэхгүй.`);
        total += p.price * quantity;
        return { productId: p.id, quantity, unitPrice: p.price };
      });
      if (!Number.isSafeInteger(total) || total <= 0 || total > 2_147_483_647) throw new BadRequestException('Захиалгын нийт дүн зөвшөөрөгдөх хэмжээнээс хэтэрсэн байна.');
      for (const line of lines) {
        const changed = await tx.marketplaceProduct.updateMany({ where: { id: line.productId, stock: { gte: line.quantity }, isPublished: true }, data: { stock: { decrement: line.quantity } } });
        if (changed.count !== 1) throw new ConflictException('Барааны үлдэгдэл өөрчлөгдсөн байна. Дахин оролдоно уу.');
      }
      const order = await tx.marketplaceOrder.create({ data: { buyerId, totalAmount: total, items: { create: lines } }, include: { items: { include: { product: { select: { title: true } } } } } });
      await tx.paymentRecord.create({ data: { userId: buyerId, purpose: 'MARKETPLACE_ORDER', referenceId: order.id, amount: total, idempotencyKey: `order:${order.id}` } });
      return order;
    }, { isolationLevel: 'Serializable' });
  }
  myOrders(buyerId: string) { return this.db.marketplaceOrder.findMany({ where: { buyerId }, include: { items: { include: { product: { select: { title: true, imageUrl: true } } } } }, orderBy: { createdAt: 'desc' } }); }


  async requestMarketplaceRefund(orderId: string, reason: string, buyerId: string) {
    const order = await this.db.marketplaceOrder.findFirst({ where: { id: orderId, buyerId }, include: { refunds: true } });
    if (!order) throw new NotFoundException('Захиалга олдсонгүй.');
    if (order.status !== 'PAID') throw new BadRequestException('Зөвхөн төлбөр баталгаажсан захиалгад буцаалт хүснэ.');
    if (order.refunds.some((r) => ['REQUESTED', 'APPROVED', 'REFUNDED'].includes(r.status))) throw new ConflictException('Энэ захиалгад буцаалтын хүсэлт өмнө нь бүртгэгдсэн байна.');
    return this.db.marketplaceRefund.create({ data: { orderId, buyerId, reason: reason.trim(), amount: order.totalAmount } });
  }

  async reviewMarketplaceRefund(refundId: string, decision: 'APPROVED' | 'REJECTED', adminId: string) {
    const refund = await this.db.marketplaceRefund.findUnique({ where: { id: refundId } });
    if (!refund) throw new NotFoundException('Буцаалтын хүсэлт олдсонгүй.');
    if (refund.status !== 'REQUESTED') throw new ConflictException('Буцаалтын хүсэлтийг өмнө нь шийдвэрлэсэн байна.');
    return this.db.marketplaceRefund.update({ where: { id: refundId }, data: { status: decision, reviewedBy: adminId, reviewedAt: new Date() } });
  }

  async confirmMarketplaceRefund(refundId: string, providerRefundId: string, adminId: string) {
    // Call only after the payment provider confirms that money was actually returned.
    return this.db.$transaction(async (tx) => {
      const refund = await tx.marketplaceRefund.findUnique({ where: { id: refundId } });
      if (!refund) throw new NotFoundException('Буцаалтын хүсэлт олдсонгүй.');
      if (refund.status !== 'APPROVED') throw new ConflictException('Зөвшөөрөгдсөн буцаалт шаардлагатай.');
      const order = await tx.marketplaceOrder.findUnique({ where: { id: refund.orderId }, include: { items: true } });
      if (!order || order.status !== 'PAID') throw new ConflictException('Захиалгын төлөв буцаалт хийх боломжгүй байна.');
      await tx.marketplaceRefund.update({ where: { id: refundId }, data: { status: 'REFUNDED', providerRefundId, reviewedBy: adminId, reviewedAt: new Date() } });
      await tx.marketplaceOrder.update({ where: { id: order.id }, data: { status: 'REFUNDED' } });
      await tx.paymentRecord.updateMany({ where: { referenceId: order.id, purpose: 'MARKETPLACE_ORDER', status: 'PAID' }, data: { status: 'REFUNDED' } });
      await tx.marketplaceCommission.updateMany({ where: { orderId: order.id }, data: { status: 'REVERSED' } });
      for (const item of order.items) await tx.marketplaceProduct.update({ where: { id: item.productId }, data: { stock: { increment: item.quantity } } });
      await tx.userNotification.create({ data: { userId: refund.buyerId, title: 'Буцаалт баталгаажлаа', body: `${refund.amount.toLocaleString('en-US')} MNT буцаалт баталгаажлаа.`, type: 'REFUND' } });
      return { success: true, status: 'REFUNDED' };
    }, { isolationLevel: 'Serializable' });
  }

  listFitnessCenters() { return this.db.fitnessCenter.findMany({ where: { isPublished: true }, include: { plans: { where: { isActive: true } } }, orderBy: { createdAt: 'desc' } }); }
  createFitnessCenter(dto: CreateFitnessCenterDto, providerId: string) { return this.db.fitnessCenter.create({ data: { ...dto, providerId, isPublished: true } }); }
  async createFitnessPlan(centerId: string, dto: CreateFitnessPlanDto, actor: Actor) {
    const center = await this.db.fitnessCenter.findUnique({ where: { id: centerId } });
    if (!center) throw new NotFoundException('Фитнесс төв олдсонгүй.');
    if (center.providerId !== actor.sub && actor.role !== 'ADMIN') throw new ForbiddenException('Зөвхөн төвийн эзэмшигч төлөвлөгөө нэмнэ.');
    return this.db.fitnessPlan.create({ data: { ...dto, centerId } });
  }
  async subscribe(planId: string, userId: string) {
    const plan = await this.db.fitnessPlan.findFirst({ where: { id: planId, isActive: true, center: { isPublished: true } } });
    if (!plan) throw new NotFoundException('Идэвхтэй фитнесс багц олдсонгүй.');
    const startsAt = new Date(); const expiresAt = new Date(startsAt.getTime() + plan.durationDays * 86400000);
    const membership = await this.db.fitnessMembership.create({ data: { planId, userId, startsAt, expiresAt, status: 'PENDING_PAYMENT' } });
    await this.db.paymentRecord.create({ data: { userId, purpose: 'FITNESS_MEMBERSHIP', referenceId: membership.id, amount: plan.price, idempotencyKey: `membership:${membership.id}` } });
    return { ...membership, paymentStatus: 'PENDING', note: 'QPay нэхэмжлэл бодитоор үүсгэхийн тулд merchant API эрх шаардлагатай.' };
  }
  myMemberships(userId: string) { return this.db.fitnessMembership.findMany({ where: { userId }, include: { plan: { include: { center: true } } }, orderBy: { createdAt: 'desc' } }); }

  async issueMembershipPass(membershipId: string, userId: string) {
    const membership = await this.db.fitnessMembership.findFirst({ where: { id: membershipId, userId, status: 'ACTIVE', expiresAt: { gt: new Date() } } });
    if (!membership) throw new NotFoundException('Идэвхтэй фитнесс эрх олдсонгүй.');
    const token = randomBytes(32).toString('base64url');
    await this.db.verificationPass.create({ data: { userId, passType: 'FITNESS_MEMBERSHIP', referenceId: membership.id, tokenHash: hashToken(token), expiresAt: membership.expiresAt } });
    return { token, expiresAt: membership.expiresAt, qrPayload: token, note: 'QR payload-д зөвхөн энэ токеныг оруулна. Токен нэг удаа харуулагдана.' };
  }

  async verifyPass(token: string) {
    if (!/^[A-Za-z0-9_-]{30,100}$/.test(token)) throw new BadRequestException('QR токен буруу форматтай.');
    const pass = await this.db.verificationPass.findUnique({ where: { tokenHash: hashToken(token) }, include: { user: { select: { phone: true } } } });
    if (!pass || (pass.expiresAt && pass.expiresAt < new Date())) throw new NotFoundException('QR эрх хүчингүй эсвэл хугацаа дууссан.');
    if (pass.passType === 'FITNESS_MEMBERSHIP') {
      const membership = await this.db.fitnessMembership.findFirst({ where: { id: pass.referenceId, userId: pass.userId, status: 'ACTIVE', expiresAt: { gt: new Date() } }, select: { expiresAt: true } });
      if (!membership) throw new NotFoundException('Фитнесс гишүүнчлэлийн хугацаа дууссан эсвэл идэвхгүй байна.');
      return { valid: true, type: pass.passType, referenceId: pass.referenceId, expiresAt: membership.expiresAt, ownerPhoneMasked: `${pass.user.phone.slice(0, 3)}****${pass.user.phone.slice(-2)}` };
    }
    return { valid: true, type: pass.passType, referenceId: pass.referenceId, issuedAt: pass.createdAt, ownerPhoneMasked: `${pass.user.phone.slice(0, 3)}****${pass.user.phone.slice(-2)}` };
  }
  notifications(userId: string) { return this.db.userNotification.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 100 }); }
  async markNotificationRead(id: string, userId: string) {
    const result = await this.db.userNotification.updateMany({ where: { id, userId }, data: { readAt: new Date() } });
    if (!result.count) throw new NotFoundException('Мэдэгдэл олдсонгүй.');
    return { success: true };
  }
}
