import { Module } from '@nestjs/common';
import { EcosystemController } from './ecosystem.controller';
import { EcosystemService } from './ecosystem.service';
import { AuthModule } from '../auth/auth.module';

@Module({ imports: [AuthModule], controllers: [EcosystemController], providers: [EcosystemService] })
export class EcosystemModule {}
