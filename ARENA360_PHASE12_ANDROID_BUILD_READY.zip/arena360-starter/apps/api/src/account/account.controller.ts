import { Body, Controller, Delete, Get, Param, Patch, Post, Req, UseGuards } from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { AccountService } from './account.service';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { CreateFavoriteDto } from './dto/create-favorite.dto';
import { CreateReviewDto } from './dto/create-review.dto';
import { CreateChatDto } from './dto/create-chat.dto';
import { CreateMessageDto } from './dto/create-message.dto';
import { CreateSupportDto } from './dto/create-support.dto';
interface AuthRequest { user: { sub: string } }
@Controller('account')
@UseGuards(AuthGuard)
export class AccountController {
  constructor(private readonly account: AccountService) {}
  @Get('me') profile(@Req() req: AuthRequest) { return this.account.profile(req.user.sub); }
  @Patch('me') update(@Req() req: AuthRequest, @Body() body: UpdateProfileDto) { return this.account.updateProfile(req.user.sub, body); }
  @Get('me/activity') activity(@Req() req: AuthRequest) { return this.account.activity(req.user.sub); }
  @Get('me/payments') payments(@Req() req: AuthRequest) { return this.account.payments(req.user.sub); }
  @Get('me/qr') qr(@Req() req: AuthRequest) { return this.account.qr(req.user.sub); }
  @Get('me/notifications') notifications(@Req() req: AuthRequest) { return this.account.notifications(req.user.sub); }
  @Patch('me/notifications/:id/read') readNotification(@Req() req: AuthRequest, @Param('id') id: string) { return this.account.readNotification(req.user.sub, id); }
  @Get('me/favorites') favorites(@Req() req: AuthRequest) { return this.account.favorites(req.user.sub); }
  @Post('me/favorites') addFavorite(@Req() req: AuthRequest, @Body() body: CreateFavoriteDto) { return this.account.addFavorite(req.user.sub, body); }
  @Delete('me/favorites/:id') removeFavorite(@Req() req: AuthRequest, @Param('id') id: string) { return this.account.removeFavorite(req.user.sub, id); }
  @Get('me/reviews') reviews(@Req() req: AuthRequest) { return this.account.reviews(req.user.sub); }
  @Post('me/reviews') addReview(@Req() req: AuthRequest, @Body() body: CreateReviewDto) { return this.account.addReview(req.user.sub, body); }
  @Get('me/chats') chats(@Req() req: AuthRequest) { return this.account.conversations(req.user.sub); }
  @Post('me/chats') createChat(@Req() req: AuthRequest, @Body() body: CreateChatDto) { return this.account.createConversation(req.user.sub, body); }
  @Get('me/chats/:id/messages') messages(@Req() req: AuthRequest, @Param('id') id: string) { return this.account.messages(req.user.sub, id); }
  @Post('me/chats/:id/messages') sendMessage(@Req() req: AuthRequest, @Param('id') id: string, @Body() body: CreateMessageDto) { return this.account.sendMessage(req.user.sub, id, body); }
  @Get('me/support') support(@Req() req: AuthRequest) { return this.account.supportTickets(req.user.sub); }
  @Post('me/support') createSupport(@Req() req: AuthRequest, @Body() body: CreateSupportDto) { return this.account.createSupportTicket(req.user.sub, body); }
}
