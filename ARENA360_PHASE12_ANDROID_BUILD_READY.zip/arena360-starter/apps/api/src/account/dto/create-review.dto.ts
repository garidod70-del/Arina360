import { IsIn, IsInt, IsOptional, IsString, IsUUID, Max, MaxLength, Min } from 'class-validator';
export class CreateReviewDto {
  @IsIn(['VENUE','COMPETITION','COURSE','FITNESS','PRODUCT','CLUB','REFEREE','SERVICE']) targetType!: string;
  @IsUUID() targetId!: string;
  @IsInt() @Min(1) @Max(5) rating!: number;
  @IsOptional() @IsString() @MaxLength(2000) comment?: string;
}
