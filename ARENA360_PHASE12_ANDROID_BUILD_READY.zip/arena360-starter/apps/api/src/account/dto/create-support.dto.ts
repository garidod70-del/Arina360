import { IsIn, IsString, MaxLength, MinLength } from 'class-validator';
export class CreateSupportDto {
  @IsString() @MinLength(3) @MaxLength(180) subject!: string;
  @IsString() @MinLength(5) @MaxLength(4000) message!: string;
  @IsIn(['GENERAL','PAYMENT','BOOKING','ACCOUNT','BUG','OTHER']) category!: string;
}
