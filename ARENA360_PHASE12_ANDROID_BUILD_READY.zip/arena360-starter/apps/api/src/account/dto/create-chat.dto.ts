import { IsOptional, IsString, IsUUID, MaxLength } from 'class-validator';
export class CreateChatDto {
  @IsUUID() participantId!: string;
  @IsOptional() @IsString() @MaxLength(180) title?: string;
}
