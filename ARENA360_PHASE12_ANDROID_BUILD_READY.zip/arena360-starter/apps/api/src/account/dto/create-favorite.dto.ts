import { IsIn, IsUUID } from 'class-validator';
export class CreateFavoriteDto {
  @IsIn(['VENUE','COMPETITION','COURSE','FITNESS','PRODUCT','CLUB','REFEREE','SERVICE']) targetType!: string;
  @IsUUID() targetId!: string;
}
