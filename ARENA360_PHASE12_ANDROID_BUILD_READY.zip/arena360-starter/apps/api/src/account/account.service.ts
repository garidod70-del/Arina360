import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';
import { UpdateProfileDto } from './dto/update-profile.dto';
import { CreateFavoriteDto } from './dto/create-favorite.dto';
import { CreateReviewDto } from './dto/create-review.dto';
import { CreateChatDto } from './dto/create-chat.dto';
import { CreateMessageDto } from './dto/create-message.dto';
import { CreateSupportDto } from './dto/create-support.dto';

@Injectable()
export class AccountService {
  constructor(private readonly db: PrismaService) {}

  profile(userId: string) {
    return this.db.user.findUnique({ where: { id: userId }, select: { id: true, phone: true, displayName: true, email: true, avatarUrl: true, city: true, district: true, role: true, createdAt: true } });
  }
  async updateProfile(userId: string, input: UpdateProfileDto) {
    if (input.email) {
      const existing = await this.db.user.findFirst({ where: { email: input.email, NOT: { id: userId } }, select: { id: true } });
      if (existing) throw new ConflictException('Энэ имэйл хаяг өөр бүртгэлд ашиглагдаж байна.');
    }
    return this.db.user.update({ where: { id: userId }, data: input, select: { id: true, phone: true, displayName: true, email: true, avatarUrl: true, city: true, district: true, role: true, updatedAt: true } });
  }
  async activity(userId: string) {
    const [venueBookings, refereeBookings, orders, enrollments, memberships] = await Promise.all([
      this.db.booking.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 50, include: { venue: { select: { name: true, address: true } } } }),
      this.db.refereeBooking.findMany({ where: { customerId: userId }, orderBy: { createdAt: 'desc' }, take: 50, include: { referee: { select: { displayName: true } } } }),
      this.db.marketplaceOrder.findMany({ where: { buyerId: userId }, orderBy: { createdAt: 'desc' }, take: 50, include: { items: { include: { product: { select: { title: true } } } } } }),
      this.db.courseEnrollment.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 50, include: { course: { select: { title: true, startsAt: true } } } }),
      this.db.fitnessMembership.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 50, include: { plan: { include: { center: { select: { name: true } } } } } }),
    ]);
    return { venueBookings, refereeBookings, orders, courseEnrollments: enrollments, fitnessMemberships: memberships };
  }
  payments(userId: string) { return this.db.paymentRecord.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 100, select: { id: true, purpose: true, referenceId: true, amount: true, currency: true, provider: true, status: true, createdAt: true } }); }
  notifications(userId: string) { return this.db.userNotification.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 100 }); }
  async readNotification(userId: string, id: string) {
    const result = await this.db.userNotification.updateMany({ where: { id, userId, readAt: null }, data: { readAt: new Date() } });
    if (!result.count) { const found = await this.db.userNotification.findFirst({ where: { id, userId } }); if (!found) throw new NotFoundException('Мэдэгдэл олдсонгүй.'); }
    return this.db.userNotification.findFirst({ where: { id, userId } });
  }
  favorites(userId: string) { return this.db.favorite.findMany({ where: { userId }, orderBy: { createdAt: 'desc' } }); }
  async addFavorite(userId: string, input: CreateFavoriteDto) {
    try { return await this.db.favorite.create({ data: { userId, ...input } }); }
    catch (e: any) { if (e?.code === 'P2002') throw new ConflictException('Энэ зүйл дуртайд аль хэдийн нэмэгдсэн.'); throw e; }
  }
  async removeFavorite(userId: string, id: string) {
    const result = await this.db.favorite.deleteMany({ where: { id, userId } });
    if (!result.count) throw new NotFoundException('Дуртай жагсаалтын зүйл олдсонгүй.');
    return { success: true };
  }
  async addReview(userId: string, input: CreateReviewDto) {
    let eligible = false;
    const now = new Date();
    switch (input.targetType) {
      case 'REFEREE': eligible = !!(await this.db.refereeBooking.findFirst({ where: { customerId: userId, refereeId: input.targetId, status: 'COMPLETED' }, select: { id: true } })); break;
      case 'VENUE': eligible = !!(await this.db.booking.findFirst({ where: { userId, venueId: input.targetId, status: 'CONFIRMED', endsAt: { lt: now } }, select: { id: true } })); break;
      case 'PRODUCT': eligible = !!(await this.db.marketplaceOrderItem.findFirst({ where: { productId: input.targetId, order: { buyerId: userId, status: { not: 'CANCELLED' } } }, select: { id: true } })); break;
      case 'COURSE': eligible = !!(await this.db.courseEnrollment.findFirst({ where: { userId, courseId: input.targetId }, select: { id: true } })); break;
      case 'FITNESS': eligible = !!(await this.db.fitnessMembership.findFirst({ where: { userId, plan: { centerId: input.targetId } }, select: { id: true } })); break;
      case 'COMPETITION': eligible = !!(await this.db.competitionEntrant.findFirst({ where: { competitionId: input.targetId, registeredById: userId }, select: { id: true } })); break;
      case 'CLUB': case 'SERVICE': eligible = !!(await this.db.serviceInquiry.findFirst({ where: { userId, listingId: input.targetId }, select: { id: true } })); break;
    }
    if (!eligible) throw new ForbiddenException('Үнэлгээ өгөхийн тулд тухайн үйлчилгээтэй холбоотой бүртгэл эсвэл захиалга шаардлагатай.');
    return this.db.review.upsert({ where: { userId_targetType_targetId: { userId, targetType: input.targetType, targetId: input.targetId } }, create: { userId, ...input }, update: { rating: input.rating, comment: input.comment } });
  }
  reviews(userId: string) { return this.db.review.findMany({ where: { userId }, orderBy: { updatedAt: 'desc' }, take: 100 }); }
  async conversations(userId: string) {
    return this.db.chatConversation.findMany({ where: { OR: [{ participantAId: userId }, { participantBId: userId }] }, orderBy: { updatedAt: 'desc' }, include: { participantA: { select: { id: true, displayName: true } }, participantB: { select: { id: true, displayName: true } }, messages: { orderBy: { createdAt: 'desc' }, take: 1 } } });
  }
  async createConversation(userId: string, input: CreateChatDto) {
    if (input.participantId === userId) throw new BadRequestException('Өөртэйгөө чат эхлүүлэх боломжгүй.');
    const other = await this.db.user.findUnique({ where: { id: input.participantId }, select: { id: true, isActive: true } });
    if (!other?.isActive) throw new NotFoundException('Чатлах хэрэглэгч олдсонгүй.');
    const existing = await this.db.chatConversation.findFirst({ where: { OR: [{ participantAId: userId, participantBId: input.participantId }, { participantAId: input.participantId, participantBId: userId }] } });
    if (existing) return existing;
    return this.db.chatConversation.create({ data: { participantAId: userId, participantBId: input.participantId, title: input.title } });
  }
  private async assertConversationMember(userId: string, conversationId: string) {
    const conversation = await this.db.chatConversation.findUnique({ where: { id: conversationId } });
    if (!conversation) throw new NotFoundException('Харилцан яриа олдсонгүй.');
    if (conversation.participantAId !== userId && conversation.participantBId !== userId) throw new ForbiddenException('Энэ харилцан ярианд хандах эрхгүй.');
    return conversation;
  }
  async messages(userId: string, conversationId: string) {
    await this.assertConversationMember(userId, conversationId);
    await this.db.chatMessage.updateMany({ where: { conversationId, senderId: { not: userId }, readAt: null }, data: { readAt: new Date() } });
    return this.db.chatMessage.findMany({ where: { conversationId }, orderBy: { createdAt: 'asc' }, take: 200 });
  }
  async sendMessage(userId: string, conversationId: string, input: CreateMessageDto) {
    await this.assertConversationMember(userId, conversationId);
    const [message] = await this.db.$transaction([
      this.db.chatMessage.create({ data: { conversationId, senderId: userId, body: input.body } }),
      this.db.chatConversation.update({ where: { id: conversationId }, data: { updatedAt: new Date() } }),
    ]);
    return message;
  }
  supportTickets(userId: string) { return this.db.supportTicket.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 100 }); }
  createSupportTicket(userId: string, input: CreateSupportDto) { return this.db.supportTicket.create({ data: { userId, ...input } }); }
  qr(userId: string) { return { type: 'ARENA360_USER', userId, payload: `ARENA360:USER:${userId}` }; }
}
