import { IsString, Matches, MinLength, MaxLength } from 'class-validator';

export class LoginDto {
  @IsString() @Matches(/^\+?[0-9]{8,15}$/)
  phone!: string;

  @IsString() @MinLength(8) @MaxLength(72)
  password!: string;
}
