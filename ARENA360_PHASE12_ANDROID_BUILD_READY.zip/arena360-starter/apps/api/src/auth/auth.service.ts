import { BadRequestException, ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { compare, hash } from 'bcryptjs';
import { PrismaService } from '../database/prisma.service';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';

@Injectable()
export class AuthService {
  constructor(private readonly db: PrismaService, private readonly jwt: JwtService) {}

  private normalizePhone(phone: string) { return phone.replace(/[\s()-]/g, ''); }

  async register(input: RegisterDto) {
    if (!input.acceptedTerms) throw new BadRequestException('Үйлчилгээний нөхцөлийг зөвшөөрнө үү.');
    const phone = this.normalizePhone(input.phone);
    const existing = await this.db.user.findUnique({ where: { phone }, select: { id: true } });
    if (existing) throw new ConflictException('Энэ утасны дугаар бүртгэлтэй байна.');
    const passwordHash = await hash(input.password, 12);
    const user = await this.db.user.create({ data: { phone, passwordHash }, select: { id: true, phone: true, role: true, createdAt: true } });
    return { user, ...await this.issueTokens(user.id, user.phone, user.role) };
  }

  async login(input: LoginDto) {
    const phone = this.normalizePhone(input.phone);
    const user = await this.db.user.findUnique({ where: { phone } });
    if (!user || !user.isActive || !(await compare(input.password, user.passwordHash))) {
      throw new UnauthorizedException('Утасны дугаар эсвэл нууц үг буруу байна.');
    }
    const safeUser = { id: user.id, phone: user.phone, role: user.role };
    return { user: safeUser, ...await this.issueTokens(user.id, user.phone, user.role) };
  }

  async profile(userId: string) {
    const user = await this.db.user.findUnique({ where: { id: userId }, select: { id: true, phone: true, role: true, createdAt: true } });
    if (!user) throw new UnauthorizedException();
    return user;
  }

  private async issueTokens(sub: string, phone: string, role: string) {
    const accessToken = await this.jwt.signAsync({ sub, phone, role }, { secret: process.env.JWT_ACCESS_SECRET, expiresIn: '30m' });
    return { accessToken, tokenType: 'Bearer', expiresIn: 1800 };
  }
}
