import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../database/prisma.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private readonly jwt: JwtService, private readonly db: PrismaService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const header = request.headers.authorization as string | undefined;
    if (!header?.startsWith('Bearer ')) throw new UnauthorizedException('Нэвтрэх шаардлагатай.');
    let payload: { sub: string };
    try {
      payload = await this.jwt.verifyAsync<{ sub: string }>(header.slice(7), {
        secret: process.env.JWT_ACCESS_SECRET,
      });
    } catch {
      throw new UnauthorizedException('Нэвтрэх хугацаа дууссан эсвэл токен хүчингүй.');
    }

    const user = await this.db.user.findUnique({
      where: { id: payload.sub },
      select: { id: true, phone: true, role: true, isActive: true },
    });
    if (!user || !user.isActive) throw new UnauthorizedException('Бүртгэл идэвхгүй эсвэл олдсонгүй.');
    // Always use current database permissions; never trust a stale role claim in the JWT.
    request.user = { sub: user.id, phone: user.phone, role: user.role };
    return true;
  }
}
