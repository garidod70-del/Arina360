import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';

@Injectable()
export class AdminRoleGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    if (request.user?.role !== 'ADMIN') throw new ForbiddenException('Админы эрх шаардлагатай.');
    return true;
  }
}

@Injectable()
export class ProviderRoleGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    if (!['PROVIDER', 'ADMIN'].includes(request.user?.role)) {
      throw new ForbiddenException('Баталгаажсан үйлчилгээ үзүүлэгчийн эрх шаардлагатай.');
    }
    return true;
  }
}
