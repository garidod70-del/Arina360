const { PrismaClient } = require('@prisma/client');
const { hash } = require('bcryptjs');

async function main() {
  const phone = (process.env.ADMIN_BOOTSTRAP_PHONE || '').replace(/[\s()-]/g, '');
  const password = process.env.ADMIN_BOOTSTRAP_PASSWORD || '';
  if (!/^\+?[0-9]{8,15}$/.test(phone)) throw new Error('Set ADMIN_BOOTSTRAP_PHONE to a valid phone number.');
  if (password.length < 14) throw new Error('ADMIN_BOOTSTRAP_PASSWORD must contain at least 14 characters.');

  const db = new PrismaClient();
  try {
    const existing = await db.user.findUnique({ where: { phone }, select: { id: true } });
    if (existing) throw new Error('This phone already belongs to an account. Refusing to elevate or overwrite it.');
    const passwordHash = await hash(password, 12);
    const admin = await db.user.create({
      data: { phone, passwordHash, role: 'ADMIN' },
      select: { id: true, phone: true, role: true },
    });
    process.stdout.write(`Created initial admin: ${admin.phone} (${admin.id})\n`);
  } finally {
    await db.$disconnect();
  }
}

main().catch((error) => {
  process.stderr.write(`${error.message}\n`);
  process.exitCode = 1;
});
