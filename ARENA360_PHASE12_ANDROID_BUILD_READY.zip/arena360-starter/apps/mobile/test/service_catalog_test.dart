import 'package:flutter_test/flutter_test.dart';
import 'package:arena360/main.dart';

void main() {
  group('ARENA 360 service catalogue', () {
    test('contains the core service sections', () {
      final slugs = arenaServices.map((service) => service.slug).toSet();
      expect(slugs, containsAll([
        'referees',
        'clubs',
        'competitions',
        'venues',
        'marketplace',
        'education',
        'fitness',
      ]));
    });

    test('service slugs are unique and titles are not empty', () {
      final slugs = arenaServices.map((service) => service.slug).toList();
      expect(slugs.toSet().length, slugs.length);
      expect(arenaServices.every((service) => service.title.trim().isNotEmpty), isTrue);
    });
  });
}
