import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'account_page.dart';
import 'referee_page.dart';

void main() => runApp(const Arena360App());

const _navy = Color(0xFF101B36);
const _blue = Color(0xFF2878FF);
const _canvas = Color(0xFFF4F7FC);
const _apiBase = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000/api/v1');
const _secureStorage = FlutterSecureStorage();

String _targetTypeForService(String slug) => switch (slug) {
  'referees' => 'REFEREE', 'clubs' => 'CLUB', 'competitions' => 'COMPETITION', 'venues' => 'VENUE', 'marketplace' => 'PRODUCT', 'education' => 'COURSE', 'fitness' => 'FITNESS', _ => 'SERVICE',
};


Future<void> _startServiceChat(BuildContext context, Map<String, dynamic> item, String title) async {
  final participantId = (item['userId'] ?? item['providerId'] ?? item['ownerId'] ?? item['sellerId'])?.toString();
  if (participantId == null || participantId.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Энэ үйлчилгээний холбоо барих бүртгэл олдсонгүй.'))); return; }
  try {
    final token = await _secureStorage.read(key: 'arena_access_token');
    final response = await http.post(Uri.parse('$_apiBase/account/me/chats'), headers:{'Authorization':'Bearer ${token ?? ''}','Content-Type':'application/json'}, body:jsonEncode({'participantId':participantId,'title':title})).timeout(const Duration(seconds:15));
    final data=jsonDecode(response.body); if(response.statusCode<200 || response.statusCode>=300) throw Exception(data is Map ? (data['message']??'Чат эхлүүлж чадсангүй') : 'Чат эхлүүлж чадсангүй');
    if(context.mounted) { final conversation=Map<String,dynamic>.from(data as Map); Navigator.of(context).push(MaterialPageRoute(builder:(_)=>ChatDetailPage(conversationId:conversation['id'].toString(),title:title))); }
  } catch(e) { if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString()))); }
}

Future<void> _saveServiceAction(BuildContext context, ArenaService service, Map<String, dynamic> item, {required bool review}) async {
  final id = item['id']?.toString();
  if (id == null || id.isEmpty) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Энэ үйлчилгээний ID олдсонгүй.'))); return; }
  int rating = 5; final comment = TextEditingController();
  if (review) {
    final accepted = await showDialog<bool>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (dialogContext, setDialogState) => AlertDialog(title: const Text('Үнэлгээ, сэтгэгдэл'), content: Column(mainAxisSize: MainAxisSize.min, children: [DropdownButtonFormField<int>(value: rating, decoration: const InputDecoration(labelText: 'Үнэлгээ'), items: [1,2,3,4,5].map((v) => DropdownMenuItem(value:v, child: Text('$v / 5 од'))).toList(), onChanged: (v) => setDialogState(() => rating = v ?? 5)), const SizedBox(height:10), TextField(controller: comment, maxLines:3, decoration: const InputDecoration(labelText:'Сэтгэгдэл'))]), actions:[TextButton(onPressed:()=>Navigator.pop(dialogContext,false),child:const Text('Болих')),FilledButton(onPressed:()=>Navigator.pop(dialogContext,true),child:const Text('Илгээх'))])));
    if (accepted != true) { comment.dispose(); return; }
  }
  try {
    final token = await _secureStorage.read(key: 'arena_access_token');
    final endpoint = Uri.parse('$_apiBase/account/me/${review ? 'reviews' : 'favorites'}');
    final body = review ? {'targetType':_targetTypeForService(service.slug),'targetId':id,'rating':rating,'comment':comment.text.trim()} : {'targetType':_targetTypeForService(service.slug),'targetId':id};
    final response = await http.post(endpoint, headers:{'Authorization':'Bearer ${token ?? ''}','Content-Type':'application/json'}, body:jsonEncode(body)).timeout(const Duration(seconds:15));
    if (response.statusCode < 200 || response.statusCode >= 300) { final data=jsonDecode(response.body); throw Exception(data is Map ? (data['message'] ?? 'Үйлдэл амжилтгүй') : 'Үйлдэл амжилтгүй'); }
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(review ? 'Үнэлгээ хадгалагдлаа.' : 'Дуртай зүйлд нэмлээ.')));
  } catch(e) { if(context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString()))); }
  finally { comment.dispose(); }
}

class ArenaService {
  const ArenaService({required this.slug, required this.title, required this.description, required this.icon, required this.features});
  final String slug;
  final String title;
  final String description;
  final IconData icon;
  final List<String> features;
}

const arenaServices = <ArenaService>[
  ArenaService(slug: 'referees', title: 'Шүүгч', description: 'Спортын төрлөөр мэргэшсэн шүүгч хайж, мэдээлэлтэй танилцана.', icon: Icons.sports, features: ['Спортын төрөл, зэрэглэлээр хайх', 'Туршлага, байршил, үйлчилгээний үнэ', 'Эрхийн баримт бичгийн баталгаажуулалт']),
  ArenaService(slug: 'clubs', title: 'Клуб, сургалтууд', description: 'Клуб, секц болон нас, түвшинд тохирсон сургалтууд.', icon: Icons.groups, features: ['Спорт, нас, түвшин, байршлаар шүүх', 'Дасгалжуулагч, хуваарь, төлбөр', 'Сургалтад хүсэлт илгээх']),
  ArenaService(slug: 'competitions', title: 'Спортын тэмцээн', description: 'Багийн, ганцаарчилсан болон үндэсний спортын тэмцээн.', icon: Icons.emoji_events, features: ['Тэмцээн, ангилал, дүрэм', 'Оролцогчийн бүртгэл', 'Сугалаа, оноолт, үр дүн, медалийн хүснэгт']),
  ArenaService(slug: 'venues', title: 'Заал түрээс', description: 'Спортын заал, талбайн цагийн хуваарь, түрээс.', icon: Icons.stadium, features: ['Байршил, спортын төрлөөр хайх', 'Үнэ, багтаамж, тоноглол', 'Цаг сонгон захиалах']),
  ArenaService(slug: 'marketplace', title: 'Спорт бараа', description: 'Спортын хувцас, хэрэглэл, тоног төхөөрөмжийн худалдаа.', icon: Icons.shopping_bag, features: ['Барааны ангилал, үнэ, хэмжээ', 'Барааны үлдэгдэл', 'Сагс, захиалга, хүргэлт']),
  ArenaService(slug: 'education', title: 'Дасгалжуулагч, шүүгчийн сургалт', description: 'Мэргэжлийн сургалт, шалгалт, гэрчилгээ.', icon: Icons.school, features: ['Сургалтын хөтөлбөр', 'Бүртгэл, ирц, шалгалт', 'Дугаартай гэрчилгээ, QR баталгаажуулалт']),
  ArenaService(slug: 'fitness', title: 'Фитнесс', description: 'Фитнесс төв, дасгалжуулагч, гишүүнчлэл.', icon: Icons.fitness_center, features: ['Төв, тоног төхөөрөмж, хуваарь', 'Эрх, багц сонгох', 'Дасгалжуулагч, цаг захиалах']),
  ArenaService(slug: 'sports_doctor', title: 'Спортын эмч', description: 'Спортын эмчийн зөвлөгөө, үзлэгийн үйлчилгээ.', icon: Icons.medical_services, features: ['Мэргэжлийн танилцуулга', 'Байршил, үйлчилгээний мэдээлэл', 'Зөвлөгөө авах хүсэлт']),
  ArenaService(slug: 'strength_coach', title: 'Хүчний бэлтгэлийн мэргэжилтэн', description: 'Хүч, хурд, тэсвэрийн бэлтгэлийн мэргэжлийн үйлчилгээ.', icon: Icons.fitness_center, features: ['Мэргэшил, туршлага', 'Бэлтгэлийн үйлчилгээ', 'Зөвлөгөө авах хүсэлт']),
  ArenaService(slug: 'sports_psychologist', title: 'Спортын сэтгэл зүйч', description: 'Тамирчны сэтгэл зүйн бэлтгэл, зөвлөгөө.', icon: Icons.psychology, features: ['Мэргэжлийн мэдээлэл', 'Зөвлөгөөний төрөл', 'Цагийн хүсэлт']),
  ArenaService(slug: 'nutritionist', title: 'Хоол зүйч', description: 'Спортын хооллолт, шим тэжээлийн зөвлөгөө.', icon: Icons.restaurant, features: ['Мэргэжлийн мэдээлэл', 'Зөвлөгөөний үйлчилгээ', 'Цагийн хүсэлт']),
  ArenaService(slug: 'physiotherapist', title: 'Хөдөлгөөн засалч', description: 'Хөдөлгөөн засал, нөхөн сэргээх үйлчилгээ.', icon: Icons.accessibility_new, features: ['Мэргэжлийн мэдээлэл', 'Үйлчилгээний төрөл', 'Цагийн хүсэлт']),
  ArenaService(slug: 'sports_analyst', title: 'Спортын шинжээч', description: 'Тамирчин, багийн гүйцэтгэлийн шинжилгээ.', icon: Icons.query_stats, features: ['Шинжилгээний чиглэл', 'Тайлангийн үйлчилгээ', 'Хүсэлт илгээх']),
  ArenaService(slug: 'fitness_trainer', title: 'Фитнесс дасгалжуулагч', description: 'Хувийн болон бүлгийн фитнесс дасгалжуулалт.', icon: Icons.sports_gymnastics, features: ['Дасгалжуулагчийн профайл', 'Хөтөлбөр, хуваарь', 'Сургалтын хүсэлт']),
  ArenaService(slug: 'rehabilitation', title: 'Сэргээн засах мэргэжилтэн', description: 'Спортын гэмтлийн дараах сэргээн засах үйлчилгээ.', icon: Icons.healing, features: ['Мэргэжлийн мэдээлэл', 'Үйлчилгээний төрөл', 'Цагийн хүсэлт']),
];

class Arena360App extends StatelessWidget {
  const Arena360App({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ARENA 360',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: _blue),
          scaffoldBackgroundColor: _canvas,
          appBarTheme: const AppBarTheme(backgroundColor: _navy, foregroundColor: Colors.white),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
          ),
        ),
        home: const SessionGate(),
      );
}


class SessionGate extends StatefulWidget {
  const SessionGate({super.key});
  @override
  State<SessionGate> createState() => _SessionGateState();
}

class _SessionGateState extends State<SessionGate> {
  late final Future<bool> _session = _restoreSession();
  Future<bool> _restoreSession() async {
    final token = await _secureStorage.read(key: 'arena_access_token');
    if (token == null || token.isEmpty) return false;
    try {
      final response = await http.get(Uri.parse('$_apiBase/auth/me'), headers: {'Authorization': 'Bearer $token'}).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) return true;
    } catch (_) {}
    await _secureStorage.delete(key: 'arena_access_token');
    return false;
  }
  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
    future: _session,
    builder: (context, snapshot) {
      if (snapshot.connectionState != ConnectionState.done) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      return snapshot.data == true ? const HomePage() : const AuthPage();
    },
  );
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final _formKey = GlobalKey<FormState>();
  final _phone = TextEditingController();
  final _password = TextEditingController();
  final _repeat = TextEditingController();
  bool _register = false;
  bool _accepted = false;
  bool _hidePassword = true;
  bool _loading = false;

  @override
  void dispose() {
    _phone.dispose();
    _password.dispose();
    _repeat.dispose();
    super.dispose();
  }

  Future<void> _continue() async {
    if (!_formKey.currentState!.validate()) return;
    if (_register && !_accepted) {
      _message('Үйлчилгээний нөхцөлийг зөвшөөрнө үү.');
      return;
    }
    setState(() => _loading = true);
    try {
      final endpoint = Uri.parse('$_apiBase/auth/${_register ? 'register' : 'login'}');
      final payload = <String, dynamic>{'phone': _phone.text.trim(), 'password': _password.text};
      if (_register) payload['acceptedTerms'] = true;
      final response = await http.post(endpoint, headers: {'Content-Type': 'application/json'}, body: jsonEncode(payload)).timeout(const Duration(seconds: 20));
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      if (response.statusCode < 200 || response.statusCode >= 300) {
        final message = data['message'];
        throw Exception(message is List ? message.join('\n') : (message ?? 'Серверийн алдаа'));
      }
      final token = data['accessToken'] as String?;
      if (token == null || token.isEmpty) throw Exception('Сервер нэвтрэх токен буцаасангүй.');
      await _secureStorage.write(key: 'arena_access_token', value: token);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomePage()));
    } catch (error) {
      if (mounted) _message('Холболт амжилтгүй: ${error.toString().replaceFirst('Exception: ', '')}');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _message(String value) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(22),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: Form(
                  key: _formKey,
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(gradient: const LinearGradient(colors: [_navy, Color(0xFF245EDB)]), borderRadius: BorderRadius.circular(24)),
                      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Icon(Icons.sports_martial_arts, color: Colors.white, size: 38),
                        SizedBox(height: 18),
                        Text('ARENA 360', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 27, letterSpacing: 1.2)),
                        SizedBox(height: 6),
                        Text('ONE PLATFORM. ALL SPORTS.', style: TextStyle(color: Colors.white70, letterSpacing: 1.1, fontSize: 11)),
                        SizedBox(height: 18),
                        Text('Спортын ертөнц\nтаны гарт.', style: TextStyle(color: Colors.white, fontSize: 25, height: 1.2, fontWeight: FontWeight.w800)),
                      ]),
                    ),
                    const SizedBox(height: 26),
                    Text(_register ? 'Шинэ бүртгэл' : 'Тавтай морил', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: _navy)),
                    const SizedBox(height: 6),
                    Text(_register ? 'Утасны дугаараа ашиглан бүртгүүлнэ үү.' : 'Бүртгэлтэй дугаараараа нэвтэрнэ үү.', style: const TextStyle(color: Color(0xFF68758E))),
                    const SizedBox(height: 20),
                    TextFormField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Утасны дугаар', prefixIcon: Icon(Icons.phone_android)), validator: (v) {
                      final digits = (v ?? '').replaceAll(RegExp(r'\D'), '');
                      return digits.length < 8 || digits.length > 15 ? 'Утасны дугаараа зөв оруулна уу.' : null;
                    }),
                    const SizedBox(height: 12),
                    TextFormField(controller: _password, obscureText: _hidePassword, decoration: InputDecoration(labelText: 'Нууц үг', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(onPressed: () => setState(() => _hidePassword = !_hidePassword), icon: Icon(_hidePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined))), validator: (v) => (v ?? '').length < 8 ? 'Нууц үг хамгийн багадаа 8 тэмдэгт байна.' : null),
                    if (_register) ...[
                      const SizedBox(height: 12),
                      TextFormField(controller: _repeat, obscureText: true, decoration: const InputDecoration(labelText: 'Нууц үг давтах', prefixIcon: Icon(Icons.lock_reset)), validator: (v) => v != _password.text ? 'Нууц үг таарахгүй байна.' : null),
                      const SizedBox(height: 8),
                      CheckboxListTile(contentPadding: EdgeInsets.zero, value: _accepted, onChanged: (v) => setState(() => _accepted = v ?? false), title: const Text('Үйлчилгээний нөхцөл зөвшөөрч байна', style: TextStyle(fontSize: 13)), controlAffinity: ListTileControlAffinity.leading),
                    ],
                    const SizedBox(height: 12),
                    FilledButton(onPressed: _loading ? null : _continue, style: FilledButton.styleFrom(backgroundColor: _blue, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))), child: _loading ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(_register ? 'Бүртгүүлэх' : 'Нэвтрэх', style: const TextStyle(fontWeight: FontWeight.w800))),
                    TextButton(onPressed: () => setState(() => _register = !_register), child: Text(_register ? 'Бүртгэлтэй юу? Нэвтрэх' : 'Шинэ хэрэглэгч үү? Бүртгүүлэх')),
                    OutlinedButton.icon(
                      onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const HomePage())),
                      icon: const Icon(Icons.explore_outlined),
                      label: const Text('Танилцах горимоор үзэх'),
                    ),
                    const SizedBox(height: 8),
                    const Text('Бүртгэл, нэвтрэлт API сервертэй холбогдсон. SMS OTP үйлчилгээ нийлүүлэгчийн эрх шаарддаг тул хараахан идэвхжээгүй.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, height: 1.5, color: Color(0xFF7C879B))),
                  ]),
                ),
              ),
            ),
          ),
        ),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _query = '';
  @override
  Widget build(BuildContext context) {
    final filtered = arenaServices.where((s) => s.title.toLowerCase().contains(_query.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('ARENA 360', style: TextStyle(fontWeight: FontWeight.w900)), actions: [IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AccountPage())), icon: const Icon(Icons.account_circle_outlined), tooltip: 'Миний кабинет'), IconButton(onPressed: () async { await _secureStorage.delete(key: 'arena_access_token'); if (!context.mounted) return; Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AuthPage()), (route) => false); }, icon: const Icon(Icons.logout), tooltip: 'Гарах')]),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [_navy, Color(0xFF245EDB)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('ONE PLATFORM. ALL SPORTS.', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.1)), SizedBox(height: 10), Text('Спортын бүх үйлчилгээ\nнэг дор.', style: TextStyle(color: Colors.white, fontSize: 25, height: 1.2, fontWeight: FontWeight.w900)), SizedBox(height: 12), Text('Шүүгч • Клуб • Тэмцээн • Заал • Бараа • Сургалт • Фитнесс', style: TextStyle(color: Colors.white70, fontSize: 12))])),
        const SizedBox(height: 22),
        const Text('ҮЙЛЧИЛГЭЭНҮҮД', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1, color: _navy)),
        const SizedBox(height: 12),
        TextField(onChanged: (v) => setState(() => _query = v), decoration: const InputDecoration(hintText: 'Үйлчилгээ хайх', prefixIcon: Icon(Icons.search))),
        const SizedBox(height: 14),
        GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: filtered.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.12), itemBuilder: (context, index) {
          final service = filtered[index];
          return Material(color: Colors.white, borderRadius: BorderRadius.circular(18), child: InkWell(borderRadius: BorderRadius.circular(18), onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ServicePage(service: service))), child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Icon(service.icon, color: _blue, size: 30), const SizedBox(height: 12), Text(service.title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)), const SizedBox(height: 5), const Text('Дэлгэрэнгүй үзэх  →', style: TextStyle(color: _blue, fontSize: 11))]))));
        }),
        const SizedBox(height: 12),
        const Text('Үйлчилгээний жагсаалтыг ARENA 360 серверээс татаж харуулна.', style: TextStyle(color: Color(0xFF77839A), fontSize: 11, height: 1.5)),
      ]),
    );
  }
}

Future<List<Map<String, dynamic>>> _fetchServiceItems(String slug) async {
  final routes = <String, String>{
    'referees': 'referees',
    'clubs': 'listings?type=CLUB',
    'competitions': 'competitions',
    'venues': 'venues',
    'marketplace': 'marketplace/products',
    'education': 'courses',
    'fitness': 'fitness/centers',
    'sports_doctor': 'listings?type=SPORTS_DOCTOR',
    'strength_coach': 'listings?type=STRENGTH_COACH',
    'sports_psychologist': 'listings?type=SPORTS_PSYCHOLOGIST',
    'nutritionist': 'listings?type=NUTRITIONIST',
    'physiotherapist': 'listings?type=PHYSIOTHERAPIST',
    'sports_analyst': 'listings?type=SPORTS_ANALYST',
    'fitness_trainer': 'listings?type=FITNESS_TRAINER',
    'rehabilitation': 'listings?type=REHABILITATION_SPECIALIST',
  };
  final route = routes[slug];
  if (route == null) return [];
  final response = await http.get(Uri.parse('$_apiBase/$route')).timeout(const Duration(seconds: 15));
  if (response.statusCode < 200 || response.statusCode >= 300) throw Exception('Сервер ${response.statusCode} алдаа буцаалаа.');
  final decoded = jsonDecode(response.body);
  if (decoded is! List) return [];
  return decoded.whereType<Map>().map((item) => Map<String, dynamic>.from(item)).toList();
}

class ServicePage extends StatelessWidget {
  const ServicePage({super.key, required this.service});
  final ArenaService service;

  String _title(Map<String, dynamic> item) => (item['title'] ?? item['name'] ?? 'Нэргүй үйлчилгээ').toString();
  String _subtitle(Map<String, dynamic> item) {
    final parts = <String>[];
    for (final key in ['sport', 'address', 'location', 'division', 'category', 'status']) {
      final value = item[key];
      if (value != null && value.toString().isNotEmpty) parts.add(value.toString());
    }
    if (item['price'] != null) parts.add('${item['price']} ₮');
    if (item['hourlyPrice'] != null) parts.add('${item['hourlyPrice']} ₮ / цаг');
    return parts.join(' • ');
  }

  @override
  Widget build(BuildContext context) {
    if (service.slug == 'referees') return const RefereeDirectoryPage();
    return Scaffold(
    appBar: AppBar(title: Text(service.title)),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(service.icon, color: _blue, size: 38), const SizedBox(height: 14), Text(service.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: _navy)), const SizedBox(height: 8), Text(service.description, style: const TextStyle(color: Color(0xFF657089), height: 1.5))])),
      const SizedBox(height: 20),
      const Text('БОЛОМЖТОЙ ҮЙЛЧИЛГЭЭ', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: .8)),
      const SizedBox(height: 10),
      FutureBuilder<List<Map<String, dynamic>>>(
        future: _fetchServiceItems(service.slug),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) return const Padding(padding: EdgeInsets.all(28), child: Center(child: CircularProgressIndicator()));
          if (snapshot.hasError) return Card(color: Colors.white, child: Padding(padding: const EdgeInsets.all(16), child: Text('Сервертэй холбогдож чадсангүй. API хаяг болон серверээ шалгана уу.\n${snapshot.error}', style: const TextStyle(fontSize: 12))));
          final items = snapshot.data ?? [];
          if (items.isEmpty) return const Card(color: Colors.white, child: Padding(padding: EdgeInsets.all(18), child: Text('Одоогоор нийтлэгдсэн үйлчилгээ алга байна.')));
          return Column(children: items.map((item) => Card(color: Colors.white, elevation: 0, child: ListTile(
            leading: CircleAvatar(backgroundColor: const Color(0xFFEAF1FF), child: Icon(service.icon, color: _blue)),
            title: Text(_title(item), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            subtitle: Text(_subtitle(item).isEmpty ? (item['description'] ?? 'Дэлгэрэнгүй мэдээлэл').toString() : _subtitle(item), maxLines: 2, overflow: TextOverflow.ellipsis),
            trailing: Wrap(spacing: 0, children: [IconButton(tooltip: 'Дуртайд нэмэх', onPressed: () => _saveServiceAction(context, service, item, review: false), icon: const Icon(Icons.favorite_border, color: _blue)), IconButton(tooltip: 'Үнэлгээ өгөх', onPressed: () => _saveServiceAction(context, service, item, review: true), icon: const Icon(Icons.star_border, color: _blue)), IconButton(tooltip: 'Чат эхлүүлэх', onPressed: () => _startServiceChat(context, item, _title(item)), icon: const Icon(Icons.chat_bubble_outline, color: _blue))]),
          ))).toList());
        },
      ),
      const SizedBox(height: 12),
      const Text('Тэмдэглэл: захиалга, төлбөрийн бүрэн урсгал болон зарим дэлгэцийн үйлдлүүд үргэлжлэн хөгжүүлэгдэж байна.', style: TextStyle(color: Color(0xFF77839A), fontSize: 12, height: 1.5)),
    ]),
    );
  }
}
