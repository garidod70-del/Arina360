import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:qr_flutter/qr_flutter.dart';

const _accountApi = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000/api/v1');
const _accountStorage = FlutterSecureStorage();
const _accountBlue = Color(0xFF2878FF);
const _accountNavy = Color(0xFF101B36);

Future<Map<String, String>> _headers() async {
  final token = await _accountStorage.read(key: 'arena_access_token');
  return {'Authorization': 'Bearer ${token ?? ''}', 'Content-Type': 'application/json'};
}

Future<dynamic> _get(String path) async {
  final response = await http.get(Uri.parse('$_accountApi/$path'), headers: await _headers()).timeout(const Duration(seconds: 15));
  final data = response.body.isEmpty ? null : jsonDecode(response.body);
  if (response.statusCode < 200 || response.statusCode >= 300) throw Exception(data is Map ? (data['message'] ?? 'Серверийн алдаа').toString() : 'Серверийн алдаа');
  return data;
}

Future<void> _deleteRequest(String path) async {
  final response = await http.delete(Uri.parse('$_accountApi/$path'), headers: await _headers()).timeout(const Duration(seconds: 15));
  final data = response.body.isEmpty ? null : jsonDecode(response.body);
  if (response.statusCode < 200 || response.statusCode >= 300) throw Exception(data is Map ? (data['message'] ?? 'Устгаж чадсангүй').toString() : 'Устгаж чадсангүй');
}

Future<dynamic> _sendRequest(String method, String path, [Map<String, dynamic>? body]) async {
  final uri = Uri.parse('$_accountApi/$path');
  final headers = await _headers();
  final response = method == 'PATCH'
      ? await http.patch(uri, headers: headers, body: jsonEncode(body ?? {})).timeout(const Duration(seconds: 15))
      : await http.post(uri, headers: headers, body: jsonEncode(body ?? {})).timeout(const Duration(seconds: 15));
  final data = response.body.isEmpty ? null : jsonDecode(response.body);
  if (response.statusCode < 200 || response.statusCode >= 300) throw Exception(data is Map ? (data['message'] ?? 'Үйлдэл амжилтгүй').toString() : 'Үйлдэл амжилтгүй');
  return data;
}

class AccountPage extends StatefulWidget {
  const AccountPage({super.key});
  @override
  State<AccountPage> createState() => _AccountPageState();
}

class _AccountPageState extends State<AccountPage> {
  late Future<Map<String, dynamic>> _profile = _loadProfile();
  Future<Map<String, dynamic>> _loadProfile() async => Map<String, dynamic>.from(await _get('account/me') as Map);
  void _refresh() => setState(() => _profile = _loadProfile());

  Future<void> _edit(Map<String, dynamic> profile) async {
    final name = TextEditingController(text: profile['displayName']?.toString() ?? '');
    final email = TextEditingController(text: profile['email']?.toString() ?? '');
    final city = TextEditingController(text: profile['city']?.toString() ?? '');
    final district = TextEditingController(text: profile['district']?.toString() ?? '');
    final avatar = TextEditingController(text: profile['avatarUrl']?.toString() ?? '');
    await showDialog<void>(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('Хувийн мэдээлэл засах'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Овог, нэр')),
        const SizedBox(height: 10), TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Имэйл')),
        const SizedBox(height: 10), TextField(controller: city, decoration: const InputDecoration(labelText: 'Хот / аймаг')),
        const SizedBox(height: 10), TextField(controller: district, decoration: const InputDecoration(labelText: 'Дүүрэг / сум')),
        const SizedBox(height: 10), TextField(controller: avatar, decoration: const InputDecoration(labelText: 'Зурагны URL (сонголтоор)')),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('Болих')), FilledButton(onPressed: () async {
        try {
          await _sendRequest('PATCH', 'account/me', {'displayName': name.text.trim(), 'email': email.text.trim().isEmpty ? null : email.text.trim(), 'city': city.text.trim(), 'district': district.text.trim(), 'avatarUrl': avatar.text.trim().isEmpty ? null : avatar.text.trim()});
          if (!dialogContext.mounted) return; Navigator.pop(dialogContext); _refresh();
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Мэдээлэл шинэчлэгдлээ.')));
        } catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
      }, child: const Text('Хадгалах'))],
    ));
    name.dispose(); email.dispose(); city.dispose(); district.dispose(); avatar.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Миний кабинет')),
    body: FutureBuilder<Map<String, dynamic>>(
      future: _profile,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
        if (snapshot.hasError) return _StatePanel(icon: Icons.cloud_off, title: 'Мэдээлэл ачаалж чадсангүй', detail: snapshot.error.toString(), action: 'Дахин оролдох', onAction: _refresh);
        final p = snapshot.data ?? {};
        final name = (p['displayName'] ?? 'ARENA 360 хэрэглэгч').toString();
        return ListView(padding: const EdgeInsets.all(16), children: [
          Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [_accountNavy, Color(0xFF245EDB)]), borderRadius: BorderRadius.circular(22)), child: Row(children: [
            CircleAvatar(radius: 28, backgroundColor: Colors.white24, child: Text(name.isEmpty ? 'A' : name.substring(0, 1).toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900))),
            const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)), const SizedBox(height: 4), Text((p['phone'] ?? '').toString(), style: const TextStyle(color: Colors.white70)), Text((p['email'] ?? 'Имэйл бүртгүүлээгүй').toString(), style: const TextStyle(color: Colors.white70, fontSize: 12))])),
            IconButton(onPressed: () => _edit(p), icon: const Icon(Icons.edit, color: Colors.white), tooltip: 'Засах'),
          ])),
          const SizedBox(height: 18),
          const Text('ХУВИЙН КАБИНЕТ', style: TextStyle(fontWeight: FontWeight.w900, color: _accountNavy, letterSpacing: .8)),
          const SizedBox(height: 8),
          _AccountTile(icon: Icons.edit_note, title: 'Хувийн мэдээлэл засах', subtitle: 'Нэр, имэйл, байршил', onTap: () => _edit(p)),
          _AccountTile(icon: Icons.history, title: 'Захиалгын түүх ба календарь', subtitle: 'Заал, шүүгч, сургалт, фитнесс', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BookingCalendarPage()))),
          _AccountTile(icon: Icons.payments_outlined, title: 'Төлбөрийн түүх', onTap: () => _openData('account/me/payments', 'Төлбөрийн түүх')),
          _AccountTile(icon: Icons.qr_code_2, title: 'Миний QR код', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AccountQrPage()))),
          _AccountTile(icon: Icons.notifications_none, title: 'Мэдэгдлийн төв', onTap: () => _openData('account/me/notifications', 'Мэдэгдлүүд')),
          _AccountTile(icon: Icons.favorite_border, title: 'Дуртай зүйлс', onTap: () => _openData('account/me/favorites', 'Дуртай зүйлс')),
          _AccountTile(icon: Icons.star_border, title: 'Үнэлгээ, сэтгэгдэл', onTap: () => _openData('account/me/reviews', 'Миний үнэлгээ')),
          _AccountTile(icon: Icons.chat_bubble_outline, title: 'Чат, мессеж', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatListPage()))),
          _AccountTile(icon: Icons.support_agent, title: 'Тусламж, санал хүсэлт', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SupportPage()))),
          _AccountTile(icon: Icons.description_outlined, title: 'Үйлчилгээний нөхцөл', onTap: () => _showPolicy('Үйлчилгээний нөхцөл')),
          _AccountTile(icon: Icons.privacy_tip_outlined, title: 'Нууцлалын бодлого', onTap: () => _showPolicy('Нууцлалын бодлого')),
          const SizedBox(height: 8),
          const Text('Сүлжээ тасарсан үед өмнөх мэдээлэл харагдахгүй байж болно. Холболт сэргэсний дараа дахин ачаална уу.', style: TextStyle(color: Colors.black54, fontSize: 12)),
        ]);
      },
    ),
  );

  Future<void> _openData(String path, String title) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => AccountDataPage(path: path, title: title)));
  }
  void _showPolicy(String title) => showDialog<void>(context: context, builder: (_) => AlertDialog(title: Text(title), content: const Text('Энэхүү хэсэгт ARENA 360-ийн баталгаажсан үйлчилгээний нөхцөл болон нууцлалын бодлогын албан ёсны эхийг нийтэлнэ. Одоогоор эрх зүйн баримт бичгийн эцсийн хувилбар холбогдоогүй байна.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Хаах'))]));
}

class AccountQrPage extends StatelessWidget {
  const AccountQrPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Миний QR код')), body: FutureBuilder<dynamic>(future: _get('account/me/qr'), builder: (context, s) {
    if (s.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
    if (s.hasError) return _StatePanel(icon: Icons.cloud_off, title: 'QR ачаалж чадсангүй', detail: s.error.toString());
    final payload = (s.data as Map)['payload'].toString();
    return Center(child: Card(margin: const EdgeInsets.all(24), child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.sports, color: _accountBlue, size: 34), const SizedBox(height: 8), const Text('ARENA 360 USER ID', style: TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 16), QrImageView(data: payload, size: 220), const SizedBox(height: 12), SelectableText(payload, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Colors.black54))]))));
  }));
}

class AccountDataPage extends StatelessWidget {
  const AccountDataPage({super.key, required this.path, required this.title});
  final String path; final String title;
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(title)), body: FutureBuilder<dynamic>(future: _get(path), builder: (context, s) {
    if (s.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
    if (s.hasError) return _StatePanel(icon: Icons.cloud_off, title: 'Мэдээлэл татаж чадсангүй', detail: s.error.toString());
    final data = s.data;
    final rows = data is List ? data : (data is Map ? data.entries.map((e) => {'title': e.key, 'value': e.value}).toList() : <dynamic>[]);
    if (rows.isEmpty) return const _StatePanel(icon: Icons.inbox_outlined, title: 'Одоогоор мэдээлэл алга', detail: 'Шинэ захиалга, төлбөр эсвэл үйлдэл нэмэгдэхэд энд харагдана.');
    return ListView(padding: const EdgeInsets.all(12), children: rows.map<Widget>((item) {
      final map = item is Map ? Map<String, dynamic>.from(item) : {'value': item};
      final heading = (map['title'] ?? map['name'] ?? map['purpose'] ?? map['type'] ?? map['id'] ?? 'Мэдээлэл').toString();
      final details = map.entries.where((e) => !['id','userId','customerId','refereeId'].contains(e.key) && e.value != null && e.value is! Map && e.value is! List).map((e) => '${e.key}: ${e.value}').take(5).join('\n');
      final unread = map['readAt'] == null && path.endsWith('notifications');
      return Card(color: Colors.white, elevation: 0, child: ListTile(onTap: unread ? () async { await _sendRequest('PATCH', 'account/me/notifications/${map['id']}/read'); } : null, leading: CircleAvatar(backgroundColor: const Color(0xFFEAF1FF), child: Icon(unread ? Icons.notifications_active : Icons.article_outlined, color: _accountBlue)), title: Text(heading, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)), subtitle: Text(details.isEmpty ? 'Дэлгэрэнгүй мэдээлэл' : details, maxLines: 4, overflow: TextOverflow.ellipsis), trailing: path.endsWith('favorites') ? IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { try { await _deleteRequest('account/me/favorites/${map['id']}'); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Дуртай жагсаалтаас хаслаа.'))); } catch (e) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); } }) : (unread ? const Icon(Icons.mark_email_read_outlined) : null)));
    }).toList());
  }));
}


class BookingCalendarPage extends StatefulWidget { const BookingCalendarPage({super.key}); @override State<BookingCalendarPage> createState() => _BookingCalendarPageState(); }
class _BookingCalendarPageState extends State<BookingCalendarPage> {
  DateTime _selected = DateTime.now();
  late Future<Map<String, dynamic>> _activity = _load();
  Future<Map<String, dynamic>> _load() async => Map<String, dynamic>.from(await _get('account/me/activity') as Map);
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Захиалгын календарь')), body: FutureBuilder<Map<String,dynamic>>(future:_activity,builder:(context,s){
    if(s.connectionState==ConnectionState.waiting) return const Center(child:CircularProgressIndicator());
    if(s.hasError) return _StatePanel(icon:Icons.cloud_off,title:'Захиалга ачаалж чадсангүй',detail:s.error.toString());
    final data=s.data??{}; final entries=<Map<String,dynamic>>[];
    for(final key in ['venueBookings','refereeBookings','orders','courseEnrollments','fitnessMemberships']) { final value=data[key]; if(value is List) { for(final item in value) { if(item is Map) entries.add({...Map<String,dynamic>.from(item),'_category':key}); } } }
    final dated=entries.where((e){ final raw=e['startsAt']??e['createdAt']; if(raw==null) return false; final dt=DateTime.tryParse(raw.toString())?.toLocal(); return dt!=null && dt.year==_selected.year && dt.month==_selected.month && dt.day==_selected.day; }).toList();
    return ListView(padding:const EdgeInsets.all(12),children:[Card(color:Colors.white,child:CalendarDatePicker(initialDate:_selected,firstDate:DateTime(2020),lastDate:DateTime(2035),onDateChanged:(d)=>setState(()=>_selected=d))), Padding(padding:const EdgeInsets.all(10),child:Text('${_selected.year}-${_selected.month.toString().padLeft(2,'0')}-${_selected.day.toString().padLeft(2,'0')} өдрийн захиалга',style:const TextStyle(fontWeight:FontWeight.w900))), if(dated.isEmpty) const _StatePanel(icon:Icons.event_available,title:'Энэ өдөр захиалга алга',detail:'Өөр өдөр сонгох эсвэл шинэ захиалга үүсгэнэ үү.') else ...dated.map((e){ final title=(e['venue'] is Map ? e['venue']['name'] : null)??(e['referee'] is Map ? e['referee']['displayName'] : null)??(e['course'] is Map ? e['course']['title'] : null)??(e['sport']??e['status']??'Захиалга'); return Card(color:Colors.white,child:ListTile(leading:const Icon(Icons.event,color:_accountBlue),title:Text(title.toString()),subtitle:Text('${e['startsAt']??e['createdAt']} • ${e['status']??e['_category']}'))); })]);
  }));
}

class ChatListPage extends StatelessWidget { const ChatListPage({super.key}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Чат, мессеж')),body:FutureBuilder<dynamic>(future:_get('account/me/chats'),builder:(context,s){if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());if(s.hasError)return _StatePanel(icon:Icons.cloud_off,title:'Чат ачаалж чадсангүй',detail:s.error.toString());final rows=s.data as List? ?? [];if(rows.isEmpty)return const _StatePanel(icon:Icons.chat_bubble_outline,title:'Чат байхгүй',detail:'Үйлчилгээ үзүүлэгч эсвэл шүүгчтэй холбогдоход чат энд харагдана.');return ListView(children:rows.map<Widget>((raw){final m=Map<String,dynamic>.from(raw as Map);final msgs=m['messages'] as List? ?? []; final last=msgs.isNotEmpty ? msgs.first : null;final title=(m['title']??'ARENA 360 чат').toString();return ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(title),subtitle:Text(last is Map ? (last['body']??'').toString() : 'Мессеж бичих'),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ChatDetailPage(conversationId:m['id'].toString(),title:title))));}).toList());})); }

class ChatDetailPage extends StatefulWidget { const ChatDetailPage({super.key,required this.conversationId,required this.title}); final String conversationId,title; @override State<ChatDetailPage> createState()=>_ChatDetailPageState(); }
class _ChatDetailPageState extends State<ChatDetailPage>{final _text=TextEditingController();late Future<dynamic> _messages=_load();bool _sending=false;Future<dynamic> _load()=>_get('account/me/chats/${widget.conversationId}/messages');void _refresh()=>setState(()=>_messages=_load());@override void dispose(){_text.dispose();super.dispose();}Future<void> _send()async{if(_text.text.trim().isEmpty)return;setState(()=>_sending=true);try{await _sendMessage();_text.clear();_refresh();}catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}finally{if(mounted)setState(()=>_sending=false);}}Future<void> _sendMessage()=>_sendRequest('POST','account/me/chats/${widget.conversationId}/messages',{'body':_text.text.trim()});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.title)),body:Column(children:[Expanded(child:FutureBuilder<dynamic>(future:_messages,builder:(context,s){if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());if(s.hasError)return _StatePanel(icon:Icons.cloud_off,title:'Мессеж ачаалж чадсангүй',detail:s.error.toString());final rows=s.data as List? ?? [];if(rows.isEmpty)return const _StatePanel(icon:Icons.forum_outlined,title:'Эхний мессежээ бичээрэй',detail:'Харилцаагаа эндээс эхлүүлнэ.');return ListView(padding:const EdgeInsets.all(12),children:rows.map<Widget>((r){final m=Map<String,dynamic>.from(r as Map);return Align(alignment:Alignment.centerLeft,child:Container(margin:const EdgeInsets.symmetric(vertical:4),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFFEAF1FF),borderRadius:BorderRadius.circular(14)),child:Text((m['body']??'').toString())));}).toList());})),SafeArea(child:Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(controller:_text,decoration:const InputDecoration(hintText:'Мессеж бичих'))),const SizedBox(width:8),IconButton(onPressed:_sending?null:_send,icon:const Icon(Icons.send,color:_accountBlue))])))]));}

class SupportPage extends StatefulWidget { const SupportPage({super.key}); @override State<SupportPage> createState() => _SupportPageState(); }
class _SupportPageState extends State<SupportPage> {
  final _subject = TextEditingController(); final _message = TextEditingController(); String _category = 'GENERAL'; bool _sending = false;
  @override void dispose() { _subject.dispose(); _message.dispose(); super.dispose(); }
  Future<void> _submit() async {
    if (_subject.text.trim().length < 3 || _message.text.trim().length < 5) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Гарчиг болон хүсэлтээ бүрэн бичнэ үү.'))); return; }
    setState(() => _sending = true);
    try { await _sendRequest('POST', 'account/me/support', {'subject': _subject.text.trim(), 'message': _message.text.trim(), 'category': _category}); if (mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Таны хүсэлт бүртгэгдлээ.'))); Navigator.pop(context); } }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString()))); }
    finally { if (mounted) setState(() => _sending = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Тусламж, санал хүсэлт')), body: ListView(padding: const EdgeInsets.all(18), children: [DropdownButtonFormField<String>(value: _category, items: const [DropdownMenuItem(value:'GENERAL',child:Text('Ерөнхий')),DropdownMenuItem(value:'PAYMENT',child:Text('Төлбөр')),DropdownMenuItem(value:'BOOKING',child:Text('Захиалга')),DropdownMenuItem(value:'ACCOUNT',child:Text('Бүртгэл')),DropdownMenuItem(value:'BUG',child:Text('Алдаа мэдээлэх')),DropdownMenuItem(value:'OTHER',child:Text('Бусад'))], onChanged: (v) => setState(() => _category = v ?? 'GENERAL'), decoration: const InputDecoration(labelText: 'Ангилал')), const SizedBox(height:12), TextField(controller:_subject, decoration:const InputDecoration(labelText:'Гарчиг')), const SizedBox(height:12), TextField(controller:_message, minLines:5, maxLines:8, decoration:const InputDecoration(labelText:'Дэлгэрэнгүй')), const SizedBox(height:18), FilledButton(onPressed:_sending?null:_submit, child:_sending?const CircularProgressIndicator():const Text('Илгээх'))]));
}

class _AccountTile extends StatelessWidget { const _AccountTile({required this.icon, required this.title, this.subtitle, required this.onTap}); final IconData icon; final String title; final String? subtitle; final VoidCallback onTap; @override Widget build(BuildContext context) => Card(color: Colors.white, elevation: 0, child: ListTile(onTap: onTap, leading: CircleAvatar(backgroundColor: const Color(0xFFEAF1FF), child: Icon(icon, color: _accountBlue)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)), subtitle: subtitle == null ? null : Text(subtitle!), trailing: const Icon(Icons.chevron_right))); }
class _StatePanel extends StatelessWidget { const _StatePanel({required this.icon, required this.title, required this.detail, this.action, this.onAction}); final IconData icon; final String title; final String detail; final String? action; final VoidCallback? onAction; @override Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size:42, color: Colors.blueGrey), const SizedBox(height:12), Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize:16)), const SizedBox(height:6), Text(detail, textAlign:TextAlign.center, style:const TextStyle(color:Colors.black54)), if(action != null) ...[const SizedBox(height:14), OutlinedButton(onPressed:onAction, child:Text(action!))]]))); }
