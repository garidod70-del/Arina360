# ARENA 360 — Phase 8–9 implementation status

## Source baseline
- Input: `ARENA360_COMPLETE_SOURCE_PHASE7(2).zip`
- ZIP integrity: verified
- Source entries: 123
- Mobile: Flutter app in `apps/mobile`
- API: NestJS + Prisma in `apps/api`
- Admin: Next.js in `apps/admin-web`

## Implemented in this source update
1. Added dedicated referee profile and referee booking Prisma models.
2. Added PostgreSQL migration `20261117080000_referee_module`.
3. Added NestJS referee module:
   - `GET /api/v1/referees` — list approved referee profiles; optional `sport` and `region` filters.
   - `GET /api/v1/referees/me` — authenticated user's profile and recent bookings.
   - `POST /api/v1/referees/me` — create/update referee application; resets review state to pending.
   - `POST /api/v1/referees/bookings` — authenticated customer requests a referee booking.
   - `PATCH /api/v1/referees/bookings/:id/:status` — referee/customer permitted state transitions.
   - `GET /api/v1/referees/admin/pending` — admin-only pending referee applications.
   - `PATCH /api/v1/referees/admin/:id/:decision` — admin-only approve/reject.
4. Added overlap checks for referee booking requests and server-side price calculation from referee service/travel/meal fees.
5. Connected the referee mobile service list to the new `/referees` API endpoint.

## Not yet implemented / not verified
This update does NOT claim the entire master specification is complete. Remaining work includes:
- Full referee license document upload and federation verification workflow.
- Referee booking payment/invoice integration and refund lifecycle.
- Coach, doctor, strength specialist, psychologist, nutritionist, physiotherapist and analyst dedicated profiles/workflows.
- Full club management and athlete/parent portals.
- Sport-specific competition rules, referee scoring screens, live scoring and advanced draw formats.
- Venue calendar UI, conflict-safe availability and cancellation/refund policies.
- Marketplace cart, inventory, delivery, returns and seller settlement.
- Course video delivery, exams, attendance and certificate QR verification.
- Fitness subscriptions, entry scanner and membership renewals.
- FCM push notifications, in-app messaging and chat attachments.
- Unified QR issuance/scanning and replay protection.
- Full admin management pages and audit workflows.
- OTP provider integration, password reset, refresh-token rotation and device/session management.
- Full payment production credentials, webhook verification, reconciliation, split settlement and eBarimt integration.
- Security hardening, backups, monitoring, accessibility, localization review and full automated test coverage.
- Release APK build and real-device installation test.

## Required validation before deployment
Run from `apps/api`:
1. `npm ci`
2. `npx prisma validate`
3. `npx prisma generate`
4. `npx prisma migrate deploy` against a backed-up staging database
5. `npm run build`

Run from `apps/mobile`:
1. `flutter pub get`
2. `flutter analyze`
3. `flutter test`
4. `flutter build apk --release --dart-define=API_BASE_URL=https://YOUR_API_HOST/api/v1`

Do not deploy until migrations, API build, tests, credentials, CORS, HTTPS and real-device checks pass.
