# ARENA 360 Android APK build

The Flutter Android project is generated in CI so the source archive stays small. The repository workflow `.github/workflows/android-apk.yml` generates the Android platform, resolves dependencies, analyzes Dart, runs Flutter tests, builds an ARM64 release APK, verifies the package/signature, then installs and launches it on an Android  emulator.

## Build from GitHub Actions (phone-friendly)

1. Upload/push this complete source tree to the GitHub repository's `main` branch.
2. Open **Actions → ARENA 360 Android APK → Run workflow**.
3. Enter the real, publicly reachable HTTPS API base URL, ending in `/api/v1` (for example `https://api.your-domain.mn/api/v1`). Do not use `api.example.mn` or a localhost address for a physical phone build.
4. Wait for `build-and-install-test` to finish successfully.
5. Open the completed run, scroll to **Artifacts**, and download `ARENA360-ANDROID-APK-...`. Extract the ZIP and install `app-release.apk` on the Android phone.

The workflow's manual build rejects placeholder/example API URLs. Push-triggered builds use an intentionally invalid placeholder only for compilation checks and are not distributable builds.

## Local build

Requirements: Flutter 3.24.5, Android SDK, JDK 17, and a reachable API server.

```bash
cd apps/mobile
flutter create --platforms=android --project-name arena360 --org mn.arena360 .
flutter pub get
flutter analyze
flutter test
flutter build apk --release --target-platform android-arm64 \\
  --dart-define=API_BASE_URL=https://api.your-domain.mn/api/v1
```

Output: `build/app/outputs/flutter-apk/app-release.apk`.

## Release limitations

- This CI APK is signed with the generated Android debug key for installation/testing. It is not a permanent production signing identity. Configure a private release keystore and a protected GitHub Actions secret before publishing updates to end users; keep the same keystore for every future update.
- Emulator install/launch verifies packaging and startup only. It does not prove that QPay, SMS/OTP, live backend, real-money refunds, notifications, or every business workflow works end-to-end.
- The API must be deployed over HTTPS and configured with production database, secrets, CORS and payment-provider credentials before public distribution.
- A physical Android device test remains required before production release.
