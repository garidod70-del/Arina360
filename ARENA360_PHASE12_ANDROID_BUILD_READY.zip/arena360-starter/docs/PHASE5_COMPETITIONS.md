# ARENA 360 — Phase 5: Competition & tournament engine

## Included
- Competition creation by an approved provider or administrator.
- Registration open/close lifecycle (registration opens from DRAFT; bracket generation locks registration).
- Individual and team entrant registration, with optional club name.
- Randomized single-elimination bracket generation, including automatic byes for non-power-of-two entrant counts.
- Pre-generated match tree with round and match numbers.
- Match result validation: winner must be one of the two entrants, scores must be non-negative and non-tied, and score winner must match selected winner.
- Automatic winner advancement into the next round and automatic tournament completion at the final.
- Public competition details, bracket, match scores, and podium (gold/silver plus semifinal bronze places).
- Owner/admin authorization for competition management and results.

## API
All routes are under `/api/v1`.

| Method | Route | Access | Purpose |
|---|---|---|---|
| GET | `/competitions` | Public | List active/public competitions |
| GET | `/competitions/:id` | Public | Entrants, bracket, results, podium |
| POST | `/competitions` | Provider/Admin | Create competition |
| POST | `/competitions/:id/registration/open` | Owner/Admin | Open entrant registration |
| POST | `/competitions/:id/entrants` | Authenticated user | Register individual/team; records submitting account |
| POST | `/competitions/:id/bracket/generate` | Owner/Admin | Lock registration and generate bracket |
| PATCH | `/competitions/:id/matches/:matchId/result` | Owner/Admin | Record result and advance winner |

### Example payloads

Create competition:
```json
{"title":"Залуучуудын жүдо 2026","sport":"Жүдо","division":"-66 кг","venue":"Улаанбаатар"}
```

Register entrant:
```json
{"name":"Бат-Эрдэнэ","kind":"INDIVIDUAL","club":"Гарди жудо клуб"}
```

Record result:
```json
{"winnerEntrantId":"00000000-0000-4000-8000-000000000001","scoreA":10,"scoreB":3}
```

## Database
Migration: `20261116050000_competitions`. It adds competition, entrant, and match tables, indexes, unique constraints, and basic score/round checks.

## Verification status
Source and migration have been added. This environment currently does not have the required installed Node dependencies/Prisma generated client or a running PostgreSQL service, so compilation, migration execution, API integration tests, and concurrency tests remain pending. Do not treat the module as production-verified until those checks pass.
