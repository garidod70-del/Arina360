# ARENA 360 Master Feature Backlog V2

This is the full implementation acceptance checklist requested for the platform. A checklist item is not considered complete until code, API, persistence, permissions, UI and tests are present.

## Mobile application
- [ ] Premium home, all service screens, search, filters, detail pages
- [ ] User profile, bookings, payment history, favorites, ratings, help and settings
- [ ] Offline/error/loading/empty states and responsive layouts
- [ ] Push/in-app notifications, chat, QR camera scanner
- [ ] Dark mode and Mongolian localization review

## Identity and access
- [ ] Phone OTP, password reset, refresh-token rotation
- [ ] Device/session management and account deletion
- [ ] Role and resource ownership checks on every private endpoint
- [ ] Provider credential uploads, expiry reminders and review history

## Referee service
- [x] Referee profile persistence and admin approval state
- [x] Approved profile listing with sport/region filters
- [x] Booking request, overlap check and fee calculation
- [x] Referee/customer booking status changes with ownership checks
- [ ] License file upload, federation verification, public referee history
- [ ] Availability calendar, group/team booking, payment and settlement
- [ ] QR identity credential and performance reports

## Coaches and specialists
- [ ] Coach profiles, qualifications, training plans, students, attendance and reports
- [x] Provider listing categories for sports doctor, strength coach, psychologist, nutritionist, physiotherapist, analyst, fitness trainer and rehabilitation specialist (basic listing only)
- [ ] Full specialist credential/profile, appointment, consent and service-record workflows
- [ ] Appointment booking, teleconsultation, consent and service records

## Clubs and athletes
- [ ] Club onboarding, location, sports, age/skill groups, fees and schedules
- [ ] Athlete/student enrollment, guardian access, attendance and progress
- [ ] Athlete profile, medals, competition history and verified achievements
- [ ] Club finance and inter-club competition tools

## Competitions
- [ ] Competition registration, divisions and fees
- [ ] Single/double elimination, round robin and sport-specific formats
- [ ] Judo, wrestling, volleyball and other sport rule engines
- [ ] Referee assignment, scoring, chief-referee approval and result audit
- [ ] Live scoreboard, medal table, team ranking and PDF exports

## Venues
- [ ] Venue media, facilities, capacity, location and pricing
- [ ] Availability calendar, double-booking protection and cancellation rules
- [ ] Booking QR, check-in and provider revenue analytics

## Marketplace
- [ ] Catalog, variants, inventory, cart and checkout
- [ ] QPay checkout, shipping, delivery status, returns and refunds
- [ ] Seller dashboard, promotions and sales reporting

## Education and certification
- [ ] Course publishing, video lessons, materials and enrollment
- [ ] Attendance, exams, scores and certificate issuance
- [ ] QR certificate verification, expiry and revocation

## Fitness
- [ ] Center profile, facilities, plans and subscriptions
- [ ] Trainer appointments, membership renewal and check-in
- [ ] QR entry, attendance and center analytics

## Payments and finance
- [ ] QPay sandbox and production integration with verified callbacks
- [ ] Idempotency, reconciliation, refund and payment audit
- [ ] Platform commission, provider payouts and statements
- [ ] Tax receipt/eBarimt integration subject to provider access

## QR, messaging and notifications
- [ ] Signed, expiring, revocable QR tokens with replay protection
- [ ] QR scanning app and scan audit
- [ ] FCM, notification preferences and event-driven alerts
- [ ] Real-time chat, read receipts and secure file attachments

## Admin and operations
- [ ] Admin authentication and role-based pages
- [ ] User/provider/referee/club/competition/venue/product/course/fitness moderation
- [ ] Payments, refunds, complaints, reviews and commission controls
- [ ] CSV/PDF reports and immutable admin audit events
- [ ] Monitoring, backups, restore drills and incident logging

## Quality gates
- [ ] Prisma validation and migration tests
- [ ] API unit/integration/security tests
- [ ] Flutter analyze/widget/integration tests
- [ ] Admin production build
- [ ] Android release APK signing and installation test
- [ ] Staging acceptance test with real provider credentials
