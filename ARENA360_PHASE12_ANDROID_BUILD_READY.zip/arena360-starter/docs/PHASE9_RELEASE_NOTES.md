# ARENA 360 — Phase 9 incremental source update

## Changes included
- Provider listing API now accepts the additional specialist categories: sports doctor, strength coach, sports psychologist, nutritionist, physiotherapist, sports analyst, fitness trainer and rehabilitation specialist.
- Flutter home catalogue exposes these specialist service categories and loads each category from the existing listings API.
- Mobile logout now clears the persisted access token before navigating to the authentication screen.
- Admin dashboard metrics include the count of referee applications awaiting review.
- Retains the dedicated referee profile, booking, admin review API and Prisma migration introduced in Phase 8.

## Important scope note
This is an incremental implementation, not a completed implementation of every item in `MASTER_FEATURE_BACKLOG_V2.md`. Specialist categories currently support basic provider listings and inquiry flow through the existing ecosystem module. They do not yet provide clinical records, medical appointment workflows, training plans, chat, complete booking/payment lifecycle or dedicated specialist credential verification.

## Validation status
- Source ZIP extraction and file edits: completed.
- Flutter analyze/build: not run (Flutter SDK is unavailable in this environment).
- NestJS build / Prisma validation: not run (dependencies are not installed in this source workspace).
- PostgreSQL migration execution: not run (requires a configured database).
- Android APK: not built or verified.

## Before deployment
Install dependencies, run Prisma validation/generation, deploy migrations to a backed-up staging database, run API and Flutter tests, configure secrets and HTTPS, then build and install the signed release APK on a physical Android device.
