# ARENA 360 — QA acceptance checklist

## Authentication
- [ ] Register with valid Mongolian phone number format.
- [ ] Reject duplicate phone number.
- [ ] Reject mismatched password confirmation.
- [ ] Require accepted terms.
- [ ] OTP expires, cannot be reused, and resend is rate-limited.
- [ ] Password stored only as a secure hash.
- [ ] Login, refresh, logout, password reset work.
- [ ] USER/PROVIDER/ADMIN permissions are enforced server-side.

## Provider governance
- [ ] Provider starts as PENDING.
- [ ] Unapproved provider and its content are not publicly listed.
- [ ] Admin approval/rejection is recorded in audit log.
- [ ] Provider can only edit its own resources.

## Seven services
- [ ] Referee sport categories, profiles, credentials and availability.
- [ ] Clubs: sport, location, age, level, schedule, capacity and fees.
- [ ] Competitions: team/individual/traditional categories and registrations.
- [ ] Venues: opening hours, slots, hourly rates and media.
- [ ] Marketplace: categories, cart, inventory, orders and delivery states.
- [ ] Education: enrollment, payment, attendance, assessment and certificate.
- [ ] Fitness: centers, packages, memberships, booking and QR access.

## Booking and payments
- [ ] Concurrent requests cannot reserve the same resource/time twice.
- [ ] Booking state transitions are validated.
- [ ] Cancellation policy is enforced.
- [ ] QPay invoice and webhook are tested in sandbox.
- [ ] Duplicate webhook does not duplicate payment/settlement.
- [ ] Client cannot mark a payment paid.
- [ ] Refund and failed payment states are traceable.

## QR
- [ ] QR contains opaque token only, not personal data.
- [ ] Expired, revoked and already-used QR are rejected.
- [ ] Concurrent scans cannot exceed max uses.
- [ ] Every scan attempt is auditable.

## Tournament operations
- [ ] Format is sport-specific.
- [ ] Draw/bracket generation is reproducible and validated.
- [ ] Scores and results have revision history.
- [ ] Official result requires authorized approval.
- [ ] Medal table matches approved results.

## Analytics, notifications, admin
- [ ] Provider analytics are tenant-scoped.
- [ ] Admin aggregate analytics are permission-protected.
- [ ] CSV/PDF exports match source totals.
- [ ] Notification preferences are respected.
- [ ] Audit log captures sensitive admin actions.

## Quality and release
- [ ] API unit/integration tests pass.
- [ ] Mobile widget/integration tests pass.
- [ ] Admin web build and role-protected navigation pass.
- [ ] Offline, loading, empty and error states are usable.
- [ ] Security and rate-limit tests pass.
- [ ] Load tests cover search, booking and webhook endpoints.
- [ ] APK built in release mode, installed and tested on real Android device.
- [ ] iOS build tested on macOS/Xcode before iOS release.
