# Phase 7 — QPay and release pipeline

## QPay Merchant V2 source integration

- Obtain a merchant access token using Basic authentication.
- Create an invoice for an existing pending `PaymentRecord`.
- Persist QPay `invoice_id` against the unique payment record.
- Return QPay QR/deep-link payload unchanged to the client.
- QPay callback URL includes a dedicated random shared secret; callback request data is not treated as proof of payment.
- Both callback and authenticated status polling call QPay `/v2/payment/check` server-to-server.
- Local payment state changes only when a PAID MNT payment row exactly matches the expected invoice amount.
- Payment update and associated marketplace/fitness state changes occur in one serializable database transaction.
- Duplicate callbacks are idempotent: an already-paid payment returns PAID without reapplying state changes.

## Configuration

Required environment variables:

- `QPAY_BASE_URL` — sandbox or production Merchant V2 base URL.
- `QPAY_USERNAME`, `QPAY_PASSWORD` — credentials issued to the merchant.
- `QPAY_INVOICE_CODE` — merchant invoice code.
- `QPAY_CALLBACK_URL` — public HTTPS origin for the ARENA 360 API.
- `QPAY_CALLBACK_SECRET` — independent random secret, at least 32 characters.

Do not store merchant credentials in the mobile app, browser, Git repository or logs. Only the API server calls QPay.

## Payment API

- `POST /api/v1/payments/qpay/invoices` — authenticated owner creates/gets the QPay invoice for a pending payment record.
- `GET /api/v1/payments/:id/status` — authenticated owner checks status; the API independently queries QPay when an invoice exists.
- `POST /api/v1/payments/qpay/callback/:paymentRecordId?key=...` — callback shared-secret check followed by server-to-server QPay verification.

## Automated build pipeline

`.github/workflows/ci.yml` adds GitHub Actions jobs for:
- API dependencies, Prisma generation/validation, PostgreSQL migrations and Nest build.
- Admin Next.js production build.
- Flutter analysis and release APK artifact generation after Android platform scaffolding is generated.

The APK workflow uses a placeholder API origin. Before distributing a release, configure the real HTTPS API URL, build with that URL, sign using protected release keystore secrets, install on physical Android devices and run the release checklist.

## Not complete until external prerequisites are supplied

No QPay merchant credentials or publicly reachable HTTPS callback endpoint were supplied in this development environment, so sandbox payment transactions were not run. SMS OTP and password recovery still require the selected SMS provider's API contract and credentials. Refund, merchant settlement, seller payouts, eBarimt and payment reconciliation remain separate release items.
