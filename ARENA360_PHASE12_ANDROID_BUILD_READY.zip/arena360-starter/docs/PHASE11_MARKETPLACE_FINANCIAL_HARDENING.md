# ARENA 360 — Phase 11 Marketplace Financial Hardening

## Implemented

- Unique marketplace commission ledger, created atomically when QPay verification transitions an order to PAID.
- Commission rate stored as 500 basis points (5%); whole-MNT rounding is explicit.
- Idempotent commission creation keyed by unique order ID, protecting against repeated QPay callbacks.
- One refund request per order, buyer ownership validation, and admin-only review/confirmation routes.
- Provider refund reference required before final refund confirmation; order and payment status are updated, commission is reversed, stock is restored, and buyer notification is sent in one transaction.
- Marketplace order total is checked against PostgreSQL INTEGER limits before inventory is decremented.

## API routes

- `POST /api/v1/marketplace/orders/:id/refunds` — authenticated buyer requests refund.
- `PATCH /api/v1/admin/marketplace/refunds/:id/review` — admin approves or rejects.
- `POST /api/v1/admin/marketplace/refunds/:id/confirm` — admin records an already completed provider refund.

## Deployment

Run `npx prisma migrate deploy`, `npx prisma generate`, and `npm run build` in `apps/api`.

## External verification still required

- QPay merchant sandbox/production credentials and a real callback test.
- Actual QPay refund execution/confirmation; current endpoint records the provider-confirmed refund and does not initiate it.
- PostgreSQL-backed integration tests and end-to-end Android tests on a physical device.
- Flutter/Android SDK are not included in this source archive; APK compilation and device installation must be run in a configured Android build environment.
