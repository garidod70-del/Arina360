# ARENA 360 implementation roadmap and traceability

This roadmap preserves all 29 sections of the master specification.

| Phase | Scope | Acceptance evidence |
|---|---|---|
| 1 | Architecture, all screens, flows, design system | Architecture, screen inventory, approved UI |
| 2 | PostgreSQL, migrations, API foundation, auth/OTP | Migration tests, auth integration tests |
| 3 | Referees, clubs, competitions, venues, marketplace, education, fitness | CRUD/search/permissions and service tests |
| 4 | USER/PROVIDER/ADMIN RBAC and provider approval | Unauthorized access tests; approval audit |
| 5 | Smart booking calendar, pricing, cancellations | Concurrent double-booking test |
| 6 | QR issue/scan/expiry/reuse protection | Certificate and fitness QR API implemented; scanner UI and security tests pending |
| 7 | Tournament engine by sport | Single-elimination and round-robin API implemented; sport-specific rules and result approval pending |
| 8 | Analytics, exports, notifications | Basic admin metrics and in-app notifications implemented; provider analytics, exports and push pending |
| 9 | QPay invoices, webhooks, refunds, commissions | Merchant V2 invoice and server-side payment verification coded; sandbox, refunds and commissions pending |
| 10 | Next.js admin dashboard | Role-protected admin workflows |
| 11 | Integrated QA, security, performance, bug fixing | QA report and resolved defect log |
| 12 | Android APK, real-device test, deployment | Signed APK, installation evidence, release notes |

## Non-negotiable release gates
- No unapproved provider listing.
- No client-trusted payment-success state.
- No duplicate active reservation for the same resource/time.
- No QR personal data embedded in the QR payload.
- No official competition result without authorized approval and audit history.
- No secret credentials committed to source control.
- No claim of APK readiness before release build, installation and device testing.

## Current baseline
Current source includes the modules described in the README and Phase 1–7 notes. Implemented source is not equivalent to tested production capability: each feature must move from `IMPLEMENTED` to `TESTED` with evidence before being described as complete.
