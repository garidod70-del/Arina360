# ARENA 360 system architecture

## Product boundary
ARENA 360 is a professional sports digital ecosystem and marketplace, not a static information app. The complete scope is governed by `MASTER_DEVELOPMENT_SPECIFICATION_V1.0.md`.

## Applications
- Flutter mobile client for Android and iOS.
- Next.js responsive admin dashboard.
- NestJS modular-monolith API.
- PostgreSQL as transactional source of truth.
- Redis for cache, rate limiting and queue coordination.
- Object storage for profile images, credentials, course materials and media.
- Firebase Cloud Messaging for push notifications.
- QPay server-side payment integration.

## Backend modules
`auth`, `users`, `roles`, `organizations`, `providers`, `referees`, `clubs`,
`competitions`, `venues`, `products`, `orders`, `education`, `fitness`,
`bookings`, `payments`, `qr`, `analytics`, `notifications`, `reviews`,
`commissions`, `settlements`, `complaints`, `audit`, `admin`.

## Roles
- USER
- PROVIDER
- ADMIN

Provider content is private/unpublished until admin approval. Provider APIs must enforce tenant ownership; an organization cannot read or mutate another organization's data.

## Seven service areas
1. Referee services: volleyball, basketball, 3x3 basketball, judo, freestyle wrestling.
2. Clubs and training.
3. Competitions: team, individual and traditional sports.
4. Venue rental.
5. Sports goods marketplace.
6. Coach/referee education, attendance, assessment and certificates.
7. Fitness centers, packages, memberships and access.

## Five advanced systems
1. Smart booking calendar, pricing, state machine and server-side concurrency protection.
2. QR verification with opaque hashed tokens, expiry, revocation and atomic use limits.
3. Provider and platform analytics, CSV/PDF exports.
4. Sport-specific tournament draws, brackets, schedules, scoring and authorized result approval.
5. In-app and push notifications with user preferences.

## Payment trust boundary
Mobile clients may request an invoice and display payment state, but cannot assert payment success. The API verifies QPay callbacks, deduplicates events, reconciles provider transaction IDs, and updates order/booking state in a database transaction. Secrets are environment/secret-manager values and never shipped in the app.

## Booking concurrency
Availability shown to clients is advisory. The API must reserve a slot in a transaction and enforce a database-level overlap constraint or equivalent lock. Expired holds and cancellation rules must be handled consistently.

## Tournament integrity
Sport-specific rules are isolated behind format/rules modules. Draws, score revisions and result approvals are persisted. Official results require explicit permission and an audit trail.

## Security baseline
Password hashing, OTP expiry/rate limits, short-lived access tokens, refresh rotation, RBAC, DTO validation, rate limiting, tenant scoping, webhook verification, audit logs, encrypted transport, secret management and backups.

## Deployment environments
Separate local, staging and production environments. Production requires monitoring, structured logs, backup/restore drills, migrations, secret management and release rollback procedure.
