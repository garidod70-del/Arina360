# ARENA 360 development status — 2026-11-16

## Implemented in source (not yet runtime-verified)
1. Phone/password authentication with bcrypt password hashing and JWT.
2. Public seven-service catalog.
3. Provider applications, admin approval/rejection, provider role promotion, and admin audit records.
4. Venue listings, provider venue creation, customer bookings/history/cancellation, server-side price calculation, serializable transaction, and PostgreSQL overlap exclusion constraint.
5. Competition creation, registration, randomized single-elimination bracket generation, byes, match result validation, winner advancement, completion state, and podium summary.
6. Sport service listings for referee, club and coach providers; public catalog, provider publishing and customer inquiry notifications.
7. Training course publishing, enrollment/capacity checks, completion and unique certificate identifiers.
8. QR verification endpoint using cryptographically random tokens; only SHA-256 token hashes are stored.
9. Sports marketplace product catalog, stock-aware order creation, transactionally decremented inventory and pending payment records.
10. Fitness center/plan catalog, membership creation and pending payment records.
11. In-app notification inbox and read state.
12. Admin API dashboard metrics, user listing, payment listing and order listing.
13. Flutter login/register calls the API and stores the access token using secure storage; session restoration and secure logout are added; API base URL is configurable with `--dart-define=API_BASE_URL=...`.
14. QPay Merchant V2 invoice creation, cached access token, callback shared-secret check, server-to-server payment verification, exact MNT amount check, and local paid-state transitions for marketplace/fitness are implemented. Venue bookings now create pending payment records.
15. API liveness/readiness endpoints and minimum JWT secret startup validation are added.

## Important remaining work / external dependencies
- SMS OTP and password reset delivery (requires an SMS provider and credentials). Current API registration verifies accepted terms but does not send OTP.
- QPay live/sandbox execution requires merchant credentials, invoice code, public HTTPS callback URL and callback secret. The callback is verified by server-to-server payment check; QPay credentials are not available in this environment. Refunds, settlement/payout and reconciliation remain outstanding.
- Payment lifecycle handling and stock-hold expiry/release.
- QR scanner UI and staff/provider scan screens remain outstanding. Certificate and active fitness-membership QR tokens are issued and hashed server-side; fitness pass expiry is checked.
- Training attendance, lesson materials and exams.
- Pool play, sport-specific judo/wrestling brackets, referee approval and official result audit history (single elimination and round robin are implemented).
- Advanced provider analytics, reviews, delivery tracking and push notifications (FCM).
- Complete Flutter screens and admin dashboard UI/API integration, refresh-token rotation and account recovery.
- Production deployment, secrets management, observability, backups, rate limiting and security review.

## Verification caveat
TypeScript syntax transpilation: 44 files, zero syntax diagnostics. This is not a semantic type-check; full type-check is not possible without the project dependencies. `npm install` did not complete within the available execution window. Therefore Prisma client generation, full type-check/build, PostgreSQL migration execution, API runtime/integration tests, Flutter analysis, APK build and physical Android testing have NOT been completed. A GitHub Actions CI workflow and Dockerfiles for API/admin have been added; the workflow has not been run because the source has not been pushed from this environment. No production readiness or APK completion is claimed.
