# ARENA 360 — Phase 6 ecosystem modules

All endpoints below are under `/api/v1`.

## Provider listings (referee, club, coach)
- `GET /listings` — public published listings.
- `POST /listings` — verified provider/admin creates a `REFEREE`, `CLUB` or `COACH` listing.
- `POST /listings/:id/publish` — listing owner/admin publishes.
- `POST /listings/:id/inquiries` — authenticated user sends an inquiry; provider receives an in-app notification.
- `GET /listings/inquiries/mine` — provider's incoming inquiries.

## Training / certificates
- `GET /courses` — published courses.
- `POST /courses` — verified provider/admin creates a course.
- `POST /courses/:id/publish` — course owner/admin publishes.
- `POST /courses/:id/enroll` — authenticated user enrolls; capacity and duplicate checks.
- `GET /courses/enrollments/mine` — own enrollments.
- `POST /courses/enrollments/:id/complete` — course owner/admin marks completion and issues certificate ID + one-time verification token.

## QR verification
- `GET /passes/verify/:token` — public verification endpoint. Only SHA-256 token hashes are stored; raw token is returned once on issue. QR can encode the verification URL containing this token. Current certificate tokens do not expire; event/fitness pass expiry and one-time consumption are not yet wired.

## Marketplace
- `GET /marketplace/products` — published items in stock.
- `POST /marketplace/products` — verified provider/admin publishes a product.
- `POST /marketplace/orders` — authenticated order; server recalculates prices, checks stock, decrements inventory atomically, and creates a pending payment record.
- `GET /marketplace/orders/mine` — own orders.

## Fitness
- `GET /fitness/centers` — published centers and active plans.
- `POST /fitness/centers` — verified provider/admin creates center.
- `POST /fitness/centers/:id/plans` — center owner/admin adds plan.
- `POST /fitness/plans/:id/subscribe` — authenticated user creates a pending membership and payment record.
- `GET /fitness/memberships/mine` — own memberships.

## Notifications
- `GET /notifications/mine` — latest 100 notifications.
- `PATCH /notifications/:id/read` — mark own notification as read.

## Admin API
- `GET /admin/dashboard` — platform aggregate metrics.
- `GET /admin/users?limit=50` — recent user list (limit 1–100).
- `GET /admin/payments?status=PENDING` — recent payment records.
- `GET /admin/orders` — recent marketplace orders.

## Payment integration boundary

Orders and memberships create `PENDING` payment records only. No payment is marked successful from a client request. A real QPay invoice and signed callback handler must be connected using merchant credentials and QPay's current API contract before accepting live money. Do not manually set a payment to paid.

## Migration

`20261116060000_ecosystem` adds these tables, foreign keys, indexes and database checks. Run `npm run prisma:generate` and `npm run db:deploy` after configuring PostgreSQL. The migration has not been run against a live database in this environment.
