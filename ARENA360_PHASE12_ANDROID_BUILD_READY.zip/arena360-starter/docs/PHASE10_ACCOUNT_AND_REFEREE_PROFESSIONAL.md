# ARENA 360 — Phase 10: User Account & Professional Referee Workflows

## Included in this source update

### User account API (`/api/v1/account`)
- `GET /me`, `PATCH /me`: profile and editable name, email, avatar URL, city and district.
- `GET /me/activity`: venue bookings, referee bookings, marketplace orders, course enrollments and fitness memberships.
- `GET /me/payments`: payment history scoped to the authenticated user.
- `GET /me/qr`: account QR payload (`ARENA360:USER:<user UUID>`).
- `GET /me/notifications`, `PATCH /me/notifications/:id/read`: notification center and ownership-checked read action.
- `GET/POST /me/favorites`, `DELETE /me/favorites/:id`: saved items.
- `GET/POST /me/reviews`: one editable review per user/target.
- `GET/POST /me/chats`, `GET/POST /me/chats/:id/messages`: private two-person conversations; membership is checked for every message operation.
- `GET/POST /me/support`: support tickets and feedback.

### Flutter account screens
- Profile summary and edit dialog.
- Booking date selector/history, payment history, QR view, notifications, favorites, reviews, chat list/message view, support request form.
- Loading, empty and connection-error states are included.
- Service cards expose favorite, review and chat actions where the listing includes a provider/user ID.

### Professional referee API (`/api/v1/referees`)
- Profile includes sports, rank/license data, experience, region/city/district, federation name/document URL, availability JSON, service fee, travel, meal and lodging expenses.
- Public directory returns approved, non-suspended referee profiles and their fee/availability fields.
- Multi-referee booking creates one booking per referee under a shared `groupId`. Each referee must separately accept or reject. Time-overlap checks run in a serializable transaction.
- Fees are snapshotted into each booking so later price edits do not rewrite historical income.
- Referees can complete their own accepted bookings and submit one event report per completed booking.
- Personal dashboard derives completed booking count, report count, average rating and income from persisted records.
- QR credential is generated server-side. `GET /qr/:token` validates it against an approved, non-suspended profile.
- Admin-only actions support profile approval/rejection, federation verification, suspension and restoration. Actions are written to `admin_audit_logs`.

### Flutter referee screens
- Referee directory with multi-select and team booking request.
- Referee professional cabinet, profile editor, booking accept/reject/complete actions, event report form, QR ID and earnings summary.

### Admin web
- Referee list with approve/reject, federation verification, suspend and restore controls.

## Database migration

`apps/api/prisma/migrations/20261117100000_account_and_referee_professional/migration.sql`

This migration adds account profile columns, referee professional fields, a suspended provider status, referee booking fee snapshots/group IDs, favorites, reviews, conversations/messages, support tickets and event reports.

Run:

```bash
cd apps/api
npm install
npx prisma generate
npx prisma validate
npm run db:deploy
npm run build
```

For Android:

```bash
cd apps/mobile
flutter pub get
flutter analyze
flutter build apk --release --dart-define=API_BASE_URL=https://YOUR_API_HOST/api/v1
```

## Important implementation boundaries

- The source ZIP was statically inspected and archive integrity was checked. This environment does not have Flutter/Dart, PostgreSQL, Docker, or installed project dependencies; the Prisma migration, API build, Flutter analyzer, device tests and APK build have **not** been run here.
- The GitHub Actions workflow already defines API schema validation/migration/build and Android analyze/release-APK jobs. Push this source to the repository and run the workflow to obtain CI verification and the APK artifact.
- Terms and privacy screens are placeholders until the platform owner supplies approved legal text.
- Federation verification is an admin decision based on the submitted evidence URL; no federation API integration is configured.
- Availability is stored and displayed as user-supplied JSON. Automatic calendar-rule validation against every booking has not yet been implemented.
- Chat is persisted request/response messaging; real-time sockets and push notifications are not configured.
- User QR is a profile identifier display. Referee QR has a server-side verification endpoint.
- Support ticket creation is implemented; a full support-agent response console is not included in this phase.
- The broader payment provider, marketplace fulfillment and tournament-specific workflows retain their earlier implementation boundaries documented in previous phase notes.
