# ARENA 360 — API module map (REST /api/v1)

All protected routes require authenticated access and server-side RBAC. Provider resources are scoped to the owning provider/organization. Public reads must filter out providers and content that are not approved/published.

## Auth
- `POST /auth/register`
- `POST /auth/otp/verify`
- `POST /auth/otp/resend`
- `POST /auth/login`
- `POST /auth/token/refresh`
- `POST /auth/logout`
- `POST /auth/password/forgot`
- `POST /auth/password/reset`

## Users and provider approval
- `/users`, `/users/me`
- `/providers`, `/providers/me`
- `/providers/:id/submit`
- `/admin/providers/:id/approve`
- `/admin/providers/:id/reject`

## Seven services
- `/referees`
- `/clubs`
- `/competitions`
- `/venues`
- `/products`, `/orders`, `/cart`
- `/courses`, `/course-enrollments`, `/certificates`
- `/fitness-centers`, `/fitness-memberships`

## Advanced systems
- `/bookings` — availability, create, confirm, cancel, history
- `/qr/tokens`, `/qr/verify`, `/qr/scans`
- `/analytics/provider`, `/analytics/admin`, `/analytics/exports`
- `/competitions/:id/draw`, `/matches`, `/results`, `/medals`
- `/notifications`, `/notifications/preferences`, `/notifications/:id/read`

## Payments and revenue
- `POST /payments/qpay/invoice`
- `POST /payments/qpay/webhook`
- `GET /payments/:id`
- `/admin/commissions`
- `/providers/me/settlements`

## Admin
- `/admin/dashboard`
- `/admin/users`
- `/admin/providers`
- `/admin/bookings`
- `/admin/payments`
- `/admin/competitions`
- `/admin/courses`
- `/admin/complaints`
- `/admin/audit-logs`
- `/admin/settings`

## API rules
- Validate all request DTOs on the server.
- Use pagination and stable sorting for lists.
- Use idempotency keys for payment/order/booking creation where retries are possible.
- Never accept payment success from the mobile client as proof of payment.
- Verify QPay webhook authenticity and reconcile payment state server-side.
- Apply rate limits to OTP, login, password reset, QR verification and public search.
- Return consistent error envelopes and correlation IDs.
- Publish OpenAPI/Swagger documentation from the running API.
