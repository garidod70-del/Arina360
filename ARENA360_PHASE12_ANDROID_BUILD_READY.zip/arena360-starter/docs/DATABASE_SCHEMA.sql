-- ARENA 360 initial PostgreSQL domain schema (foundation)
-- This is a starting migration design, not a complete production migration.
-- Apply additional constraints, indexes, retention policies and tests before production.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE account_role AS ENUM ('USER', 'PROVIDER', 'ADMIN');
CREATE TYPE provider_status AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'SUSPENDED');
CREATE TYPE booking_status AS ENUM ('PENDING', 'CONFIRMED', 'PAYMENT_PENDING', 'COMPLETED', 'CANCELLED');
CREATE TYPE payment_status AS ENUM ('INITIATED', 'PENDING', 'PAID', 'FAILED', 'REFUNDED');
CREATE TYPE tournament_status AS ENUM ('DRAFT', 'REGISTRATION_OPEN', 'REGISTRATION_CLOSED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED');

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone VARCHAR(32) NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name VARCHAR(160),
  profile_image_url TEXT,
  is_phone_verified BOOLEAN NOT NULL DEFAULT FALSE,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE user_roles (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role account_role NOT NULL,
  PRIMARY KEY (user_id, role)
);

CREATE TABLE organizations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(220) NOT NULL,
  registration_number VARCHAR(100),
  contact_phone VARCHAR(32),
  address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE provider_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  organization_id UUID REFERENCES organizations(id),
  status provider_status NOT NULL DEFAULT 'PENDING',
  provider_type VARCHAR(80) NOT NULL,
  description TEXT,
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMPTZ,
  rejection_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE referee_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  sport_type VARCHAR(100) NOT NULL,
  referee_grade VARCHAR(120),
  certificate_file_url TEXT,
  experience_years NUMERIC(4,1),
  service_price NUMERIC(14,2),
  location TEXT,
  verification_status VARCHAR(40) NOT NULL DEFAULT 'PENDING'
);

CREATE TABLE clubs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  name VARCHAR(220) NOT NULL,
  sport_type VARCHAR(100) NOT NULL,
  location TEXT NOT NULL,
  age_min INT,
  age_max INT,
  training_level VARCHAR(100),
  coach_name VARCHAR(160),
  schedule JSONB NOT NULL DEFAULT '[]',
  fee_amount NUMERIC(14,2),
  capacity INT,
  media JSONB NOT NULL DEFAULT '[]',
  is_published BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE competitions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  name VARCHAR(240) NOT NULL,
  sport_group VARCHAR(40) NOT NULL,
  sport_type VARCHAR(100) NOT NULL,
  format VARCHAR(100),
  rules_document_url TEXT,
  registration_opens_at TIMESTAMPTZ,
  registration_closes_at TIMESTAMPTZ,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  venue TEXT,
  entry_fee NUMERIC(14,2),
  capacity INT,
  status tournament_status NOT NULL DEFAULT 'DRAFT',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE competition_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  competition_id UUID NOT NULL REFERENCES competitions(id) ON DELETE CASCADE,
  age_category VARCHAR(100),
  weight_category VARCHAR(100),
  gender_category VARCHAR(40),
  rules_config JSONB NOT NULL DEFAULT '{}'
);

CREATE TABLE competition_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  competition_id UUID NOT NULL REFERENCES competitions(id),
  category_id UUID REFERENCES competition_categories(id),
  entry_type VARCHAR(20) NOT NULL,
  participant_name VARCHAR(220) NOT NULL,
  participant_data JSONB NOT NULL DEFAULT '{}',
  payment_status payment_status NOT NULL DEFAULT 'INITIATED',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE matches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  competition_id UUID NOT NULL REFERENCES competitions(id),
  category_id UUID REFERENCES competition_categories(id),
  round_name VARCHAR(120),
  match_order INT NOT NULL,
  participant_a UUID REFERENCES competition_entries(id),
  participant_b UUID REFERENCES competition_entries(id),
  score_a JSONB,
  score_b JSONB,
  result_entry_id UUID REFERENCES competition_entries(id),
  is_official BOOLEAN NOT NULL DEFAULT FALSE,
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMPTZ
);

CREATE TABLE venues (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  name VARCHAR(220) NOT NULL,
  address TEXT NOT NULL,
  capacity INT,
  dimensions VARCHAR(120),
  equipment JSONB NOT NULL DEFAULT '[]',
  sport_types JSONB NOT NULL DEFAULT '[]',
  hourly_price NUMERIC(14,2) NOT NULL,
  opening_hours JSONB NOT NULL DEFAULT '{}',
  media JSONB NOT NULL DEFAULT '[]',
  is_published BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  name VARCHAR(240) NOT NULL,
  category VARCHAR(120) NOT NULL,
  description TEXT,
  price NUMERIC(14,2) NOT NULL,
  sizes JSONB NOT NULL DEFAULT '[]',
  colors JSONB NOT NULL DEFAULT '[]',
  stock_quantity INT NOT NULL DEFAULT 0,
  image_urls JSONB NOT NULL DEFAULT '[]',
  delivery_terms TEXT,
  is_published BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  name VARCHAR(240) NOT NULL,
  course_type VARCHAR(100) NOT NULL,
  instructor_name VARCHAR(180),
  organizer VARCHAR(180),
  curriculum TEXT,
  delivery_mode VARCHAR(30) NOT NULL,
  starts_at TIMESTAMPTZ,
  ends_at TIMESTAMPTZ,
  registration_deadline TIMESTAMPTZ,
  price NUMERIC(14,2),
  is_published BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE fitness_centers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  name VARCHAR(220) NOT NULL,
  address TEXT NOT NULL,
  equipment JSONB NOT NULL DEFAULT '[]',
  opening_hours JSONB NOT NULL DEFAULT '{}',
  media JSONB NOT NULL DEFAULT '[]',
  is_published BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE fitness_memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fitness_center_id UUID NOT NULL REFERENCES fitness_centers(id),
  name VARCHAR(160) NOT NULL,
  duration_days INT NOT NULL,
  price NUMERIC(14,2) NOT NULL,
  benefits JSONB NOT NULL DEFAULT '[]'
);

CREATE TABLE bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES users(id),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  service_type VARCHAR(60) NOT NULL,
  service_id UUID NOT NULL,
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  amount NUMERIC(14,2) NOT NULL,
  status booking_status NOT NULL DEFAULT 'PENDING',
  cancellation_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (ends_at > starts_at)
);

CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  booking_id UUID REFERENCES bookings(id),
  order_reference VARCHAR(160) NOT NULL UNIQUE,
  provider_transaction_id VARCHAR(180) UNIQUE,
  payment_method VARCHAR(50) NOT NULL,
  amount NUMERIC(14,2) NOT NULL,
  status payment_status NOT NULL DEFAULT 'INITIATED',
  paid_at TIMESTAMPTZ,
  raw_callback JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id UUID NOT NULL REFERENCES users(id),
  status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
  subtotal NUMERIC(14,2) NOT NULL,
  delivery_fee NUMERIC(14,2) NOT NULL DEFAULT 0,
  total NUMERIC(14,2) NOT NULL,
  delivery_details JSONB NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id),
  quantity INT NOT NULL CHECK (quantity > 0),
  unit_price NUMERIC(14,2) NOT NULL
);

CREATE TABLE qr_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  token_hash TEXT NOT NULL UNIQUE,
  owner_user_id UUID NOT NULL REFERENCES users(id),
  resource_type VARCHAR(60) NOT NULL,
  resource_id UUID NOT NULL,
  valid_from TIMESTAMPTZ NOT NULL,
  valid_until TIMESTAMPTZ NOT NULL,
  max_uses INT NOT NULL DEFAULT 1,
  uses_count INT NOT NULL DEFAULT 0,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (valid_until > valid_from),
  CHECK (uses_count <= max_uses)
);

CREATE TABLE qr_scans (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  qr_token_id UUID NOT NULL REFERENCES qr_tokens(id),
  scanned_by UUID NOT NULL REFERENCES users(id),
  result VARCHAR(40) NOT NULL,
  scanned_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE course_enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES courses(id),
  user_id UUID NOT NULL REFERENCES users(id),
  payment_status payment_status NOT NULL DEFAULT 'INITIATED',
  attendance JSONB NOT NULL DEFAULT '[]',
  assessment JSONB NOT NULL DEFAULT '{}',
  certificate_number VARCHAR(120) UNIQUE,
  certificate_qr_token_id UUID REFERENCES qr_tokens(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(course_id, user_id)
);

CREATE TABLE reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_user_id UUID NOT NULL REFERENCES users(id),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  notification_type VARCHAR(100) NOT NULL,
  title VARCHAR(220) NOT NULL,
  body TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}',
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE commission_rules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  service_type VARCHAR(60) NOT NULL,
  percentage NUMERIC(6,3) NOT NULL CHECK (percentage >= 0 AND percentage <= 100),
  effective_from TIMESTAMPTZ NOT NULL DEFAULT now(),
  effective_until TIMESTAMPTZ,
  updated_by UUID REFERENCES users(id)
);

CREATE TABLE provider_settlements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id UUID NOT NULL REFERENCES provider_profiles(id),
  gross_amount NUMERIC(14,2) NOT NULL,
  commission_amount NUMERIC(14,2) NOT NULL,
  net_amount NUMERIC(14,2) NOT NULL,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'PENDING'
);

CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID REFERENCES users(id),
  action VARCHAR(160) NOT NULL,
  entity_type VARCHAR(100) NOT NULL,
  entity_id UUID,
  before_data JSONB,
  after_data JSONB,
  ip_address INET,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_bookings_provider_time ON bookings(provider_id, starts_at, ends_at);
CREATE INDEX idx_bookings_customer_created ON bookings(customer_id, created_at DESC);
CREATE INDEX idx_competitions_status_start ON competitions(status, starts_at);
CREATE INDEX idx_products_category_price ON products(category, price);
CREATE INDEX idx_notifications_user_unread ON notifications(user_id, read_at);
CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id, created_at DESC);

-- IMPORTANT:
-- Preventing overlapping reservations must be implemented transactionally
-- (e.g. PostgreSQL exclusion constraint on a tstzrange per bookable resource,
-- with an explicit policy for cancelled/expired holds). Do not rely on client checks.
-- Payment callbacks must be idempotent and cryptographically/provider-verified.
