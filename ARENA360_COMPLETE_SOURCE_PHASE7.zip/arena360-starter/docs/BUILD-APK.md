# Android APK build

The current Flutter source has API-backed registration/login and public service-list screens. The APK has NOT been built or device-tested in this environment.

## Requirements
- Flutter stable (Dart 3.3+)
- Android SDK / Android Studio
- JDK 17 or the version required by the installed Flutter Android template
- Running ARENA 360 API reachable from the Android device

## Configure API address

Android emulator default:

```bash
--dart-define=API_BASE_URL=http://10.0.2.2:3000/api/v1
```

Physical phone: use the computer/server's LAN address, e.g. `http://192.168.x.x:3000/api/v1`; the phone and server must be able to reach each other. For production, use HTTPS.

## Build

```bash
cd apps/mobile
flutter pub get
flutter analyze
flutter build apk --release --dart-define=API_BASE_URL=https://YOUR_API_HOST/api/v1
```

Expected output: `build/app/outputs/flutter-apk/app-release.apk`.

Before distributing a production APK:
- configure application ID and signing key
- add/verify Android INTERNET permission in the generated Android manifest
- implement SMS OTP, password reset and refresh-token rotation (basic secure session restoration is now implemented)
- complete all booking, QR scanner, payment, order and provider workflows
- configure QPay merchant credentials and test invoice/callback/payment-check flow in sandbox; callbacks use a shared secret and server-to-server QPay payment verification
- test on physical Android devices and complete privacy/security review

## Automated build

`.github/workflows/ci.yml` includes a Flutter Android release build job and uploads the APK as a GitHub Actions artifact. The job generates the Android platform scaffolding, adds the INTERNET permission, runs `flutter analyze`, and builds with a placeholder API URL. Configure the real API URL and release signing before distributing.
