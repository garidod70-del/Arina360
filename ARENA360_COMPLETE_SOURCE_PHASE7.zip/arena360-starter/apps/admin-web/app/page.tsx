'use client';

import { useState } from 'react';

type Metrics = {
  users: number; providersPending: number; activeVenues: number; bookings: number;
  competitions: number; courses: number; products: number; orders: number;
  pendingPayments: number; confirmedRevenueMnt: number; currency: string;
};
const API = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:3000/api/v1';
const tiles: { key: keyof Metrics; label: string; suffix?: string }[] = [
  { key: 'users', label: 'Нийт хэрэглэгч' }, { key: 'providersPending', label: 'Баталгаажуулах үйлчилгээ үзүүлэгч' },
  { key: 'activeVenues', label: 'Идэвхтэй заал' }, { key: 'bookings', label: 'Заалны захиалга' },
  { key: 'competitions', label: 'Тэмцээн' }, { key: 'courses', label: 'Сургалт' },
  { key: 'products', label: 'Спорт бараа' }, { key: 'orders', label: 'Барааны захиалга' },
  { key: 'pendingPayments', label: 'Хүлээгдэж буй төлбөр' }, { key: 'confirmedRevenueMnt', label: 'Баталгаажсан орлого', suffix: '₮' },
];
export default function Home() {
  const [token, setToken] = useState('');
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  async function loadDashboard() {
    if (!token.trim()) { setError('Админы access token оруулна уу.'); return; }
    setLoading(true); setError('');
    try {
      const response = await fetch(`${API}/admin/dashboard`, { headers: { Authorization: `Bearer ${token.trim()}` }, cache: 'no-store' });
      const data = await response.json();
      if (!response.ok) throw new Error(Array.isArray(data.message) ? data.message.join(', ') : data.message || 'Мэдээлэл татахад алдаа гарлаа.');
      setMetrics(data as Metrics);
    } catch (e) { setError(e instanceof Error ? e.message : 'Сервертэй холбогдож чадсангүй.'); setMetrics(null); }
    finally { setLoading(false); }
  }
  return <main className="wrap">
    <header><div className="mark">A360</div><div><h1>ARENA 360</h1><p>Админ удирдлагын самбар</p></div></header>
    <section className="hero"><span>ПЛАТФОРМЫН УДИРДЛАГА</span><h2>Спортын үйлчилгээг нэг дор.</h2><p>Хэрэглэгч, үйлчилгээ үзүүлэгч, тэмцээн, захиалга болон төлбөрийн нэгдсэн хяналт.</p></section>
    <section className="authPanel">
      <label htmlFor="adminToken">Админы access token</label>
      <input id="adminToken" type="password" autoComplete="off" placeholder="Bearer token" value={token} onChange={e => setToken(e.target.value)} />
      <button onClick={loadDashboard} disabled={loading}>{loading ? 'Уншиж байна…' : 'Dashboard мэдээлэл татах'}</button>
      <small>Token зөвхөн энэ дэлгэцийн санах ойд хадгалагдана. Browser storage-д бичихгүй.</small>
      {error && <p className="error">{error}</p>}
    </section>
    {metrics && <><h3>ПЛАТФОРМЫН ҮЗҮҮЛЭЛТ</h3><section className="grid">{tiles.map(tile => <article key={tile.key}><small>{tile.label}</small><b>{Number(metrics[tile.key]).toLocaleString('mn-MN')}{tile.suffix ? ` ${tile.suffix}` : ''}</b></article>)}</section></>}
    {!metrics && <section className="grid"><article><b>Үйлчилгээ үзүүлэгч</b><small>Админ баталгаажуулалтын API холбогдсон</small></article><article><b>Тэмцээн, сугалаа</b><small>Тэмцээний удирдлагын API холбогдсон</small></article><article><b>Захиалга, төлбөр</b><small>Захиалгын бүртгэл ба pending төлбөрийн API холбогдсон</small></article></section>}
    <footer>ARENA 360 · Admin API · v0.6.0</footer>
  </main>;
}
