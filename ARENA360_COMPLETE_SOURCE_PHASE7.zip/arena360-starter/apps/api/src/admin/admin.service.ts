import { BadRequestException, Injectable } from '@nestjs/common';
import { PrismaService } from '../database/prisma.service';
@Injectable()
export class AdminService {
  constructor(private readonly db: PrismaService) {}
  async dashboard() {
    const [users, providersPending, venues, bookings, competitions, courses, products, orders, pendingPayments, revenue] = await Promise.all([
      this.db.user.count(),
      this.db.providerApplication.count({ where: { status: 'PENDING_ADMIN_REVIEW' } }),
      this.db.venue.count({ where: { isActive: true } }),
      this.db.booking.count(),
      this.db.competition.count(),
      this.db.trainingCourse.count(),
      this.db.marketplaceProduct.count(),
      this.db.marketplaceOrder.count(),
      this.db.paymentRecord.count({ where: { status: 'PENDING' } }),
      this.db.paymentRecord.aggregate({ where: { status: 'PAID' }, _sum: { amount: true } }),
    ]);
    return { users, providersPending, activeVenues: venues, bookings, competitions, courses, products, orders, pendingPayments, confirmedRevenueMnt: revenue._sum.amount ?? 0, currency: 'MNT' };
  }
  users(limit?: string) {
    const parsed = limit === undefined ? 50 : Number(limit);
    if (!Number.isInteger(parsed) || parsed < 1 || parsed > 100) throw new BadRequestException('limit 1–100 хооронд байна.');
    return this.db.user.findMany({ take: parsed, orderBy: { createdAt: 'desc' }, select: { id: true, phone: true, role: true, isActive: true, createdAt: true } });
  }
  payments(status?: string) {
    if (status && !['PENDING', 'PAID', 'FAILED', 'REFUNDED'].includes(status)) throw new BadRequestException('Төлбөрийн төлөв буруу байна.');
    return this.db.paymentRecord.findMany({ where: status ? { status } : undefined, orderBy: { createdAt: 'desc' }, take: 100 });
  }
  orders() { return this.db.marketplaceOrder.findMany({ orderBy: { createdAt: 'desc' }, take: 100, include: { items: { include: { product: { select: { title: true } } } } } }); }
}
