import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { ProvidersModule } from './providers/providers.module';
import { ServicesModule } from './services/services.module';
import { DatabaseModule } from './database/database.module';
import { AuthModule } from './auth/auth.module';
import { BookingsModule } from './bookings/bookings.module';
import { CompetitionsModule } from './competitions/competitions.module';
import { EcosystemModule } from './ecosystem/ecosystem.module';
import { AdminModule } from './admin/admin.module';
import { PaymentsModule } from './payments/payments.module';

@Module({
  imports: [DatabaseModule, AuthModule, ServicesModule, ProvidersModule, BookingsModule, CompetitionsModule, EcosystemModule, AdminModule, PaymentsModule],
  controllers: [AppController],
})
export class AppModule {}
