import { BadGatewayException, ConflictException, Injectable, NotFoundException, ServiceUnavailableException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { timingSafeEqual } from 'node:crypto';
import { PrismaService } from '../database/prisma.service';

type QPayToken = { access_token: string; expires_in?: number; token_type?: string };
type QPayInvoice = { invoice_id: string; qr_text?: string; qr_image?: string; qPay_shortUrl?: string; urls?: Array<{ name: string; description?: string; logo?: string; link: string }> };
type QPayCheck = { count?: number; paid_amount?: number; rows?: Array<{ payment_id?: string; payment_status?: string; payment_amount?: string | number; payment_currency?: string }> };
@Injectable()
export class PaymentsService {
  private token?: string;
  private tokenExpiresAt = 0;
  constructor(private readonly db: PrismaService) {}

  private config() {
    const baseUrl = process.env.QPAY_BASE_URL?.replace(/\/$/, '');
    const username = process.env.QPAY_USERNAME;
    const password = process.env.QPAY_PASSWORD;
    const invoiceCode = process.env.QPAY_INVOICE_CODE;
    const callbackBase = process.env.QPAY_CALLBACK_URL?.replace(/\/$/, '');
    const callbackSecret = process.env.QPAY_CALLBACK_SECRET;
    if (!baseUrl || !username || !password || !invoiceCode || !callbackBase || !callbackSecret || callbackSecret.length < 32) throw new ServiceUnavailableException('QPay холболт тохируулагдаагүй. Merchant эрх болон .env тохиргоо шаардлагатай.');
    if (!/^https:\/\//i.test(baseUrl) && process.env.NODE_ENV === 'production') throw new ServiceUnavailableException('Production QPay URL HTTPS байх ёстой.');
    if (!/^https:\/\//i.test(callbackBase) && process.env.NODE_ENV === 'production') throw new ServiceUnavailableException('Production callback URL HTTPS байх ёстой.');
    return { baseUrl, username, password, invoiceCode, callbackBase, callbackSecret };
  }

  private async accessToken() {
    if (this.token && Date.now() < this.tokenExpiresAt - 60_000) return this.token;
    const { baseUrl, username, password } = this.config();
    const response = await fetch(`${baseUrl}/v2/auth/token`, { method: 'POST', headers: { Authorization: `Basic ${Buffer.from(`${username}:${password}`).toString('base64')}`, 'Content-Type': 'application/json' }, signal: AbortSignal.timeout(15000) });
    if (!response.ok) throw new BadGatewayException(`QPay нэвтрэлт амжилтгүй (${response.status}).`);
    const body = await response.json() as QPayToken;
    if (!body.access_token) throw new BadGatewayException('QPay access token буцаасангүй.');
    this.token = body.access_token;
    this.tokenExpiresAt = Date.now() + Math.max(60, body.expires_in ?? 1800) * 1000;
    return this.token;
  }

  private async qpay<T>(path: string, method: 'GET' | 'POST', body?: unknown): Promise<T> {
    const { baseUrl } = this.config();
    const token = await this.accessToken();
    const response = await fetch(`${baseUrl}${path}`, { method, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, ...(body === undefined ? {} : { body: JSON.stringify(body) }), signal: AbortSignal.timeout(20000) });
    if (!response.ok) {
      const detail = (await response.text()).slice(0, 500);
      throw new BadGatewayException(`QPay хүсэлт амжилтгүй (${response.status}): ${detail}`);
    }
    return response.json() as Promise<T>;
  }

  async createInvoice(paymentRecordId: string, userId: string) {
    const payment = await this.db.paymentRecord.findFirst({ where: { id: paymentRecordId, userId } });
    if (!payment) throw new NotFoundException('Төлбөрийн бүртгэл олдсонгүй.');
    if (payment.status === 'PAID') throw new ConflictException('Энэ төлбөр аль хэдийн төлөгдсөн.');
    if (payment.status !== 'PENDING') throw new ConflictException('Энэ төлбөр нэхэмжлэх үүсгэх боломжгүй төлөвтэй байна.');
    if (payment.providerInvoiceId) return this.qpay<QPayInvoice>(`/v2/invoice/${encodeURIComponent(payment.providerInvoiceId)}`, 'GET');
    const { invoiceCode, callbackBase, callbackSecret } = this.config();
    const invoice = await this.qpay<QPayInvoice>('/v2/invoice', 'POST', {
      invoice_code: invoiceCode,
      sender_invoice_no: payment.idempotencyKey,
      invoice_receiver_code: 'terminal',
      invoice_description: `ARENA 360 ${payment.purpose}`.slice(0, 200),
      amount: payment.amount,
      callback_url: `${callbackBase}/api/v1/payments/qpay/callback/${payment.id}?key=${encodeURIComponent(callbackSecret)}`,
    });
    if (!invoice.invoice_id) throw new BadGatewayException('QPay нэхэмжлэхийн ID ирсэнгүй.');
    await this.db.paymentRecord.updateMany({ where: { id: payment.id, status: 'PENDING', providerInvoiceId: null }, data: { providerInvoiceId: invoice.invoice_id } });
    const saved = await this.db.paymentRecord.findUnique({ where: { id: payment.id } });
    if (saved?.providerInvoiceId !== invoice.invoice_id) throw new ConflictException('Нэхэмжлэхийн бүртгэл зэрэг өөрчлөгдсөн байна. Төлөв шалгана уу.');
    return invoice;
  }

  async status(paymentId: string, userId: string) {
    const payment = await this.db.paymentRecord.findFirst({ where: { id: paymentId, userId } });
    if (!payment) throw new NotFoundException('Төлбөрийн бүртгэл олдсонгүй.');
    if (payment.status === 'PENDING' && payment.providerInvoiceId) await this.confirmInvoice(payment.providerInvoiceId);
    const latest = await this.db.paymentRecord.findUnique({ where: { id: paymentId }, select: { id: true, purpose: true, amount: true, currency: true, status: true, providerInvoiceId: true, createdAt: true } });
    return latest;
  }

  async confirmPaymentRecord(paymentRecordId: string, callbackKey: string) {
    const expected = this.config().callbackSecret;
    const provided = Buffer.from(callbackKey || '');
    const known = Buffer.from(expected);
    if (provided.length !== known.length || !timingSafeEqual(provided, known)) throw new NotFoundException('Callback баталгаажуулалт амжилтгүй.');
    const payment = await this.db.paymentRecord.findUnique({ where: { id: paymentRecordId }, select: { providerInvoiceId: true } });
    if (!payment?.providerInvoiceId) throw new NotFoundException('QPay нэхэмжлэх олдсонгүй.');
    return this.confirmInvoice(payment.providerInvoiceId);
  }

  async confirmInvoice(invoiceId: string) {
    const payment = await this.db.paymentRecord.findFirst({ where: { providerInvoiceId: invoiceId } });
    if (!payment) throw new NotFoundException('Энэ QPay нэхэмжлэх ARENA 360-д бүртгэлгүй байна.');
    if (payment.status === 'PAID') return { received: true, status: 'PAID', paymentRecordId: payment.id };
    const result = await this.qpay<QPayCheck>('/v2/payment/check', 'POST', { object_type: 'INVOICE', object_id: invoiceId });
    const paidRows = (result.rows ?? []).filter((row) => row.payment_status === 'PAID' && row.payment_currency === 'MNT');
    const paidAmount = paidRows.reduce((sum, row) => sum + Number(row.payment_amount ?? 0), 0);
    if (paidAmount !== payment.amount) return { received: false, status: 'PENDING', paymentRecordId: payment.id, reason: 'Төлсөн дүн нэхэмжлэхийн дүнтэй таарахгүй байна.' };
    const paymentId = paidRows.find((row) => row.payment_id)?.payment_id ?? null;
    await this.db.$transaction(async (tx) => {
      const changed = await tx.paymentRecord.updateMany({ where: { id: payment.id, status: 'PENDING', amount: Math.floor(paidAmount) }, data: { status: 'PAID', providerPaymentId: paymentId } });
      if (!changed.count) {
        const current = await tx.paymentRecord.findUnique({ where: { id: payment.id } });
        if (current?.status !== 'PAID') throw new ConflictException('Төлбөрийн төлөв зэрэг өөрчлөгдсөн байна.');
      }
      if (payment.purpose === 'MARKETPLACE_ORDER') await tx.marketplaceOrder.updateMany({ where: { id: payment.referenceId, buyerId: payment.userId, status: 'PENDING_PAYMENT' }, data: { status: 'PAID' } });
      if (payment.purpose === 'FITNESS_MEMBERSHIP') await tx.fitnessMembership.updateMany({ where: { id: payment.referenceId, userId: payment.userId, status: 'PENDING_PAYMENT' }, data: { status: 'ACTIVE' } });
      if (payment.purpose === 'VENUE_BOOKING') await tx.userNotification.create({ data: { userId: payment.userId, title: 'Заалны төлбөр баталгаажлаа', body: 'Таны заалны захиалгын төлбөр амжилттай баталгаажлаа.', type: 'PAYMENT' } });
      await tx.userNotification.create({ data: { userId: payment.userId, title: 'Төлбөр амжилттай', body: `${payment.amount.toLocaleString('en-US')} MNT төлбөр баталгаажлаа.`, type: 'PAYMENT' } });
    }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
    return { received: true, status: 'PAID', paymentRecordId: payment.id };
  }
}
