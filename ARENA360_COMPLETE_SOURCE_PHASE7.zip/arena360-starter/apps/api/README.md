# ARENA 360 API — development source

NestJS + Prisma/PostgreSQL API source. This package is a development build, not a production deployment.

## Implemented API modules

- Phone/password registration and login with bcrypt and JWT access tokens.
- Current-account role lookup on every protected request; public registration cannot assign provider/admin roles.
- Provider applications, admin review, provider role promotion and audit logs.
- Public provider listings for referees, clubs and coaches; customer inquiries and notifications.
- Venue catalog, bookings, history and cancellation; server-side pricing and PostgreSQL overlap exclusion.
- Competition registration, single-elimination and round-robin draw generation, bye handling, score validation, winner advancement, standings and podium summary.
- Training courses, enrollment capacity checks, completion and certificate IDs.
- SHA-256 hashed QR tokens for certificates and active fitness memberships.
- Sports marketplace products, transactional stock decrement, orders and pending payment records.
- Fitness centers, plans, memberships and notifications.
- Admin metrics, user, payment and order listing APIs.
- QPay Merchant V2 invoice creation, payment status verification and callback verification. Callback data is not trusted; payment status is checked server-to-server with QPay before local state changes.

## Run locally

1. Copy root `.env.example` to `.env` and set `DATABASE_URL`, `JWT_ACCESS_SECRET` (32+ random characters), and the other secrets.
2. For local containers, run `docker compose up -d --build` from the repository root (set a strong `JWT_ACCESS_SECRET` in `.env` first). This starts PostgreSQL, API and admin web.
3. For a host-based API development process, start PostgreSQL with `docker compose up -d postgres`, then in `apps/api` run `npm install`, `npm run prisma:generate`, `npm run db:deploy`, `npm run build`, `npm run start`.
4. Check liveness at `GET /api/v1/health` and database readiness at `GET /api/v1/health/ready`.

## Main routes

### Auth and providers
- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `GET /api/v1/auth/me`
- `POST /api/v1/providers/applications`
- `GET /api/v1/providers/applications/mine`
- `GET /api/v1/providers/applications/pending` (ADMIN)
- `PATCH /api/v1/providers/applications/:id/approve` (ADMIN)
- `PATCH /api/v1/providers/applications/:id/reject` (ADMIN)
- `GET /api/v1/providers/admin/audit-logs` (ADMIN)

### Listings, courses, marketplace and fitness
- `GET/POST /api/v1/listings`
- `POST /api/v1/listings/:id/publish`
- `POST /api/v1/listings/:id/inquiries`
- `GET /api/v1/courses`, `POST /api/v1/courses`, `POST /api/v1/courses/:id/enroll`
- `POST /api/v1/courses/enrollments/:id/complete`
- `GET /api/v1/marketplace/products`, `POST /api/v1/marketplace/products`, `POST /api/v1/marketplace/orders`
- `GET /api/v1/fitness/centers`, `POST /api/v1/fitness/centers`, `POST /api/v1/fitness/centers/:id/plans`
- `POST /api/v1/fitness/plans/:id/subscribe`
- `POST /api/v1/fitness/memberships/:id/pass`
- `GET /api/v1/passes/verify/:token`
- `GET /api/v1/notifications/mine`, `PATCH /api/v1/notifications/:id/read`

### Venues, competitions and payments
- `GET /api/v1/venues`, `POST /api/v1/venues`
- `POST /api/v1/bookings`, `GET /api/v1/bookings/mine`, `POST /api/v1/bookings/:id/cancel`
- `GET/POST /api/v1/competitions`, `GET /api/v1/competitions/:id`
- `POST /api/v1/competitions/:id/registration/open`
- `POST /api/v1/competitions/:id/entrants`
- `POST /api/v1/competitions/:id/bracket/generate`
- `PATCH /api/v1/competitions/:id/matches/:matchId/result`
- `POST /api/v1/payments/qpay/invoices` (authenticated; body contains `paymentRecordId`)
- `GET /api/v1/payments/:id/status` (owner only; server checks QPay)
- `POST /api/v1/payments/qpay/callback/:paymentRecordId?key=...` (QPay callback; shared secret + server-to-server payment check)

## QPay configuration

The integration follows the QPay Merchant V2 flow: Basic-auth token, invoice creation, then `/v2/payment/check`. Use the QPay sandbox URL for development. Obtain merchant username/password and invoice code directly from QPay. Set `QPAY_CALLBACK_URL` to the public HTTPS origin of this API and `QPAY_CALLBACK_SECRET` to a separate random secret of at least 32 characters. Do not commit merchant credentials or callback secrets.

The API creates pending payment records for marketplace orders, fitness memberships and venue bookings. After a QPay invoice is created, the mobile/web client should display the returned `qr_image`, `qr_text`, short URL and bank deep links. Poll the authenticated status endpoint or rely on the callback; both paths verify the payment with QPay. Only an exact MNT amount match changes the local payment to PAID. Marketplace orders become PAID and fitness memberships become ACTIVE in the same database transaction.

QPay merchant onboarding and credentials are external prerequisites. Refunds, seller settlement/payouts, eBarimt, automated unpaid-order expiry/stock release and production reconciliation still require implementation and merchant/business rules.

## Important security and deployment limitations

- SMS OTP and password recovery are not active; an SMS vendor contract, API format and credentials are required. Registration currently confirms terms acceptance but does not verify phone ownership.
- Access-token refresh/rotation and account recovery are not implemented.
- In-memory QPay access-token caching is per API process; use a shared cache for multi-instance production deployment.
- Add distributed rate limiting, request tracing, production secret manager, HTTPS reverse proxy, backup/restore drills, monitoring, alerting and a security review before public launch.
- The booking record is created with a pending payment record; business policy for unpaid reservation expiry, refunds and payout is not yet automated.
- The competition engine supports single-elimination and round-robin formats. Pool play, sport-specific judo/wrestling draw rules, weight-category validation, referee approval and official result audit history remain future work.
- QR validation is an API endpoint; an in-app QR scanner and staff/provider scan screen are not yet complete.
- The mobile client is a navigation/authentication prototype, not the complete feature UI. The admin web is a dashboard foundation, not a full provider/admin workflow UI.

## Database migration note

The venue migration enables PostgreSQL `btree_gist` for the booking overlap constraint. The migration role must be allowed to create the extension, or a database administrator must enable it first. Apply migrations with `npm run db:deploy`, then generate the Prisma client with `npm run prisma:generate`.

## Verification status

The source bundle has not been built or integration-tested in this environment: npm dependency installation timed out. Prisma client generation, PostgreSQL migration execution, live QPay sandbox testing, Flutter analysis, Android APK build and physical-device testing remain outstanding. Do not deploy publicly or treat this package as production-ready until those checks pass.
